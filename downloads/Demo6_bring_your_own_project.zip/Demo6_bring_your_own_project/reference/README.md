# One worked answer

Open this **after** you have built your own, not before. There is no single
right design, and comparing two real attempts teaches more than copying one.

    capability_card.md    the human-readable description
    schema.json           the machine-readable contract
    server.py             a minimal MCP server that wraps simulate.py
    CLAUDE.md             project instructions for the agent
    .mcp.json.example     copy to ../.mcp.json to register the server

## To run this version

    cp reference/.mcp.json.example .mcp.json
    cp reference/CLAUDE.md .
    claude

Then ask for the baseline: `alpha 1.1e-4, dt 0.05, dx 0.01, nsteps 400`.

## The three things worth comparing against your own

1. **Does your validation include the stability rule?** It is not in the code,
   not in the README, and only hinted at in `notes.txt`. An agent cannot invent
   it. Someone has to know the physics.

2. **Does your result echo its own parameters?** `simulate.py` writes a bare
   two-column CSV. Six months later nobody can tell which run produced it.

3. **Did you wrap, or did you rewrite?** `simulate.py` is untouched here. The
   science stays where the scientist left it; the interface is new.
