#!/usr/bin/env python3
"""One worked answer: heat1d/simulate.py exposed as an MCP capability.

Standard library only. The science is untouched - this file wraps simulate.py,
it does not reimplement it.

The interesting part is check_stability(): a rule the original script does not
enforce, supplied by a person who knows the physics, checked before anything
runs.
"""
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent      # the project root
SIM = ROOT / "heat1d" / "simulate.py"

TOOL = {
    "name": "simulate_rod",
    "description": ("Run the 1-D heat diffusion simulation and return the final profile with "
                    "the numbers needed to judge it. Refuses configurations the explicit "
                    "scheme cannot integrate stably."),
    "inputSchema": {
        "type": "object",
        "properties": {
            "input": {"type": "string",
                      "description": "CSV with columns x_m and T_C, relative to heat1d/"},
            "alpha": {"type": "number", "minimum": 1e-8, "maximum": 1e-2, "default": 1.1e-4,
                      "description": "thermal diffusivity in m^2/s (NOT mm^2/s)"},
            "dt": {"type": "number", "minimum": 0, "description": "time step in seconds"},
            "dx": {"type": "number", "minimum": 0, "description": "node spacing in metres"},
            "nsteps": {"type": "integer", "minimum": 1, "maximum": 1000000},
            "out": {"type": "string", "default": "output/profile.csv"},
        },
        "required": ["input", "dt", "dx", "nsteps"],
    },
}

MAX_R = 0.5


def validate(args):
    errs, props = [], TOOL["inputSchema"]["properties"]
    for k in TOOL["inputSchema"]["required"]:
        if k not in args:
            errs.append("missing required argument '%s'" % k)
    for k, v in args.items():
        if k not in props:
            errs.append("unknown argument '%s' (allowed: %s)" % (k, ", ".join(props)))
            continue
        s = props[k]
        if s["type"] == "integer" and not isinstance(v, int):
            errs.append("'%s' must be an integer, got %r" % (k, v))
        if s["type"] == "number" and not isinstance(v, (int, float)):
            errs.append("'%s' must be a number, got %r" % (k, v))
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            lo = s.get("minimum")
            if lo is not None:
                # dt and dx have minimum 0 and must be strictly positive
                if (v <= lo) if lo == 0 else (v < lo):
                    errs.append("'%s' must be greater than %s, got %s" % (k, lo, v))
            if "maximum" in s and v > s["maximum"]:
                errs.append("'%s' must be <= %s, got %s" % (k, s["maximum"], v))
    return errs


def check_stability(alpha, dt, dx):
    """The rule simulate.py does not know about. A person had to supply this."""
    r = alpha * dt / (dx ** 2)
    if r > MAX_R:
        dt_max = MAX_R * dx ** 2 / alpha
        return r, (
            "refused before running: this configuration is numerically unstable.\n"
            "  r = alpha*dt/dx^2 = %.4f, and the explicit scheme requires r <= %.1f.\n"
            "  With alpha=%g and dx=%g, the largest usable dt is %.4g s.\n"
            "  The simulation WOULD have run and written a CSV - of oscillating nonsense."
            % (r, MAX_R, alpha, dx, dt_max))
    return r, None


def summarise(path):
    xs, ts = [], []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            xs.append(float(row["x_m"]))
            ts.append(float(row["T_C"]))
    return {"n_nodes": len(xs), "T_max": round(max(ts), 4), "T_min": round(min(ts), 4)}


def call(name, args):
    if name != TOOL["name"]:
        return "unknown tool: %s" % name, True
    errs = validate(args)
    if errs:
        return "argument validation failed (nothing was run):\n- " + "\n- ".join(errs), True

    alpha = args.get("alpha", 1.1e-4)
    r, problem = check_stability(alpha, args["dt"], args["dx"])
    if problem:
        return problem, True

    out = args.get("out", "output/profile.csv")
    cmd = [sys.executable, str(SIM), "--input", args["input"], "--alpha", str(alpha),
           "--dt", str(args["dt"]), "--dx", str(args["dx"]),
           "--nsteps", str(args["nsteps"]), "--out", out]
    p = subprocess.run(cmd, cwd=str(ROOT / "heat1d"), capture_output=True, text=True)
    if p.returncode != 0:
        return "simulate.py failed:\n" + (p.stderr or p.stdout), True

    result = {"r": round(r, 4), "stable": True,
              "t_total_s": round(args["dt"] * args["nsteps"], 6),
              "out": out, "parameters": dict(args, alpha=alpha)}
    result.update(summarise(ROOT / "heat1d" / out))
    return json.dumps(result, indent=2), False


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            res = {"protocolVersion": (msg.get("params") or {}).get("protocolVersion", "2024-11-05"),
                   "capabilities": {"tools": {}},
                   "serverInfo": {"name": "heat1d", "version": "1.0.0"}}
        elif method == "tools/list":
            res = {"tools": [{k: TOOL[k] for k in ("name", "description", "inputSchema")}]}
        elif method == "tools/call":
            pr = msg.get("params") or {}
            text, err = call(pr.get("name"), pr.get("arguments") or {})
            res = {"content": [{"type": "text", "text": text}], "isError": err}
        elif mid is None:
            continue
        else:
            print(json.dumps({"jsonrpc": "2.0", "id": mid,
                              "error": {"code": -32601, "message": "no method " + str(method)}}),
                  flush=True)
            continue
        if mid is not None:
            print(json.dumps({"jsonrpc": "2.0", "id": mid, "result": res}), flush=True)


if __name__ == "__main__":
    main()
