# Capability: `simulate_rod`

Run the 1-D heat diffusion simulation in `heat1d/simulate.py` and return the
final temperature profile, together with the numbers a reader needs in order to
decide whether to believe it.

## Inputs

| name | type | units | notes |
|---|---|---|---|
| `input` | string | — | CSV with `x_m`, `T_C`; first and last rows are fixed boundaries |
| `alpha` | number | **m²/s** | thermal diffusivity. The project README says mm²/s; the README is wrong, and the input file is in metres. Copper ≈ 1.11e-4 |
| `dt` | number | s | time step |
| `dx` | number | m | node spacing; must match the input file's own spacing |
| `nsteps` | integer | — | number of steps. Physical time simulated is `dt × nsteps` |

## The rule the code does not enforce

The scheme is explicit (forward time, centred space). It is stable only when

    r = alpha * dt / dx^2  <=  0.5

Above that, the solution oscillates between nodes and grows without bound. The
script does not check this. It runs, exits 0, and writes a well-formed CSV of
nonsense.

**This tool refuses to run when r > 0.5**, and says what to change.

## What it returns

    {
      "r": 0.055,                 the stability number, always reported
      "stable": true,
      "t_total_s": 20.0,          dt * nsteps
      "n_nodes": 101,
      "T_max": 68.192,
      "T_min": 20.0,
      "out": "output/profile.csv",
      "parameters": { ...every input, echoed back... }
    }

`parameters` is echoed so the result file is self-describing. Six months from
now, "what did we run?" has an answer that does not depend on anyone's memory.

## What stays under human control

- **Choosing `alpha`.** It is a property of the material being modelled. No
  agent can look it up for your rod.
- **Choosing `dx`.** It must match the physical spacing in the input file.
- **Deciding whether the physics is right at all** — boundary conditions,
  whether 1-D is adequate, whether the initial profile is the measured one.

The tool checks arithmetic. It cannot check that you are simulating the right
thing.
