# heat1d — project instructions

## Preferred workflow

Use the `heat1d` MCP tool `simulate_rod`. Do not call `heat1d/simulate.py`
directly and do not use `heat1d/plot_profile.py` — it is a 2024 driver kept only
so old scripts still run, and its `--steps` flag is the reason the README is
wrong.

## Units

`alpha` is in **m²/s**, not mm²/s. The project README says mm²/s and is wrong;
the input file is in metres. Copper is 1.11e-4 m²/s.

## Stability

Every run has a stability number `r = alpha·dt/dx²`. The tool refuses to run
when `r > 0.5`, because above that the explicit scheme oscillates and diverges
while still exiting cleanly.

**Report `r` in your first sentence, every time**, even when the run succeeded.
A temperature profile without its `r` is not a result a reader can check.

## What you must not decide alone

`alpha` is a property of the material and `dx` must match the spacing in the
input file. If either is missing from a request, ask — do not infer them from
the last run or from what looks typical.
