#!/usr/bin/env python3
"""OLD driver. Superseded by simulate.py - kept so the 2024 scripts still run."""
import argparse
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument("--input", required=True)
p.add_argument("--steps", type=int, default=400)      # note: simulate.py calls this --nsteps
a = p.parse_args()

sys.exit(subprocess.call([sys.executable, "simulate.py",
                          "--input", a.input, "--nsteps", str(a.steps)]))
