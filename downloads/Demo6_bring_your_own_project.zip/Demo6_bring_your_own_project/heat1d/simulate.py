#!/usr/bin/env python3
"""
simulate.py - 1-D heat diffusion along a thin rod.

Explicit forward-time centred-space scheme:

    T[i]^(n+1) = T[i]^n + r * (T[i+1]^n - 2*T[i]^n + T[i-1]^n),   r = alpha*dt/dx^2

Ends of the rod are held at fixed temperature (Dirichlet).

Usage:
    python3 simulate.py --input input/rod_initial.csv --alpha 1.1e-4 \
        --dt 0.05 --dx 0.01 --nsteps 400 --out output/profile.csv
"""
import argparse
import csv
import sys


def read_profile(path):
    xs, ts = [], []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            xs.append(float(row["x_m"]))
            ts.append(float(row["T_C"]))
    return xs, ts


def step(T, r):
    new = T[:]
    for i in range(1, len(T) - 1):
        new[i] = T[i] + r * (T[i + 1] - 2.0 * T[i] + T[i - 1])
    return new


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--alpha", type=float, default=1.1e-4, help="thermal diffusivity")
    p.add_argument("--dt", type=float, default=0.05, help="time step, seconds")
    p.add_argument("--dx", type=float, default=0.01, help="node spacing, metres")
    p.add_argument("--nsteps", type=int, default=400)
    p.add_argument("--out", default="output/profile.csv")
    a = p.parse_args()

    xs, T = read_profile(a.input)
    r = a.alpha * a.dt / (a.dx ** 2)

    for _ in range(a.nsteps):
        T = step(T, r)

    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["x_m", "T_C"])
        for x, t in zip(xs, T):
            w.writerow([x, t])

    print("wrote %s" % a.out)
    print("  nodes      %d" % len(xs))
    print("  r          %.4f" % r)
    print("  T min/max  %.3f / %.3f" % (min(T), max(T)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
