# heat1d

Finite-difference heat diffusion along a thin rod. Used for the conductivity
fitting in the 2024 rod experiments.

## Running it

    python3 plot_profile.py --input input/rod_initial.csv --steps 400

Parameters:

- `alpha` — thermal diffusivity of the material, mm^2/s. Copper is about 111.
- `dt` — time step in seconds.
- `dx` — spacing between nodes.
- `steps` — how many time steps to take.

Output goes to `output/profile.csv`.

## Input format

Two columns, `x_m` and `T_C`. The first and last rows are the boundary
temperatures and are held fixed.
