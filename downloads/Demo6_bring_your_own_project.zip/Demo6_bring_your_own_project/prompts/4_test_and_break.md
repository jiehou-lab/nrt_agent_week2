# Prompt 4 — test it, then try to break it

    Restart Claude Code so the new MCP server loads, then:

    1. Run the baseline: alpha 1.1e-4, dt 0.05, dx 0.01, nsteps 400.
    2. Now make it run faster: same total time, ten times fewer steps.
    3. Run that same faster configuration for 200 seconds of simulated time.
    4. Tell me which of those three results I can publish.

Step 2 looks fine. Step 3 does not. Neither one errors.
