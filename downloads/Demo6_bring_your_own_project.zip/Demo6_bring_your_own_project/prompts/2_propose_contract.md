# Prompt 2 — propose a contract, do not build it yet

    Propose how to expose ONE stable workflow from this project as an
    agent-callable capability. Do not change the scientific computation.

    Give me:
      - the capability's name and a one-sentence description
      - required inputs and optional parameters, with types and units
      - validation rules that should be checked BEFORE anything runs
      - the structure of the result it should return
      - what should stay under human control and not be exposed at all

    List anything you cannot decide without asking me.

That last line matters. The answer should include questions, not only a design.
