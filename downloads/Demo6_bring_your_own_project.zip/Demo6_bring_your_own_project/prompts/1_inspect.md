# Prompt 1 — inspect, change nothing

    Review this project and tell me:

    1. what the main analysis workflow actually is, and which file runs it
    2. the required inputs and their formats
    3. every parameter, what it means, and its units
    4. what the outputs are and where they go
    5. anything ambiguous, contradictory, or undocumented

    Do not change any files. Do not run anything yet. Where the README and the
    code disagree, say so and tell me which one you trust and why.

What to watch for: does it notice the flag the README gets wrong, the unit that
does not match the input file, and the driver that is no longer used?
