# Prompt 3 — build it

    Now build what we agreed:

      - capability_card.md, a human-readable description of the tool
      - schema.json, the machine-readable input contract
      - server.py, a minimal MCP server exposing the one capability, which
        validates every argument against the schema before running anything
      - CLAUDE.md, telling an agent in this project which interface to prefer
      - .mcp.json so Claude Code can start the server

    Standard library only. Do not modify simulate.py - wrap it.

Wrapping rather than rewriting is the whole point: the science stays where the
scientist left it.
