# Demo 6 — bring your own project

The first five demos handed you a package that had already been prepared. This
one hands you a project that has **not** been: one script, a README that is
partly out of date, an input file, an output folder, and nothing else. No
schema, no MCP server, no agent instructions.

Your job is to do to `heat1d/` what Demos 1 and 2 did to the tissue analyzer —
on code you have never seen, in a field that is not yours.

    heat1d/         a 1-D heat diffusion simulation (Python 3, standard library)
    prompts/        the four prompts, ready to paste
    reference/      one worked answer - open it AFTER you have made your own
    docs/           short walkthrough

Full guide: https://jiehou-lab.github.io/nrt_agent_week2/guides/demo6.html

## Why a heat equation

Because it has a trap that no amount of reading the code will reveal, and that
an agent cannot know unless a person tells it: the explicit scheme is only
stable when

    r = alpha * dt / dx^2  <=  0.5

Above that the simulation still runs, still exits 0, and still writes a
perfectly well-formed CSV. Whether the numbers in it mean anything is a
question the software never asks.

That is the same lesson as the fold-artifact slide, in a different subject.
