# Quick walkthrough

Full guide: https://jiehou-lab.github.io/nrt_agent_week2/guides/demo6.html

```bash
unzip Demo6_bring_your_own_project.zip
cd Demo6_bring_your_own_project
claude
```

Paste the four prompts in order, from `prompts/`:

1. `1_inspect.md` — what is this project, and what is ambiguous?
2. `2_propose_contract.md` — design the capability, do not build it
3. `3_build.md` — build the card, schema, server, CLAUDE.md
4. `4_test_and_break.md` — baseline, "make it faster", then the long run

Then open `reference/` and compare.

**The number to watch is `r = alpha·dt/dx²`.** Above 0.5 the simulation still
runs, still exits 0, and still writes a tidy CSV of nonsense.
