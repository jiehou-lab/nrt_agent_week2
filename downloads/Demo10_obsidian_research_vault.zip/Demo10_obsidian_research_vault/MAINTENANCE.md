# Living with the vault

`SETUP.md` walks you through the exercise once. This is what you do afterwards,
every week, for years.

---

## The daily loop — about two minutes

```bash
cd ~/research-system/Demo10_obsidian_research_vault/vault
cp ~/Downloads/the-paper-i-just-found.pdf inbox/
claude
```

```
File everything in inbox/.
```

That is the whole thing. `CLAUDE.md` carries the conventions, so you never
re-explain where notes go or what a note must contain.

When you have another minute:

```
Use the curator subagent on the note you just wrote.
```

It tells you which topic note the paper bears on, what it contradicts, and
what gap it opens — as a proposal in `proposals/`, for you to accept or not.

### The habit that decides whether this is worth doing

**Fill in `## My take` yourself, the same day.** Two sentences. No agent writes
in that section.

Six months from now it is the only part of the note you will trust without
re-reading the paper, because it is the only part you wrote. A vault where that
section is always empty is a vault of summaries, and you could have generated
summaries at any time. The notes are not the asset; your reaction to them is.

### What not to do daily

| | Why |
|---|---|
| Run `skeptic` on every note | It is a cross-document pass. One note gives it nothing to compare. Weekly. |
| Accept a proposal the day it appears | Let it sit. One that still looks right a week later usually is. |
| Ask the agent to "tidy up" the folders | Nothing to gain, and a rename breaks every `[[wikilink]]` pointing at it. |

---

## The weekly routine — fifteen minutes, Friday

### 1. Verify (ten minutes)

```
Use the skeptic subagent to cross-check everything added this week
against the sources in pdfs/.
```

Skim for **one thing**: claims in notes that are not in the source. Everything
else can wait. That is the error that compounds — a wrong number in a note
becomes a wrong number in a draft becomes a wrong number in a submission.

### 2. Decide (five minutes)

Open `proposals/`. For each one, either:

- **Accept** — paste the lines into the topic note yourself, then delete the
  proposal.
- **Reject** — write one line under `## Rejected reasons` and delete it.

A rejected proposal with a reason is worth as much as an accepted one: it stops
the same suggestion coming back next month, and the reason is often more
interesting than the proposal was.

`proposals/` should be near-empty most of the time. Forty pending proposals is
a folder nobody reads.

### 3. Commit

```bash
git add -A && git commit -m "week of $(date +%Y-%m-%d)"
```

---

## Adding each kind of thing

### A paper PDF
Drop it in `inbox/` under whatever name it downloaded as. Then *"File
inbox/<name>."* Do not rename it first — if the agent needs a tidy filename,
that is a finding about your `CLAUDE.md`, not about the file.

### A web page
Use the [Obsidian Web Clipper](https://github.com/obsidianmd/obsidian-clipper)
and save into `inbox/`. It runs in your logged-in browser, so it gets past
paywalls and institutional logins an agent cannot reach. **Capture in the
browser, process in the agent.**

### A scan with no text layer
Check first:

```bash
pdftotext scan.pdf - | wc -c
```

Under ~100 characters means no text layer. Say so in the prompt — *"this is a
scan, read the pages as images"* — which saves the agent a wasted step. For
anything long, OCR it first with `ocrmypdf`.

### A spreadsheet of your own measurements
Into `inbox/`, **and say what the units are in the prompt.** The most common
real failure in this demo is comparing numbers in different units without
noticing, and one sentence from you prevents it.

### A paper that changes your mind
This is the case the `curator` exists for, and it is worth treating
differently. Ask explicitly:

```
Use the curator subagent on papers/<note>.md. Does anything already in
topics/ have to change, or is this additive?
```

Three outcomes need three different responses, and collapsing them is the
common mistake:

| | Means | Do |
|---|---|---|
| **Refinement** | both true, different scope | add a qualifier to the existing line |
| **Supersession** | same question, better evidence, later | replace the line, keep the old source |
| **Contradiction** | one of them is wrong | change nothing yet — flag it and go read |

Never let a note end up asserting both the old claim and the new one. A note
that says both things reads as considered, which is worse than a note that is
simply out of date.

---

## Scaling past a hundred notes

The shipped vault has ten documents. Four things change when it has three
hundred:

**1. Searching is no longer free.** `grep` across 300 notes is fine; having an
agent *read* 300 notes is not. Narrow the prompt by folder or by tag:
*"search papers/ tagged topic/thermostability"*, not *"search the vault"*.

**2. `topics/` becomes the index.** Once the vault is big, the topic notes are
how you find anything — the papers folder is storage. Keep topic notes short
and link-heavy rather than long and comprehensive.

**3. Concept notes should be earned, not generated.** It is tempting to ask for
a note per concept. Don't. Create one when a concept has appeared in **three or
more papers** and you have something to say about it. A wiki of 300
agent-written concept stubs is unreadable and nobody maintains it.

**4. `CLAUDE.md` starts getting ignored.** See below.

---

## What rots, and the tell

| What | How you notice | Fix |
|---|---|---|
| **`CLAUDE.md` grows** | The agent follows the first half and drifts on the rest | Keep it under one screen. When a rule is ignored repeatedly, **move it into `settings.json`** — from a request to a refusal. That migration is the most useful habit here. |
| **`## My take` is empty everywhere** | You stop opening old notes | You have built a summary generator. Write two sentences per paper or stop filing them. |
| **`proposals/` fills up** | You scroll past it | Clear it weekly. Rejecting is a decision too. |
| **Links break** | `[[wikilink]]` renders as plain text | Something got renamed. Obsidian updates links on rename *inside* Obsidian; renames by an agent or by `mv` do not. |

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Agent ignores `CLAUDE.md` | You launched `claude` from the package root. `cd vault` first — the contract loads from the directory you start in. |
| It wrote to `topics/` | Shouldn't be possible. Check `python3 -m json.tool .claude/settings.json` parses; one trailing comma disables the file silently. |
| `Subagent not found` | Must be in `.claude/agents/` with frontmatter whose `name:` matches what you typed. `head -6 .claude/agents/*.md`. |
| Slow and expensive | `pdftotext` missing, so it is reading PDFs as images over and over. Install poppler. |
| It summarised the abstract | The failure this demo is about. Add an explicit instruction naming the sections it must open; if that doesn't hold, run `skeptic` as a separate pass. |
| Start over | `git checkout . && git clean -fd` |
