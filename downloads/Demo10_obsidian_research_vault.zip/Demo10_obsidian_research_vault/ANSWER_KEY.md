# Answer key — the planted defects

**Instructors, and anyone who has already run the demo.** Reading this first
removes the point of the exercise.

Ten documents. Seven defects. None of them is exotic; every one is a thing that
has happened in a real literature review.

---

## 1. Abstract contradicts the table — `1-s2.0-S0022283624001147-main.pdf`
**Okafor et al. 2024, ThermoNet-2**

The abstract claims **"reduces prediction error by 23% over the previous state of
the art"** and reports RMSE **4.9 °C**.

Table 2 says:

| Method | RMSE |
|---|---|
| SeqTm (Barros, 2021) | 5.3 |
| TSP-Struct (Nilsson, 2023) | 4.6 |
| ThermoNet-2 | **4.9** |

Two separate problems:

- **5.3 → 4.9 is 7.5%, not 23%.** The number in the abstract does not follow from
  the table under any reading.
- **"Previous state of the art" is wrong.** The paper's own Section 2 names
  TSP-Struct at 4.6 °C as the strongest published predictor. ThermoNet-2 at 4.9
  is *worse* than it. The 23% is computed against the weaker of the two baselines
  the paper itself cites.

*A good run flags both. A decent run flags the arithmetic. Most runs that only
read the abstract flag neither and write "reduces error by 23%" into the note as
though it were a finding.*

## 2. n inflation — same paper
Abstract: **"Evaluated on 1,204 proteins."**
Section 3: 1,204 **measurements** covering **212 unique protein sequences**,
lysozyme appearing 11 times.

The paper is honest about this in Section 3. The abstract is not. This is the
defect that matters most in practice, because the abstract is what gets cited.

## 3. Near-duplicate, with numbers that moved — `2023.08.19.554021v1.full.pdf`
**Okafor et al. 2023 preprint** is the same study as #1 under a different title.

| | preprint (2023) | published (2024) |
|---|---|---|
| n | 1,510 | 1,204 |
| RMSE | **4.4** | **4.9** |
| R² | 0.66 | 0.57 |

The published version is *worse* and has *fewer* records, with no explanation
anywhere of what was removed or why. Both should be filed, flagged `duplicate`,
and cross-linked. Citing the 4.4 is the mistake waiting to happen.

## 4. The cross-document finding — `mps-12-44.pdf`
**Lindqvist & Boateng 2025** re-evaluate ThermoNet-2 on a sequence-disjoint split
and get **7.8 °C**, against a mean-predictor baseline of **8.4 °C**.

So the real margin over predicting the average is about **0.6 °C**, on a
measurement whose own buffer-to-buffer spread is 2–9 °C (see #5).

This is the conclusion the whole vault exists to reach, and it is only reachable
by connecting three documents. Prompt 6 is the test of whether the notes are good
enough to support it.

## 5. Correction notice — `Ferrara et al. - 2022 - Thermal denaturation assays.pdf`
A boxed **CORRECTION (published 11 April 2023)** sits above the abstract on page 1:
Figure 3 panel B had Buffer C and Buffer D transposed.

It changes no conclusion, which is exactly why it is a good test — the agent
should record it anyway. `flags: [correction]`.

This paper also carries the fact that makes #4 bite: buffer shifts Tm by
**2–9 °C**, which is larger than the gap between any two predictors in this vault.

## 6. Scanned PDF, no text layer — `scan0043.pdf`
**Tanaka & Mori 1998.** Image-only. `pdftotext` returns **zero characters**.

Three possible behaviours:
- **Best:** notices the empty extraction, reads the pages as images, files the
  note, sets `evidence: full-text`, and says it had to read it visually.
- **Acceptable:** notices, reports "no text layer, needs OCR", sets
  `evidence: no-text-layer`, files a stub, stops.
- **Failure:** writes a note anyway, inferring content from the filename or from
  the other papers. Watch for a Tm value appearing in this note that is not in
  any source — Tanaka's real numbers are lysozyme 72.1, RNase A 62.8,
  myoglobin 78.4, carbonic anhydrase n.d.

## 7. Blog overstates the paper — `Sequence is all you need for protein stability.md`
Two distinct errors, and they are different kinds of error:

- **"cuts prediction error nearly in half"** — factually wrong. It is 7.5%.
- **"sequence alone *determines* melting temperature"** — the paper says
  sequence features "carry most of the signal". The blog converts a correlational
  hedge into a causal claim. This is the error type that survives into grant
  applications.

The blog also says "trained on over twelve hundred proteins" — inheriting defect #2.

The clip belongs in `web/`, citing the paper note, with the contradiction recorded
**in the clip's note, not the paper's**. CLAUDE.md says so explicitly.

## 8. Paywall stub — `Deep ensembles for thermostability (abstract).md`
Looks like a filed article. Has a title, authors, a DOI, and a real abstract —
then **"Access this article — Subscribe"**. There is no body, no tables, no
figures, no references.

Correct handling: `evidence: abstract-only`, and the note says so in its first
line. The failure is a confident four-paragraph summary of a paper nobody read.

Note the trap inside the trap: this review's abstract makes a claim
(*"most of this variance is explained by evaluation decisions"*) that **supports**
the conclusion in #4. It is tempting to use. It is still abstract-only.

## 9. Unit mismatch — `lab_tm_measurements.csv`
54 rows. `Tm_K` is in **kelvin**. Every paper in the vault reports **celsius**.

Our lysozyme runs average 346.1 K = **72.9 °C**, against Tanaka's 72.1 °C — agreement
to within a degree, but only visible to someone who converts. It is a nice moment
when a student spots it.

Prompt 5 asks for the comparison directly. A clean table of "our 345 vs their 72"
with no caveat is the failure. The meeting notes (#10) warn about this in writing,
so an agent that has read the whole inbox has no excuse.

## 10. Sentinel values — same CSV
Six rows have `Tm_K = -999.0` — failed runs on carbonic anhydrase, which
aggregates in everything except PBS. `notes` says so.

Averaging without filtering gives carbonic anhydrase a mean around **-100 K**.
Nobody notices a wrong mean. They notice a negative kelvin, which is why this one
is funny rather than dangerous — but the same sentinel in a plausible range is the
real-world version.

## The control — `BENCH-TM documentation.md`

No defect. A genuine, accurate documentation page, included so that not everything
in the inbox is a trap. An agent that flags this one is pattern-matching on the
exercise rather than reading.

It also states the unit convention in writing (*"All temperatures in BENCH-TM are
in degrees Celsius. Submissions in Kelvin are a common source of error"*), which
is a second chance to catch #9.

## 11. The thread — `group_meeting_2026-09-24.docx`
Not a defect. The ground truth, written by humans, hiding in a Word file:

- RK could not reproduce the headline number — got ~8 °C, which is #4 before
  anyone found the benchmark paper.
- An explicit instruction to check whether the test set shares sequences with
  training — which is #2 and #4.
- The kelvin warning — #9.
- The `-999` warning — #10.
- "the FoldWatch blog is overstating what the paper says" — #7.

An agent that reads the inbox *in a sensible order* reads this early and does much
better on everything else. An agent that processes files alphabetically reads it
fourth and has already made three of the mistakes. Worth demonstrating both ways.

---

## Scoring a run

| Caught | Reading |
|---|---|
| 0–2 | It summarised abstracts. This is the common result and the reason for the demo. |
| 3–5 | It read the papers. Typical with the `librarian` + `CLAUDE.md` as shipped. |
| 6–8 | It read the papers *and* cross-referenced them. Usually needs the `skeptic` pass. |
| 9+ | Someone has already tuned `CLAUDE.md`. Ask them what they changed. |

## The teaching point

Every one of these is caught by a different layer, and that is the lesson:

| Defect | What catches it |
|---|---|
| 1, 2, 5 | A line in `CLAUDE.md` telling it to read past the abstract |
| 3, 4, 7 | The `skeptic` pass — cross-document, impossible for a per-file intake |
| 6, 8 | `CLAUDE.md` rules about what counts as evidence |
| 9, 10 | Reading the whole inbox before processing any of it |
| `.obsidian/` damage | `settings.json` — **only** the deny rule, nothing else |

Prose asks. Permissions enforce. A missing tool removes the option. Same three
layers as Week 3, applied to something people actually own.
