# Demo 10 — Claude Code + Obsidian: a research vault that checks itself

**Level:** anyone who finished Week 3. No ML, no coding.
**Time:** 35–45 minutes end to end. The first result arrives in about 8.

---

## The one thing to understand before you start

**An Obsidian vault is a folder of Markdown files.** That is the whole format.

So there is nothing to integrate. You `cd` into the folder and run `claude`.
No plugin, no API key, no server, no MCP. Guides that start by telling you to
install Obsidian's Local REST API plugin are describing an optional extra —
useful if you want Claude to use *Obsidian's own* search index or talk to a
running Obsidian instance, and unnecessary for everything in this demo.

You do not even need Obsidian installed to do this demo. Obsidian is the viewer.
Install it if you want to see the graph and the property tables; skip it if you
just want to watch the agent work.

## What this demo is actually about

Not "AI reads my papers." The interesting question is the one underneath:

> When an agent writes a note about a paper, **what stops the note from being wrong?**

`inbox/` contains ten documents of the kinds that actually pile up — journal PDFs
with download-garbage filenames, a preprint, a scan, clipped web pages, a
spreadsheet of your own measurements, and meeting notes. Several of them are
wrong, or disagree with each other, in ways that are completely ordinary and
completely invisible if you only read abstracts.

You will see the agent catch some of those and miss others. Catching the misses is
the exercise.

## Layout

```
vault/
├── CLAUDE.md            the note contract — read this first
├── .claude/
│   ├── settings.json    permissions: what the agent cannot do here
│   └── agents/
│       ├── librarian.md intake: document -> note
│       └── skeptic.md   cross-check: no Write tool, reports only
├── inbox/               the raw mess (10 documents)
├── papers/              one note per paper  <- the real database
├── pdfs/                the files, renamed, never edited
├── web/                 processed clips
├── topics/              your own synthesis notes
└── _templates/paper.md
```

## Run it

See `SETUP.md`. Short version:

```bash
cd vault
git init && git add -A && git commit -m "before the agent"   # your undo button
claude
```

Then work through the six prompts in `SETUP.md`.

## Files

| File | What it is |
|---|---|
| `SETUP.md` | Step-by-step, the six prompts, what to watch for |
| `ANSWER_KEY.md` | **Instructors / after you have tried it.** Every planted defect. |
| `vault/` | The vault |

Opening `ANSWER_KEY.md` first spoils the demo. It is the only thing in here you
can get wrong before you start.
