# Setup and run

## 0. What you need

- **Claude Code**, working. (Week 3 setup. `claude` should start.)
- **`pdftotext`** — for long PDFs. Claude Code reads short PDFs natively, so this
  is an optimisation, not a requirement.
  - macOS: `brew install poppler`
  - Ubuntu/Debian: `sudo apt install poppler-utils`
  - Windows: install inside WSL, or skip it.
- **Obsidian** — *optional*. Download from obsidian.md. Everything below works
  without it.

Check:

```bash
claude --version
pdftotext -v          # "command not found" is survivable
```

## 1. Open the vault

```bash
cd Demo10_obsidian_research_vault/vault
ls
```

Nine entries. `inbox/` has the raw documents; everything else is nearly empty.

**Make your undo button before you let an agent near your notes:**

```bash
git init
git add -A
git commit -m "before the agent"
```

This is the single most useful thing in this demo. Every later step is
`git diff` away from being reviewed and `git checkout .` away from being undone.

## 2. Look at the contract first

```bash
cat CLAUDE.md
cat .claude/settings.json
cat _templates/paper.md
```

Three files, three different kinds of instruction:

| File | What it is | Enforced? |
|---|---|---|
| `CLAUDE.md` | What I want the agent to do | **No.** It is context. |
| `.claude/settings.json` | What the agent *cannot* do | **Yes.** Client-side, before the tool runs. |
| `_templates/paper.md` | The shape of the output | No — a shape to copy. |

There is also an `ask` tier: every write into `papers/` will prompt you. That is
deliberate for a first run — you see each note before it lands. Once you trust it,
delete those two lines.

Read the `deny` list. `Edit(./.obsidian/**)` is there because `.obsidian/` holds your
plugin state, hotkeys and graph layout — a well-meaning agent "tidying the vault"
can erase a year of configuration. `Edit(./topics/**)` is there because `topics/`
is where *your* thinking lives, and you do not want it improved.

## 3. Open Obsidian (optional, 1 minute)

Obsidian → *Open folder as vault* → pick `vault/`. Trust the author when asked.
Open `papers/barros2021_seqtm.md` and turn on **Properties** in the right sidebar.
That table is the YAML frontmatter. Same bytes, two views.

Leave it open. You will watch notes appear in it.

---

# The six prompts

Run `claude` in `vault/`. Paste these one at a time and read what comes back
before continuing.

### Prompt 1 — orient

```
Look at inbox/ and tell me what kinds of documents are there.
Do not process anything yet.
```

You are checking that it distinguishes *kinds* — paper, preprint, clip, scan,
spreadsheet, notes — rather than listing ten filenames.

### Prompt 2 — one paper, carefully

```
Use the librarian subagent to file inbox/1-s2.0-S0022283624001147-main.pdf.
```

Then open the note it wrote. **Read the `## Checks` section before anything else.**

> Write down here what it flagged, if anything: ________________________

Now open the PDF yourself and compare the abstract to Table 2. Two of the numbers
in that abstract do not follow from that table. Did the agent find both, one, or
neither?

### Prompt 3 — the batch

```
Use the librarian subagent to file everything else in inbox/.
```

This is where it gets interesting. Watch for how it handles `scan0043.pdf`
and `Deep ensembles for thermostability (abstract).md`.

```bash
git diff --stat
```

### Prompt 4 — turn the agent on its own work

```
Use the skeptic subagent to cross-check everything in papers/ and web/
against the sources in pdfs/ and inbox/.
```

The skeptic has **no Write tool**. It cannot fix anything, only report. That is
deliberate: a verifier that can edit is a verifier you cannot trust, because it
can make its own findings disappear.

### Prompt 5 — your own data

```
Compare the measurements in inbox/lab_tm_measurements.csv against the
melting temperatures reported in the papers I have filed.
```

There is a trap in this one, and it is the most common real mistake in this whole
demo. If the agent gives you a clean comparison with no caveat, it fell in.

### Prompt 6 — the question the vault is for

```
Based only on the notes in papers/, what should I conclude about whether
sequence-only Tm prediction has actually improved since 2021? Cite the note
for every claim.
```

Then:

```bash
git diff
git log --oneline
```

---

## What to do afterwards

1. `cat ANSWER_KEY.md` and count what was caught.
2. For each miss, work out **which of the three layers should have caught it** —
   a line in `CLAUDE.md`, a rule in `settings.json`, or a tool removed from a
   subagent. Then change that file and re-run the prompt.
3. `git checkout .` puts the vault back to the start so you can run it again.

That loop — run, miss, change the file that should have caught it, re-run — is
the whole skill. The vault is just somewhere to practise it.

## Using this on your own papers

Copy `vault/CLAUDE.md`, `vault/.claude/` and `vault/_templates/` into a real
vault of your own, empty the folders, and edit `CLAUDE.md` to describe how *you*
want notes written. Keep the `deny` list. Keep the git repo.
