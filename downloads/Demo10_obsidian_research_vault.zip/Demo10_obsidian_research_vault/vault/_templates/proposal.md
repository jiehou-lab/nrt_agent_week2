---
type: proposal
date:
source: ""              # the paper note this came from
targets: []             # the topic notes it would change
kind:                   # additive | refinement | contradiction | supersession
status: pending         # pending | accepted | rejected
---

# Proposal — <source> → <topic note>

## 1. Which topic note, and what changes there

**Note:** [[...]]
**The specific line or question:** "<quote it>"

## 2. Concept supplemented

What the vault did not know, or knew less precisely, before this.

## 3. Contrast

| | Claim | Source |
|---|---|---|
| Already here | | |
| This paper | | |

**Kind:** contradiction / refinement / supersession — and why that one.

## 4. Gap this opens

A question the vault now raises and cannot answer.

---

## Proposed edit

**Remove or change** (quoted exactly from the current note):

> <the existing lines, verbatim. Leave this empty for a purely additive proposal.>

**Add:**

> <the exact lines to paste in>

**Rests on:** [[paper note]] — section/table.

---

## Rejected reasons

<!-- if you reject this, say why here. the next pass should read it. -->
