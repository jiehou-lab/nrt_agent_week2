---
type: paper
title: ""
authors: []
year:
venue: ""
doi: ""
url: ""
pdf: ""
added:
status: unread          # unread | skimmed | read
evidence: full-text     # full-text | abstract-only | no-text-layer
flags: []               # contradiction | duplicate | correction | retracted | unit-mismatch
tags: []
---

# <Author><Year> — <short title>

## Claim
One sentence: what the paper asserts is true.

## Evidence
What was actually measured. Design, n, metric, baseline, the numbers from the tables.

## Checks
Anything that does not line up: abstract vs tables, n vs methods, baseline choice,
corrections or notices on the paper, overlap with another note in this vault.

## Limitations
What the authors themselves concede, and what they do not.

## Links

## My take
<!-- mine. do not write here. -->
