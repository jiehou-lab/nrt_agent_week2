---
type: paper
title: "SeqTm: a sequence-based regressor for protein melting temperature"
authors: [Barros, M.]
year: 2021
venue: "Protein Science Letters 9(2): 77-88"
doi: "10.2101/psl.2021.0077"
url: ""
pdf: ""
added: 2026-09-20
status: read
evidence: full-text
flags: []
tags: [topic/thermostability, method/sequence-only]
---

# Barros 2021 — SeqTm

> Filed by hand as the worked example. The PDF is not in this vault; the numbers
> below are taken from the tables of the papers that cite it.

## Claim
A gradient-boosted regressor over amino-acid composition features predicts
melting temperature about as well as early structure-based methods.

## Evidence
Reported RMSE 5.3 °C, R² 0.52 on the ProTherm-DSF record-level split.
Widely reused as the sequence-only baseline.

## Checks
Re-evaluated by [[lindqvist2025_benchmark]] on a sequence-disjoint split:
RMSE 8.1 °C, against a mean-predictor baseline of 8.4 °C.

## Limitations
Record-level splitting. Buffer conditions folded into the label.

## Links
- [[okafor2024_thermonet2]] uses this as its baseline.

## My take
Treat 5.3 °C as a number about a split, not a number about a method.
