# Research vault

This is an Obsidian vault. Every file is Markdown. Frontmatter is YAML and is the
contract between what you write and what Obsidian can query.

You do not need Obsidian running. This is a folder.

## Folders

| Folder | What lives here |
|---|---|
| `inbox/` | Raw documents as they arrive. PDFs, clipped web pages, exports. Nothing here is processed yet. |
| `papers/` | One note per paper. This is the real database. |
| `pdfs/` | The PDF files themselves, renamed. Never edited. |
| `web/` | Processed clips of web pages. |
| `topics/` | My own synthesis notes. You may link to these; you may not rewrite them. |
| `proposals/` | Where you propose changes to `topics/`. The only place you may write outside `papers/` and `web/`. |
| `wave2/` | Documents that arrive later. Ignore until I move them to `inbox/`. |
| `_templates/` | Note templates. |

## Adding a paper

1. Read the PDF. Short ones whole; for anything long,
   `pdftotext -f 1 -l 12 inbox/file.pdf -` first and read ranges after that.
2. **Read past the abstract.** The abstract is a claim. The methods and tables are
   the evidence. Where they disagree, the table wins and you say so.
3. Move the PDF to `pdfs/<firstauthor><year>_<keyword>.pdf`.
4. Create `papers/<firstauthor><year>_<keyword>.md` from `_templates/paper.md`.
5. Link it with `[[wikilinks]]` to any note in `papers/` or `topics/` it relates to.
6. Leave `## My take` empty. That section is mine.

## Rules

- **Never state a number that is not in the source.** If it is not there, write `unknown`.
- **Quote the source's own units.** Do not convert silently; if you convert, show both.
- **An abstract is not a paper.** If you only had the abstract — because the PDF was
  paywalled, or a clip stopped at "Subscribe" — set `evidence: abstract-only` and say
  so in the first line of the note.
- **If text extraction returns nothing, say so.** A scanned PDF with no text layer is
  not an empty paper. Report it and stop; do not guess from the filename.
- **A blog post is not evidence.** Clips in `inbox/` that describe a paper are filed in
  `web/` and must cite the paper note they refer to. If a clip's claim contradicts the
  paper, record the contradiction in the clip's note, not in the paper's.
- Never edit `.obsidian/` — that is Obsidian's own configuration.
- Never modify or delete anything in `pdfs/`.
- Do not write to `topics/`. Ever. Propose instead — see below.

## Growing the vault

Filing a paper is not the point; it is the cost of entry. The point is that
what I think changes when I read something.

When I ask what a new paper means for the vault, use the `curator` subagent. It
answers four questions — which topic note this bears on, what concept it
supplements, what it contrasts with, and what gap it opens — and writes a
**proposal** to `proposals/`, containing the exact lines to add and the exact
lines to remove.

I apply proposals myself. This is not distrust of the output; it is that a
synthesis note I accepted is mine and one that appeared while I was not looking
is not, and after six months I will no longer be able to tell which sentences I
wrote. The rule exists to keep that distinction, not to keep the agent out.

**A new paper does not only add.** Three different things can happen to an
existing claim, and they need different responses:

| | What it means | What to do |
|---|---|---|
| **Refinement** | Both true, different scope | Add a qualifier to the existing line |
| **Supersession** | Same question, better evidence, later | Replace the line, keep the old source |
| **Contradiction** | One of them is wrong | Change nothing yet. Flag it and tell me. |

Appending a contradicting sentence to a note that still asserts the old claim is
worse than leaving the note wrong, because a note that says both things reads as
considered.

## Reporting back

After processing a batch, list: what you filed, what you flagged, and every field you
left as `unknown`. The `unknown` list is the useful part.
