---
type: topic
title: "Tm prediction — open questions"
status: active
updated: 2026-09-24
tags: [topic/thermostability]
---

# Tm prediction — open questions

My own running note. The agent may link here. It may not rewrite this.

## What I want to know

1. How much of the reported progress since 2021 survives a sequence-disjoint split?
2. Is any published predictor beating a mean predictor by more than the
   buffer-to-buffer spread of the measurement itself?
3. What would we have to measure in-house to answer (2) for our six proteins?

## Status
RK could not reproduce the headline numbers on our own proteins. Unresolved.
