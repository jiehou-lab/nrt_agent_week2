---
title: "BENCH-TM — Leaderboard"
source: "https://bench-tm.example.org/leaderboard"
author: "Lindqvist Lab"
published: 2026-09-15
created: 2026-10-02
description: "Current standings on the sequence-disjoint test split."
tags: [clippings]
---

# BENCH-TM — Leaderboard

Sequence-disjoint test split, 318 proteins. Lower is better.
**Mean-predictor baseline: 8.4 °C.**

| # | Method | Inputs | RMSE (°C) | Submitted |
|---|---|---|---|---|
| 1 | ThermoNet-2 + buffer | sequence, pH, I | **6.1** | 2026-04 |
| 2 | ThermoNet-2 + pH | sequence, pH | 6.9 | 2026-04 |
| 3 | Buffer only | pH, I | 7.4 | 2026-04 |
| 4 | TSP-Struct | structure | 7.6 | 2025-02 |
| 5 | ThermoNet-2 | sequence | 7.8 | 2025-02 |
| 6 | SeqTm | sequence | 8.1 | 2025-02 |
| — | *Mean predictor* | *—* | *8.4* | — |

## Note from the maintainers (2026-09)

Three of the six entries now use buffer covariates. We are **splitting the
leaderboard into two tables** from the next release, because a buffer-aware model
and a sequence-only model are not solving the same task and ranking them together
has already caused two papers to cite the 6.1 as a sequence-only result.

Entries 1–3 require buffer composition **at prediction time**. If you are
choosing between candidate sequences before you have chosen a buffer, entries
1–3 are not available to you and the relevant comparison is entry 5 against the
baseline.

## Reminder

Report the baseline with your number. A result quoted without 8.4 beside it is
not interpretable.
