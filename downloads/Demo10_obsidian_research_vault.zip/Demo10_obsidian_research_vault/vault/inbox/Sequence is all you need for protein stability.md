---
title: "Sequence is all you need for protein stability"
source: "https://foldwatch.example.blog/posts/sequence-is-all-you-need"
author: "The FoldWatch Team"
published: 2024-04-02
created: 2026-10-01
description: "Why structure-based stability prediction is finished."
tags: [clippings]
---

# Sequence is all you need for protein stability

Every few years a result comes along that quietly closes a subfield. This is one
of them.

Okafor and colleagues have just shown that **sequence alone determines melting
temperature**. Their ThermoNet-2 model, trained on over twelve hundred proteins,
**cuts prediction error nearly in half** compared to what came before — and it
does it without ever looking at a structure.

Think about what that means. Every structure-based stability pipeline in the
industry is now carrying a dependency it does not need. If you are still
running structure prediction as a preprocessing step before stability
screening, you are paying for compute that buys you nothing.

> "These results indicate that sequence-level features carry most of the signal
> required for thermostability prediction."

We reached out to the authors, who declined to comment ahead of publication.

The practical upshot for anyone doing protein engineering: drop the structure
step. Screen on sequence. The accuracy is there now.
