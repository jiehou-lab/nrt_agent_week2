---
title: "Machine learning approaches to protein thermostability: a critical review"
source: "https://www.journalofproteinengineering.example.com/article/S0022-2836(25)00114-7"
author: "R. Castellanos, Y. Abebe, J.-P. Rousseau"
published: 2025-07-11
created: 2026-10-01
description: "Review article. Journal of Protein Engineering, in press."
tags: [clippings]
---

# Machine learning approaches to protein thermostability: a critical review

R. Castellanos, Y. Abebe, J.-P. Rousseau
*Journal of Protein Engineering*, in press. doi:10.1016/jpe.2025.00114

## Abstract

Computational prediction of protein thermostability has advanced rapidly, but
reported accuracies vary by more than a factor of two between studies that
appear, on the surface, to evaluate the same task. We survey 47 published
predictors from 2015 to 2025 and show that most of this variance is explained
not by modelling choices but by three evaluation decisions: the unit of
splitting, the treatment of buffer conditions, and the choice of baseline. We
propose a minimal reporting standard and apply it retrospectively to the
surveyed literature.

---

## Access this article

**Subscribe** to the Journal of Protein Engineering to read the full text.

- Purchase PDF — USD 39.95
- **Institutional login** — check if your library subscribes
- Already a subscriber? Sign in

*Figures, tables and references are available to subscribers only.*

Related articles · Cited by (0) · Export citation
