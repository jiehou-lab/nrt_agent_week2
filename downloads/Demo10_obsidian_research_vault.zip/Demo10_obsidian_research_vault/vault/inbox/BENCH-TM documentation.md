---
title: "BENCH-TM — Documentation"
source: "https://bench-tm.example.org/docs/getting-started"
author: "Lindqvist Lab"
published: 2025-02-18
created: 2026-10-01
description: "Official documentation for the BENCH-TM sequence-disjoint benchmark."
tags: [clippings]
---

# BENCH-TM — Getting started

BENCH-TM is a sequence-disjoint benchmark for protein melting temperature
prediction. It accompanies Lindqvist & Boateng (2025), *Methods in Protein
Science* 12(1): 44-59.

## What makes it different

Most T<sub>m</sub> benchmarks split at the level of the **measurement record**.
Because one protein is often measured in several buffers, the same sequence
then appears in both the training and the test split. BENCH-TM clusters all
sequences at 30% identity and assigns whole clusters to one split.

## Contents

| File | Rows | Description |
|---|---|---|
| `bench_tm_train.csv` | 1,042 | Training records, 254 clusters |
| `bench_tm_test.csv` | 318 | Test records, 64 clusters |
| `buffers.csv` | 1,360 | Buffer composition per record |

## Required reporting

If you report a number on BENCH-TM, report it alongside:

1. The **mean-predictor baseline** (8.4 °C RMSE on the test split).
2. Your method's performance on its *own* original split, for comparison.
3. Whether buffer was used as an input feature.

## Units

All temperatures in BENCH-TM are in **degrees Celsius**. Submissions in Kelvin
are a common source of error; the scoring script rejects any prediction
outside 0–150.
