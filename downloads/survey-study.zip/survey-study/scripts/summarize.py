"""Mean satisfaction by condition for wave 1. Standard library only."""
import csv
from collections import defaultdict

totals = defaultdict(float)
with open("data/raw/wave1.csv") as f:
    rows = list(csv.DictReader(f))

for r in rows:
    totals[r["condition"]] += float(r["satisfaction"])

for condition, total in sorted(totals.items()):
    print(f"{condition:10s} mean satisfaction = {total / len(rows):.2f}")
