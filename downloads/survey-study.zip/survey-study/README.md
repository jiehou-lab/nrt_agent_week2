# Survey Study 3 — practice project

Practice material for the Claude Code field guide (NRT Hot Topics).
**All data here is synthetic.** Nothing describes real people.

The notes describe what the data *should* look like. The data does not
quite match — on purpose. Finding the differences is your first task with
Claude. Please don't fix anything by hand.

| Path | What it is |
|------|------------|
| notes.md | the lab's notes: how the study was designed and what the data should look like |
| data/raw/wave1.csv | 48 survey responses (treat as read-only) |
| data/raw/wave2.csv | follow-up responses (treat as read-only) |
| scripts/summarize.py | a short analysis script (standard library only) |
| examples/ | three files you read in Part 5 and install in Part 8 |

Set it up once:

```bash
mkdir -p ~/projects && cd ~/projects
unzip ~/Downloads/survey-study.zip
cd survey-study
git init && git add -A && git commit -m "Starting point"
```
