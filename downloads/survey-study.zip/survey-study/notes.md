# Study 3 notes

Pilot survey, two waves, spring 2024.

- Planned sample: **48 participants**, each with a unique ID (P001–P048).
- Eligibility: **18 or older**. Consent date recorded for everyone.
- Conditions: `control` and `treatment`, assigned alternately.
- Satisfaction: 5-point scale, **1 (low) to 5 (high)**.
- Hours online per week: self-reported.
- Wave 2 re-contacts wave 1 participants only.
- Dates are recorded as YYYY-MM-DD.

## To do
- Clean wave 1 and document every change.
- Summarize satisfaction by condition (scripts/summarize.py).
