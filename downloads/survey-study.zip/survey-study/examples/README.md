# Examples

Three files explained in Part 5 of the field guide ("Anatomy of ..." slides).
Read them there. You install them in Part 8 — until then they do nothing,
because Claude Code only looks for them in specific places.

| File | Explained on | Installed to |
|------|--------------|--------------|
| CLAUDE.md | Anatomy of CLAUDE.md | the project root |
| agents/data-checker.md | Anatomy of an agent definition | .claude/agents/ |
| skills/cleaning-log/SKILL.md | Anatomy of a skill | .claude/skills/ |

To install all three (Part 8), from inside survey-study/:

```bash
cp examples/CLAUDE.md .
mkdir -p .claude/agents .claude/skills
cp examples/agents/data-checker.md .claude/agents/
cp -r examples/skills/cleaning-log .claude/skills/
```
