# Survey Study 3
Pilot survey, two waves, spring 2024.
Synthetic practice data.

## Conventions
- Python, standard library only
- Cleaned data goes in data/clean/
- Log every cleaning step in docs/cleaning_log.md

## Do not
- Do not modify anything in data/raw/
- Do not install packages
- Do not delete files
