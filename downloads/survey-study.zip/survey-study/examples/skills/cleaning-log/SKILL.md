---
name: cleaning-log
description: How to record every change made
  while cleaning a data file
---

# Cleaning log
For each change, add a row to
docs/cleaning_log.md:

| date | file | row | rule broken | action |

Never change a row without a log entry.
If the right fix is unclear, stop and ask.
