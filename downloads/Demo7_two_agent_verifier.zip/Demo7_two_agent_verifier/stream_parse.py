#!/usr/bin/env python3
"""Turn Claude Code's streaming output into a list of steps we can draw.

`claude -p --output-format stream-json --verbose` emits one JSON object per
line. The exact shape has changed across versions, so this parser is written to
be forgiving: it looks for the things it recognises and labels everything else
`unknown` rather than throwing. A trace that renders imperfectly is far better
than an app that crashes on an unfamiliar event.

Every step is a plain dict:

    {"kind": "text",        "text": ...}
    {"kind": "tool_use",    "name": ..., "input": {...}}
    {"kind": "tool_result", "text": ..., "is_error": bool}
    {"kind": "result",      "text": ..., "raw": {...}}
    {"kind": "unknown",     "raw": {...}}

Every step also carries "parent": the value of `parent_tool_use_id` on the event
it came from. Messages from a subagent carry the id of the Agent tool call that
started them; messages from the main conversation carry None. `agent_lanes()`
uses that to separate who did what.
"""
import json


def _blocks(msg):
    """Content blocks out of an Anthropic-style message, whatever the nesting."""
    if not isinstance(msg, dict):
        return []
    content = msg.get("content")
    if content is None and isinstance(msg.get("message"), dict):
        content = msg["message"].get("content")
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    return content if isinstance(content, list) else []


def parse_event(obj):
    """One JSON object -> zero or more steps."""
    steps = []
    if not isinstance(obj, dict):
        return [{"kind": "unknown", "raw": obj}]

    etype = obj.get("type")
    parent = obj.get("parent_tool_use_id")

    # the final summary object
    if etype == "result":
        steps.append({"kind": "result",
                      "text": obj.get("result") or obj.get("text") or "",
                      "raw": obj})
        return steps

    # assistant / user turns carry the interesting blocks
    for b in _blocks(obj) or _blocks(obj.get("message")):
        if not isinstance(b, dict):
            continue
        bt = b.get("type")
        if bt == "text" and b.get("text", "").strip():
            steps.append({"kind": "text", "text": b["text"]})
        elif bt == "tool_use":
            steps.append({"kind": "tool_use",
                          "name": b.get("name", "?"),
                          "id": b.get("id"),
                          "input": b.get("input", {})})
        elif bt == "tool_result":
            c = b.get("content")
            if isinstance(c, list):
                c = "\n".join(x.get("text", "") for x in c if isinstance(x, dict))
            steps.append({"kind": "tool_result",
                          "text": c if isinstance(c, str) else json.dumps(c, indent=2),
                          "is_error": bool(b.get("is_error"))})
        elif bt == "thinking" and b.get("thinking"):
            steps.append({"kind": "text", "text": b["thinking"]})

    if not steps and etype not in ("system", "stream_event", None):
        steps.append({"kind": "unknown", "raw": obj})
    for st in steps:
        st.setdefault("parent", parent)
    return steps


def parse_lines(lines):
    """Iterate steps from newline-delimited JSON. Bad lines are skipped."""
    for line in lines:
        line = (line or "").strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        for step in parse_event(obj):
            yield step


def summarise(steps):
    calls = [s for s in steps if s["kind"] == "tool_use"]
    errors = [s for s in steps if s["kind"] == "tool_result" and s.get("is_error")]
    return {"n_steps": len(steps), "n_tool_calls": len(calls),
            "tools": [c["name"] for c in calls], "n_errors": len(errors)}



# ------------------------------------------------------------ who did what

AGENT_TOOLS = ("Agent", "Task")


def _agent_name(step):
    """Best guess at which subagent an Agent/Task call started."""
    inp = step.get("input") or {}
    for key in ("subagent_type", "agent", "agent_type", "name"):
        v = inp.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    d = inp.get("description")
    return d.strip()[:40] if isinstance(d, str) and d.strip() else "subagent"


def agent_lanes(steps):
    """Split a trace into [(lane_name, [steps])] in the order the lanes opened.

    The main conversation is one lane; each subagent the main agent started is
    another. Steps are matched to a lane by `parent`, which is the id of the
    Agent tool call that spawned them.
    """
    names = {}
    for st in steps:
        if st.get("kind") == "tool_use" and st.get("name") in AGENT_TOOLS and st.get("id"):
            names[st["id"]] = _agent_name(st)

    order, lanes = [], {}
    for st in steps:
        key = st.get("parent")
        if key not in lanes:
            lanes[key] = []
            order.append(key)
        lanes[key].append(st)

    out = []
    for key in order:
        if key is None:
            label = "main agent"
        else:
            label = names.get(key, "subagent")
        out.append((label, lanes[key]))
    return out
