# Demo 7 — an analyst, and something that checks the analyst

Demo 5's app and server, plus two scoped subagents:

    .claude/agents/tissue-analyst.md    measures and labels, then reports
    .claude/agents/tissue-verifier.md   decides whether the report may be recorded

## Run it

    unzip Demo7_two_agent_verifier.zip
    cd Demo7_two_agent_verifier
    claude

Then:

    Use the tissue-analyst subagent to analyze
    data/case_fold_artifact_histology.pgm at 20x magnification with
    damage_threshold_fraction 0.45.
    Then use the tissue-verifier subagent to check the analyst's report
    before I record it as a finding.

For the app:

    python3 -m venv .demo_venv && source .demo_venv/bin/activate
    pip install -r requirements.txt
    ./run.sh          # Path C is the new tab

Path C has a **Replay** button that renders a recorded two-agent run, so the
demo works with no Claude Code and no tokens.

## The point

The verifier ships as `v1_asks_again.md`: it re-runs the analysis and compares.
That is what most people build, and on the fold-artifact slide it returns
**confirmed** — because it asked the same classifier the same question and got
the same answer.

`v2_checks_the_file.md` has exactly one tool, `check_report`, and cannot run the
analysis at all. It can only compare what the report claimed against the JSON on
disk. It rejects the same report.

    cp docs/verifier_versions/v2_checks_the_file.md .claude/agents/tissue-verifier.md

A check only helps if it can fail differently from the thing it is checking.

Full guide: https://jiehou-lab.github.io/nrt_agent_week2/guides/demo7.html
