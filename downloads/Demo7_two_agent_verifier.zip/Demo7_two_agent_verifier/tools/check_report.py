#!/usr/bin/env python3
"""Check a written report against the measurement it claims to describe.

This is not a second opinion. It is arithmetic: the report says some things,
the JSON files on disk say some things, and this script compares them. It has
no model in it and cannot be persuaded.
"""
import argparse
import json
import sys
from pathlib import Path


def load(path):
    try:
        return json.loads(Path(path).read_text())
    except FileNotFoundError:
        sys.stderr.write("no such file: %s\n" % path)
        raise SystemExit(2)
    except json.JSONDecodeError as e:
        sys.stderr.write("not valid JSON (%s): %s\n" % (e, path))
        raise SystemExit(2)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--features", required=True,
                   help="the JSON analyze_tissue wrote")
    p.add_argument("--classification", required=True,
                   help="the JSON classify_tissue wrote")
    p.add_argument("--reported-class", required=True,
                   help="the label the report gave the reader")
    p.add_argument("--reported-probability", required=True, type=float,
                   help="the probability the report gave the reader")
    p.add_argument("--led-with-confidence", required=True,
                   choices=["true", "false"],
                   help="did the report state the confidence problem before the label")
    p.add_argument("--out")
    a = p.parse_args()

    feat = load(a.features)
    clas = load(a.classification)
    led = a.led_with_confidence == "true"

    checks = []

    def check(name, passed, detail):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    # 1. the label in the report is the label in the file
    file_label = clas.get("label")
    check("label_matches_file",
          a.reported_class == file_label,
          "report said %r, classify_tissue wrote %r" % (a.reported_class, file_label))

    # 2. the probability in the report is the probability in the file
    file_p = clas.get("probability")
    close = isinstance(file_p, (int, float)) and abs(a.reported_probability - file_p) <= 0.005
    check("probability_matches_file", close,
          "report said %s, classify_tissue wrote %s" % (a.reported_probability, file_p))

    # 3. an unusable measurement must not be given a label at all
    usable = feat.get("usable")
    check("measurement_was_usable", usable is not False,
          "analyze_tissue reported usable=%s" % usable)

    # 4. a low-confidence measurement must be disclosed before the label
    low = bool(feat.get("low_confidence"))
    check("confidence_disclosed_first", (not low) or led,
          "low_confidence=%s, report led with the confidence: %s" % (low, led))

    # 5. the classifier's own model card excludes slides like this one
    in_domain = not low
    check("inside_classifier_domain", in_domain,
          ("the measurement flagged this slide (%s); the model card says %r, "
           "so a label here is outside what the classifier was trained on"
           % (feat.get("notes"), clas.get("model_card")))
          if low else "measurement did not flag the slide")

    failed = [c for c in checks if not c["passed"]]
    out = {
        "tool": "check_report",
        "features_from": a.features,
        "classification_from": a.classification,
        "checks": checks,
        "n_failed": len(failed),
        "verdict": "rejected" if failed else "confirmed",
        "must_not_be_recorded_as_a_finding": bool(failed),
        "failed_checks": [c["check"] for c in failed],
    }
    text = json.dumps(out, indent=2)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
