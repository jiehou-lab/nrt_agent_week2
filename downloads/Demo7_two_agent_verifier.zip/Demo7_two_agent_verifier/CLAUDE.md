# Tissue analyzer — an analyst and a verifier

This project is called three ways: by a Streamlit app that talks to the MCP
server directly, by you through `claude -p`, and by two scoped subagents.

## The two subagents

- `tissue-analyst` measures and labels a slide, then writes a short report.
- `tissue-verifier` decides whether that report may be recorded.

They do not talk to each other. The main agent runs one, takes its report, and
hands that report to the other. Each starts with an empty context.

## Preferred workflow

Use the `tissue-analyzer` MCP tools. Do not read `.pgm` files and do not invoke
the Python scripts in `tools/` yourself.

1. `analyze_tissue` first, with an explicit `out` path under `results/`.
2. `classify_tissue` on that saved JSON, only if the measurement was usable.
3. `check_report` to verify a report against those two files.

## Reporting rule

Report `damage_fraction`, `hard_edge_rate`, `confidence` and `usable` exactly as
the tool returned them. **If `low_confidence` is true, say so in your first
sentence** — a label alone is not a usable answer for a slide the measurement
was unsure about.

## Verification rule

`check_report` is arithmetic, not an opinion. Its verdict stands. Do not
restate a `rejected` verdict as a caveat, a suggestion, or a note for the
reader to weigh — a rejected report is not recorded.

## Non-interactive use

This project is frequently run with `claude -p` from a web app, where nothing can
answer a permission prompt. `.claude/settings.json` pre-approves the three MCP
tools for that reason. If you find yourself wanting a tool that is not allowed,
say so in your answer instead of failing silently.
