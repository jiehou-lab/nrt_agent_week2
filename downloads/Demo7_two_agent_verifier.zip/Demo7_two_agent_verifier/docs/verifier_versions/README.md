# Two verifiers

The package ships with `v1_asks_again.md` installed. It is not a strawman —
it is the design most people write first, and it is rigorous in the way people
usually mean by rigorous: it does the work again, independently, and compares.

    cp docs/verifier_versions/v1_asks_again.md    .claude/agents/tissue-verifier.md
    cp docs/verifier_versions/v2_checks_the_file.md .claude/agents/tissue-verifier.md

Run the fold-artifact slide through both and watch what happens. The difference
is not effort or care. It is that v1 can form its own opinion and v2 cannot.
