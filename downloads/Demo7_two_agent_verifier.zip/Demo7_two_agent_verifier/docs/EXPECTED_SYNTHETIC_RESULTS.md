# Expected synthetic-image demo results

| Image | Damage fraction | Edge rate | Expected class | Model probability |
|---|---:|---:|---|---:|
| `case_normal_histology.pgm` | 0.104 | 0.014 | `normal` | 0.806 |
| `case_mild_injury_histology.pgm` | 0.220 | 0.042 | `mild_injury` | 0.700 |
| `case_necrosis_histology.pgm` | 0.476 | 0.076 | `necrosis` | 0.943 |
| `case_fold_artifact_histology.pgm` | 0.234 | 0.170 | `mild_injury` | 0.700 |

---

## Demo 7 — `check_report`

Run on the fold-artifact slide at 20x, threshold 0.45. `analyze_tissue` gives
`damage_fraction` 0.234, `hard_edge_rate` 0.17, `confidence` 0.55,
`low_confidence` **true**, `usable` true, notes *"elevated edge rate - possible
fold or tear"*. `classify_tissue` gives **mild_injury, 0.7**.

What `check_report` returns for four different reports of that same slide:

| the report claimed | verdict | failed checks |
|---|---|---|
| mild_injury 0.7, label first | `rejected` | `confidence_disclosed_first`, `inside_classifier_domain` |
| mild_injury 0.7, caveat first | `rejected` | `inside_classifier_domain` |
| necrosis 0.99 | `rejected` | `label_matches_file`, `probability_matches_file` |

On a clean slide — case_necrosis_histology at the same settings,
`low_confidence` false, classifier **necrosis, 0.943**:

| the report claimed | verdict |
|---|---|
| necrosis 0.943 | `confirmed` |
| necrosis 0.91 | `rejected` (`probability_matches_file`) |

Note the second row of the first table. Wording the report better does not make
the fold slide reportable: the classifier's model card says *clean slides only;
folds, tears and pen marks excluded*, so a label on this slide is outside what
the model was trained on however carefully it is phrased. The honest report says
the slide cannot be classified by this model.

The schema refuses before any of this: `reported_probability` of `94` is
rejected as out of range, and `led_with_confidence` of `"yes"` is rejected
because the enum is `"true"` / `"false"`.

