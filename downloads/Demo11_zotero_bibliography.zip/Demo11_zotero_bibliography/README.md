# Demo 11 — Zotero: a bibliography the agent checks itself

**Level:** anyone who finished Week 3. Pairs with Demo 10.
**Time:** 30–40 minutes.

---

## Three corrections before you start

Most tutorials on connecting Zotero to Claude Code say roughly the same seven
steps. Three of them are worth questioning.

**1. You probably do not want the web API.** The usual instructions have you
create a Zotero API key, paste it into `.mcp.json`, and reach your library over
`api.zotero.org`. That works. It also means a password-equivalent key sitting in
a file, and your library being read through Zotero's servers. Zotero has had a
**local** API since version 7 — Settings → Advanced → *"Allow other applications
on this computer to communicate with Zotero"* — at `http://localhost:23119/api/`,
with **no key at all**. `zotero-mcp` reaches it with `ZOTERO_LOCAL=true`.
See `APPENDIX_live_zotero.md`.

**2. The MCP server cannot organise your library.** `zotero-mcp` exposes three
tools: search items, get metadata, get full text. All three are reads. It cannot
add a tag, create a collection, fix a year or merge a duplicate. Anything you have
read that implies otherwise is describing something it does not do.

So "use an agent to manage my Zotero library" resolves into: **the agent reads the
library and writes files beside it.** You apply the changes in Zotero. That is a
weaker claim than the tutorials make and it is the honest one — and in practice
it is also the one you want, because it keeps a human between the agent and ten
years of references.

**3. You do not need any of it to start.** A Zotero library on disk is a `.bib`
export, a `.csv` export, and a `storage/` folder of PDFs. That is what this demo
uses. No account, no key, no MCP, no Zotero installed, works offline.

## What this demo is about

Not "find me papers." The question underneath:

> A bibliography is a set of **promises** — that each work exists, says what you
> say it says, and is where you say it is. **Which of those can an agent check,
> and which can only you?**

`library/` is a small Zotero library with the kind of damage every real library
has. Nine entries, six attachment folders, and the three views of it — the `.bib`,
the `.csv` and `storage/` — disagree with each other in five places.

You will build a topic bibliography from it, then run a second agent over your own
output. The second agent has **no `Write` tool**: it can report that a citation is
wrong, and it cannot quietly fix it.

## Layout

```
library/
├── CLAUDE.md               the contract — read it first
├── .claude/
│   ├── settings.json       the library itself is read-only
│   └── agents/
│       ├── scout.md        find candidates, report what you opened
│       └── citecheck.md    verify the output. no Write tool.
├── My Library.bib          Better BibTeX export
├── My Library.csv          Zotero CSV export — carries the item keys
├── storage/                attachments, one folder per item key
├── bib/                    your output goes here
└── _templates/bibliography.md
```

## Run it

```bash
cd library
git init && git add -A && git commit -m "before the agent"
claude
```

Then the five prompts in `SETUP.md`.

## Files

| File | What it is |
|---|---|
| `SETUP.md` | The five prompts, and what to watch for |
| `APPENDIX_live_zotero.md` | Connecting to a real Zotero, locally, with no API key |
| `ANSWER_KEY.md` | **After you have run it.** Everything wrong with the library. |

## Relationship to Demo 10

Same literature, deliberately. Demo 10 is the **notes**: what you thought about
what you read. Demo 11 is the **library**: what you have and whether you can cite
it. If you did Demo 10, you already know the ThermoNet-2 abstract does not match
its own table — so this demo can spend its time on the library instead of the
papers.

They compose: Zotero holds the PDFs, the vault holds the thinking, and the agent
reads both and writes only to the vault.
