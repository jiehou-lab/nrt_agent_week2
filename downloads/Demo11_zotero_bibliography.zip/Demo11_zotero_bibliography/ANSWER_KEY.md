# Answer key — what is wrong with this library

**Read after running the demo.**

Nine entries. Six attachment folders. Eight defects, all of them things that
happen to real libraries through ordinary use rather than carelessness.

---

## The five reconciliation failures (Prompt 1)

### 1. Broken attachment — `tanaka1998calorimetry` / item `P5HD6ZXN`
The entry points at `storage/P5HD6ZXN/Tanaka and Mori - 1998 - Calorimetric
measurement.pdf`. **That folder does not exist.** The citation is in the library;
the paper is not reachable through it.

### 2. The same PDF, under a junk entry — item `TD53BV9K`
`@misc{scan0043}` — title `scan0043`, no author, no journal, year 2026, item type
`document`. Its attachment is **the Tanaka paper**.

Defects 1 and 2 are one event: the PDF was dragged in (producing a junk entry
named after the scanner's filename) and the citation was typed separately
(producing a correct entry with a dead link). The library contains the paper
twice and can cite it zero times.

*Catching either alone is half marks. Noticing they are the same document is the
finding.*

### 3. Orphaned attachment — `storage/9FGM2XPQ/`
A folder no entry in either export claims. It holds **the ThermoNet-2
Supplementary Information**, and it is the most valuable document in the library:

> *"148 of the 212 unique sequences (69.8%) appear in both the training and the
> test split."*

| Held-out records | n | RMSE |
|---|---|---|
| Sequence also seen in training | 198 | 4.1 °C |
| **Sequence not seen in training** | **43** | **8.0 °C** |
| All held-out records | 241 | 4.9 |

That 8.0 is the authors' own data, in their own supplement, confirming the
7.8 °C that Lindqvist & Boateng get independently. **Every bibliography built
from the `.bib` misses it**, because the `.bib` does not know it exists. This is
the reason the audit runs before the search, and the single best argument in the
package for reconciling `storage/` back against the exports.

### 4. Spurious duplicate — `okafor2024thermonet2` vs `okafor2024ThermoNet`
Two entries, **the same DOI** (`10.4821/jcb.2024.0288`). One imported cleanly;
one typed by hand from a conference programme, with the wrong year (2023),
title-case mangled, no attachment, and a `note` field that says
*"added by hand from the conference programme -- check before citing"*.

Distinguish this from #5. This is one paper recorded twice — one record should go.

### 5. Genuine near-duplicate — `okafor2023preprint`
The bioRxiv preprint of the same study. **Both entries should stay** and be
cross-referenced; they are different documents reporting different numbers
(4.4 °C on n=1,510 vs 4.9 °C on n=1,204). An agent that merges this one has
destroyed information.

A good run separates #4 from #5 and says why. Treating both as "duplicates" is
the common failure.

---

## The three content defects

### 6. Metadata contradicts its own PDF — `lindqvist2024bench` / `R2M9VKHT`
The export says **2024, bioRxiv, doi 10.1101/2024.06.03.597112**.
The attached PDF is **2025, Methods in Protein Science 12(1): 44–59,
doi 10.3310/mps.2025.0044**.

The `Extra` column in the CSV says it outright: *"replaced attachment with
published version 2026-06-30"*. The file was updated; the metadata never was.
Cite this from the `.bib` and you cite a preprint that has been superseded, with
the wrong year, wrong venue and wrong DOI.

Note the cite key itself is now wrong — `lindqvist2024bench` for a 2025 paper.

### 7. Wrong item type — `ferrara2022assays`
A journal article entered as `@book`, with the journal name in the `publisher`
field. Any citation style will render it as a book: no volume, no issue, no
pages, wrong punctuation. Nothing in the text is false; the *shape* is wrong, and
it is wrong silently at the point where it reaches a reviewer.

### 8. Publisher marketing as the abstract — `barros2021seqtm`
The `abstract` field reads:

> *"A landmark contribution to the field. Protein Science Letters is the leading
> venue for rapid communications in protein biophysics, with an impact factor of
> 6.2 and a median time to first decision of 21 days. Submit your work today."*

Scraped from the journal's landing page. It describes the journal, not the paper.
There is **no attachment**, so an agent working from metadata alone has nothing
else to go on — and this text is confident enough to summarise.

`barros2021seqtm` must be cited `[metadata only — not read]` or not at all. It is
the baseline every other paper in the library compares against, so leaving it out
entirely is also wrong.

Also note `nilsson2023tspstruct`: title `TSP-Struct`, no journal, no DOI, no
pages. It is the method that actually beats ThermoNet-2 in ThermoNet-2's own
table, and it is a stub.

---

## The answer Prompt 5 is looking for

Something close to:

> On a record-level split, ThermoNet-2 reports RMSE 4.9 °C (`4J8KQW2M`, Table 2).
> On records whose sequences do not appear in training, the authors' own
> supplement reports 8.0 °C (`9FGM2XPQ`, Table S3), and an independent
> sequence-disjoint benchmark reports 7.8 °C against a mean-predictor baseline of
> 8.4 °C (`R2M9VKHT`, Table 3). The margin over predicting the average is
> therefore under one degree, smaller than the 2–9 °C shift that buffer
> composition alone produces (`8QW4LJ3F`).

Four sources, all verifiable, no claim beyond them. **It is not reachable without
finding the orphan**, which is the point of the whole demo.

A run that produces a confident "sequence-only methods now match structure-based
methods" has cited the abstracts and skipped the audit.

---

## What Prompt 6 should reveal

A generic outline for this topic has roughly eight sections. Here is what this
library can and cannot carry:

| Section | Supported by | Verdict |
|---|---|---|
| Introduction / why thermostability matters | — | **Generic.** Written from outside the library. |
| Measuring thermal stability | `8QW4LJ3F` (full text), `TD53BV9K` (the junk entry — it is the 1998 reference values) | **Grounded.** Two sources, one of which is only findable by fixing defect 2. |
| Sequence-based predictors | `4J8KQW2M`, `N7XC3BQD` (full text); `C8VJ2RWD` metadata only | **Grounded, with a hole** — the baseline everything compares to has no attachment and a marketing blurb for an abstract. |
| Structure-based predictors | `H4KX7MBT` only | **Not grounded.** The method that actually beats ThermoNet-2 in its own table is a stub: title, author, year, nothing else. A section every review has, and this library cannot write it. |
| Evaluation and benchmarking | `R2M9VKHT` (full text) **and `9FGM2XPQ`** | **The strongest section in the review** — and it needs the orphan. Without prompt 1, this section rests on one paper instead of two, and loses the authors' own confirmation of their critic. |
| Energy / applications / engineering | — | **Generic.** Nothing in the library. |
| Open problems | — | **Generic**, unless it is written from the gap between 4.9 and 7.8, in which case it is the best-grounded section of all. |
| Future directions | — | **Generic.** |

So: **three grounded, one hollow, four generic.** On an eight-section outline
that looked complete.

That ratio is the finding. It is not a criticism of the agent — it is an
accurate picture of a nine-entry library, and no outline generated from training
data would have told you the structure-based section was empty.

**The two things to say out loud:**

1. *Every section was plausible. Only three were ours.* An outline is not
   evidence that anything was read.
2. *The best section depends on a file no entry in the library points to.* An
   agent that searches before it audits never finds `9FGM2XPQ`, writes a good
   benchmarking section from `R2M9VKHT` alone, and never knows what it missed.

**A run that marks nothing as generic has failed this prompt** — not because the
outline is wrong, but because it is claiming library support it does not have.
That is the same error as the paywall stub in Demo 10, one level up.

---

## Scoring

| Caught | Reading |
|---|---|
| 0–2 | It treated the `.bib` as the library. Most first runs. |
| 3–4 | It reconciled one direction — exports to files, but not files back to exports. |
| 5–6 | It reconciled both directions and found the orphan. |
| 7–8 | It also separated the real near-duplicate from the spurious one. |

## Which layer catches what

| Defect | What catches it |
|---|---|
| 1, 2, 3 | Reconciling in **both** directions — a `CLAUDE.md` instruction |
| 4, 5 | Comparing DOIs and item keys rather than titles |
| 6 | "The PDF wins over the metadata" — a `CLAUDE.md` rule, then `citecheck` |
| 7 | Nothing automatic. A human who knows what a `@book` renders like. |
| 8 | The `[metadata only]` rule, enforced by `citecheck` having no `Write` tool |
| Library damage | `settings.json` — the only thing that makes edits impossible |

Defect 7 is the honest one to end on. No layer in this package catches it. A
`@book` that should be an `@article` is well-formed, internally consistent, and
wrong — and the person who notices is the one who has seen a reference list come
back from a copy editor.
