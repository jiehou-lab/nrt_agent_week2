# Setup and run

## 0. What you need

- **Claude Code**, working.
- **`pdftotext`** — more useful here than in Demo 10, because you will be reading
  six PDFs looking for specific numbers.
  - macOS `brew install poppler` · Ubuntu `sudo apt install poppler-utils`
- **Zotero** — *not required*. See `APPENDIX_live_zotero.md` if you want to point
  this at your own library afterwards.

## 1. Look at the library before the agent does

```bash
cd library
ls
cat "My Library.bib" | head -30
column -s, -t < "My Library.csv" | cut -c1-120
ls storage/
```

Nine entries in the exports. **Six folders in `storage/`.** That gap is the demo.

Make your undo button:

```bash
git init && git add -A && git commit -m "before the agent"
```

## 2. Read the contract

```bash
cat CLAUDE.md
cat .claude/settings.json
```

The deny list is the point of this one:

```json
"deny": [
  "Edit(./storage/**)", "Write(./storage/**)",
  "Edit(./My Library.bib)", "Write(./My Library.bib)",
  "Edit(./My Library.csv)", "Write(./My Library.csv)",
  "Bash(rm:*)", "Bash(mv:*)"
]
```

**The library is read-only and the agent cannot change that.** Not "please don't
edit my references" in `CLAUDE.md` — a rule that is checked before the tool runs.
A reference manager is the system of record for someone's entire reading life.
The agent proposes into `bib/`; you apply changes in Zotero yourself.

`Bash(mv:*)` is denied too. Without it, "tidy up `storage/`" is one plausible
command away from a library whose attachments no longer resolve.

---

# The six prompts

Run `claude` in `library/`.

### Prompt 1 — audit before anything else

```
Reconcile My Library.bib, My Library.csv and the storage/ folder.
Report every place the three disagree. Change nothing.
```

There are five. Write down how many it finds: ______

One of them is a folder in `storage/` that no entry claims. It contains the single
most useful document in this library, and every bibliography built from the `.bib`
will miss it.

### Prompt 2 — search

```
Use the scout subagent to find everything in this library that bears on:
"does sequence-only Tm prediction actually beat a trivial baseline
on proteins the model has not seen?"
```

Watch whether it opens the PDFs or ranks on titles. The question cannot be
answered from titles — the numbers that settle it are in a table in one paper and
a supplementary note in another.

### Prompt 3 — build it

```
Write a bibliography for that question into bib/, using _templates/bibliography.md.
```

Then read it yourself before going on. Check three things by hand:
- Is every cite key in it actually in `My Library.bib`?
- Is anything cited that has no attachment, without the `[metadata only]` mark?
- Does the duplicate appear twice?

### Prompt 4 — check the agent's homework

```
Use the citecheck subagent to verify bib/<the file it wrote>.
```

`citecheck` has **no `Write` tool**. It can tell you a claim is unsupported; it
cannot make the problem disappear. Read its `cannot verify` rows most carefully —
that is where an honest agent admits the library does not contain what the
bibliography promises.

### Prompt 5 — the thing a bibliography is for

```
Based only on what you verified, write three sentences I could put in a paper
about the state of sequence-only Tm prediction. Cite the item key for each claim.
```

If those three sentences are hedged and short, the library did its job. If they
are confident, check them against `ANSWER_KEY.md`.

### Prompt 6 — the review outline, and the test that matters

This is the thing most "Claude Code + Zotero" posts stop at. Do it in three
moves, and the third is the demo.

**a. Ask for what everyone asks for:**

```
Write a literature review outline on sequence-only Tm prediction,
with sections.
```

You will get something like: *Introduction · Measuring thermal stability ·
Sequence-based predictors · Structure-based predictors · Evaluation and
benchmarking · Open problems*. It will look good.

**b. Now ask the question nobody asks:**

```
For each section of that outline, list the item keys from My Library.csv
that actually support it, and whether you read the full text or only the
metadata. Mark any section you could have written without my library at all.
```

Count how many sections survive: ______ out of ______

**c. Write it down, with the grounding table:**

```
Write the outline and that grounding table to bib/review_outline.md
using _templates/review_outline.md. Finish with the sections this library
cannot support.
```

**Why this matters.** An eight-section outline on a well-known topic is
something a model can produce from training data alone — no library, no PDFs,
no Zotero. The output looks identical whether it read your library or recalled
the field, and you cannot tell by looking.

The **item key** is what settles it. `4J8KQW2M` is an eight-character string
that exists only in *your* library. It cannot be recalled; it can only be read.
Either the agent names one and you can check it, or it cannot — and that is the
difference between a research assistant and a confident-sounding one.

The last section of the template — *what this library cannot support* — is the
most useful output in this whole demo. It is a reading list.

```bash
git diff --stat
```

Only `bib/` should have changed. If anything else did, the deny list has a hole —
tell us which one.

---

## Afterwards

1. `cat ANSWER_KEY.md`, count what was caught.
2. For each miss: **which layer should have caught it?** A line in `CLAUDE.md`, a
   rule in `settings.json`, or a tool the agent should not have had. Change that
   one file, `git checkout .`, run again.
3. Then try `APPENDIX_live_zotero.md` on your own library — read-only, locally,
   with no API key.

## Using this on your own library

The transferable parts are `CLAUDE.md`, `.claude/` and the habit of exporting
rather than connecting. From Zotero: select a collection → right-click →
*Export Collection* → Better BibTeX (tick *Export Files*) and again as CSV. You
now have exactly the shape in `library/`, for one project, with nothing live
attached to it.

Start there. Add the MCP server later, if you find you need it.
