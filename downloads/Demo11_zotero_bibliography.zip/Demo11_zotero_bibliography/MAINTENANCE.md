# Living with the library

`SETUP.md` runs the exercise once. This is the part that repeats.

---

## The rule that never changes

**The library is read-only. Forever.**

`storage/`, `My Library.bib` and `My Library.csv` are denied in
`.claude/settings.json`, and you should treat them the same way by hand. The
agent proposes into `bib/`; **you** apply changes in Zotero.

A reference manager is the system of record for someone's entire reading life.
An agent editing it in place is how a decade of citations gets quietly
corrupted, and you will not notice until a reference list comes back from a
copy editor.

---

## Refreshing the export — the routine that matters most

Do this whenever you have added papers to Zotero, and **always after a session
of cleaning up metadata.**

### In Zotero

1. Select the collection (or *My Library* for everything).
2. Right-click → **Export Collection…**
3. Format: **Better BibTeX**. Tick **Export Files**.
4. Export again as **CSV**.

### On disk

```bash
cd ~/research-system/Demo11_zotero_bibliography/library
git add -A && git commit -m "before re-export"     # always
```

Then replace **all three together**: the `.bib`, the `.csv`, and `storage/`.

> **Replace them as a set or not at all.** A new `.csv` against an old
> `storage/` produces exactly the broken-attachment symptoms this demo is built
> from. This is the single most common way a working setup breaks.

### Immediately after, reconcile

```
Reconcile My Library.bib, My Library.csv and the storage/ folder.
Report every place the three disagree. Change nothing.
```

Expect findings. Zotero does not promise these three views agree, and they
drift every time you merge a duplicate, replace an attachment, or fix a year.

---

## Before writing any bibliography

Two prompts, in this order, every time:

```
Reconcile the three views. Change nothing.
```
```
Use the scout subagent to find everything bearing on: <your question>
```

**Auditing before searching is not optional.** The orphaned attachment in this
demo — a folder in `storage/` that no entry claims — holds the most important
number in the whole library, and it is invisible to any search that starts from
the `.bib`. In a real library, orphans are usually supplements, author
manuscripts and figures: exactly the things you cannot cite and most want.

Then, always:

```
Use the citecheck subagent to verify bib/<the file>.
```

`citecheck` has no `Write` tool. Read its `cannot verify` rows most carefully —
that is where an honest agent admits the library does not contain what the
bibliography promises.

---

## Adding to the library

### A new paper
Add it **in Zotero**, by DOI or arXiv ID — *Add Item by Identifier*. Zotero
fetches metadata from the publisher, which is better than anything an agent
assembles and is the entire point of using a reference manager. Then re-export.

### A PDF with no metadata
Drag it into Zotero, then **fix the item before re-exporting**. A dragged-in
PDF produces an item titled after the scanner's filename — `scan0043` — and
that junk entry is one of the planted defects here precisely because it is so
common.

### A supplement, an author manuscript, a figure
Attach it to the **existing item** in Zotero rather than adding it separately.
A supplement added as its own file in `storage/` with no item is the orphan
case, and it means the best evidence you own cannot appear in any reference
list.

---

## The quarterly clean-up

Four checks, maybe twenty minutes:

```
1. Which entries have a file path that does not exist?
2. Which folders in storage/ belong to no entry?
3. Which entries share a DOI?
4. Which entries have no DOI and no attachment?
```

For each, the fix is **in Zotero**, not here:

| Finding | What to do in Zotero |
|---|---|
| Broken file path | Re-attach the PDF, or remove the dead link |
| Orphan in `storage/` | Add it as an attachment to the right item |
| Duplicate DOI | *Duplicate Items* in the left pane → Merge. **Check which survives** — merging keeps one key and anything referencing the other breaks. |
| No DOI, no attachment | Either complete it or delete it. A stub you cannot read is a citation you cannot defend. |

Then re-export and reconcile again.

---

## Two things not to do

**Do not let an agent re-score or re-rank your library.** Ask it to find and to
check, not to judge what is important. Rankings regenerate differently each
run and you cannot tell improvement from noise.

**Do not read `zotero.sqlite` directly.** It is tempting. Zotero holds a lock
on it while running, so reads can return a partial view mid-write, and the
schema is internal and changes between versions — a query that works today
breaks on the next update *silently*, by returning fewer rows rather than an
error. Export, or use the local API.

---

## Going live against real Zotero

`APPENDIX_live_zotero.md` has the detail. The short version:

- Enable **Settings → Advanced → "Allow other applications on this computer to
  communicate with Zotero"**, then `zotero-mcp` with `ZOTERO_LOCAL=true`. **No
  API key.**
- The MCP server is **read-only** — three tools, all reads. It cannot add a
  tag, create a collection or merge a duplicate.
- The web API is free, but `zotero_item_fulltext` only works on PDFs **synced
  to Zotero's servers** — 300 MB free, then $20–120/year. Local reads your disk
  at full size for nothing.

Even with the MCP connected, **export anything you are going to analyse**, so
the thing you analysed still exists in the state you analysed it.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Agent ignores `CLAUDE.md` | Launch `claude` from inside `library/`, not the package root. |
| Every attachment suddenly broken | You replaced the `.csv` without `storage/`. Re-export all three together. |
| `citecheck` says `cannot verify` on everything | The attachments are missing. Check `ls storage/` against the `File Attachments` column. |
| Citation renders wrong in Word | Check the item type — a journal article entered as `@book` renders as a book, silently. No tool in this package catches that one. |
| Cite keys changed after I fixed metadata | Expected. Better BibTeX regenerates them. **Never use a cite key as a durable identifier** — use the 8-character item key. |
| Start over | `git checkout . && git clean -fd` |
