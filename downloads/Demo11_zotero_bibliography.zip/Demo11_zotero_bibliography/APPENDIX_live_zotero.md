# Appendix — connecting to your real Zotero, locally

Everything in the main demo works on exported files. This is the live route.
Do it **after** you have run the demo, and do it read-only.

## Two ways to reach Zotero, and why the usual one is the wrong default

| | Web API | **Local API** |
|---|---|---|
| Needs an API key | Yes — a password to your whole library | **No** |
| Where the request goes | `api.zotero.org` | `localhost:23119` |
| Needs Zotero running | No | **Yes** |
| Works offline | No | **Yes** |
| Needs your library synced to Zotero's servers | Yes | No |

Most tutorials teach the web API. For a researcher with unpublished work in their
library, the local API is the better default: nothing leaves the machine to get
there, and there is no key to leak into a config file, a screenshot or a repo.

## Enable the local API

Zotero → **Settings → Advanced** → tick
**"Allow other applications on this computer to communicate with Zotero."**

Check it:

```bash
curl -s http://localhost:23119/api/users/0/items?limit=1
```

JSON means it is on. Connection refused means Zotero is not running, or the
setting is off.

Reads need no authentication. Writes (Zotero 10+) need a local key that Zotero
asks you to grant in a dialog — **do not grant it for this**.

## Point Claude Code at it

In a project folder — not your home directory — create `.mcp.json`:

```json
{
  "mcpServers": {
    "zotero": {
      "command": "uvx",
      "args": ["zotero-mcp"],
      "env": { "ZOTERO_LOCAL": "true" }
    }
  }
}
```

No key, no library ID, no library type. That is the whole file.

`uvx` comes from `uv`:
`curl -LsSf https://astral.sh/uv/install.sh | sh` (macOS/Linux).

Restart Claude Code in that folder and run `/mcp`. You should see `zotero`
connected with **three** tools.

## What those three tools are

| Tool | What it does |
|---|---|
| `zotero_search_items` | Text search over your library |
| `zotero_item_metadata` | Every populated field for one item |
| `zotero_item_fulltext` | The text of an item's PDF |

**All three are reads.** There is no tool to add a tag, create a collection,
merge duplicates, fix a year or attach a file. If a guide implies the agent will
"organise your library," this is the thing to check: it cannot.

Try it:

```
Search my Zotero library for <a topic you have papers on>, and tell me
which of the results you actually opened the full text of.
```

## Scoping it

`.mcp.json` is per-project. Put it in the folder for one paper and the agent sees
Zotero only while you are working on that paper. Your other projects have no
access at all. That is better scoping than a global config, and it is the one
part of the usual tutorial worth keeping exactly as written.

Add a deny rule for the same reason as in the main demo:

```json
{ "permissions": { "deny": ["Edit(~/Zotero/**)", "Write(~/Zotero/**)", "Bash(rm:*)"] } }
```

`~/Zotero` is Zotero's data directory — `zotero.sqlite` and the real `storage/`.
Nothing should ever write there except Zotero.

## Reading the SQLite directly — don't

`~/Zotero/zotero.sqlite` is readable, and it is tempting to query it. Two reasons
not to:

1. Zotero holds a lock on it while running. Reads can fail or return a partial
   view mid-write.
2. The schema is internal and changes between versions. A query that works today
   breaks on the next update, silently, by returning fewer rows rather than an
   error.

If you want programmatic access, use the local API. If you want reproducible
access, export — which is the main demo.

## The honest summary

- **Reads:** local API, no key, Zotero running. Good.
- **Writes:** do them in Zotero, by hand, from a proposal the agent wrote to a file.
- **Anything that matters:** export it, so the thing you analysed still exists in
  the state you analysed it.

---

Sources: [Zotero local API](https://www.zotero.org/support/dev/web_api/v3/local_api) ·
[zotero-mcp](https://pypi.org/project/zotero-mcp/)
