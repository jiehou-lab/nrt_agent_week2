---
type: review-outline
topic: ""
question: ""
compiled:
sections_total:
sections_grounded:
library: "My Library.csv"
---

# Review outline — <topic>

## Grounding table

Fill this in **before** writing any prose. One row per section.

| § | Section | Item keys supporting it | Read? | Could I have written this without the library? |
|---|---|---|---|---|
| 1 | | | | |

`Read?` is `full text`, `metadata only`, or `no`.
The last column is the honest one. `Yes` is a normal answer, not a failure —
an introduction usually can be written without the library. The problem is a
section marked `Yes` that is *presented* as a finding from the library.

## Sections

### 1. <heading>

**Grounded in:** `<ITEMKEY>` (table/section), `<ITEMKEY>` (…)
**Or:** *not grounded — general background, written from outside this library.*

<two or three sentences of what this section would argue>

---

## What this library cannot support

Sections this topic needs that nothing here covers. This list is the reason to
go and read something, so it is the most useful part of the document.

| Section | What is missing |
|---|---|
