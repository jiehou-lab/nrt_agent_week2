---
topic: ""
question: ""
compiled:
entries:
excluded:
---

# Bibliography — <topic>

**Question this is for:** <the specific question, in one sentence>

**Scope:** what was searched, and what was deliberately left out.

---

## Entries

### 1. <cite key> · item <KEY>

> Full reference, formatted.

**Contributes:** what this paper gives *this question*. Not a summary.

**Evidence:** the specific number, finding or statement, and where it is
(table, section or page).

**Read:** full text / `[metadata only — not read]`

---

## Excluded

| Entry | Why excluded |
|---|---|

## Problems found in the library

| Item key | Problem |
|---|---|
