# Reference library

This folder is a Zotero library as it exists **on disk**. Three views of the same
library, and they do not agree with each other:

| Path | What it is |
|---|---|
| `My Library.bib` | Better BibTeX export. What a citation ends up looking like. |
| `My Library.csv` | Zotero CSV export. Carries the **item key**, which is the real identifier. |
| `storage/` | The attachments. One folder per item, named with its 8-character item key. |
| `bib/` | **Output goes here.** Nothing else in this folder is yours to write. |

## The library is read-only

Do not edit, move, rename or delete anything in `storage/`, `My Library.bib` or
`My Library.csv`. A reference manager is the system of record for someone's
reading life, and an agent editing it in place is how a decade of citations gets
quietly corrupted. Changes to the library are made **by me, in Zotero**.

You propose. You write proposals to `bib/`. I apply them.

## The item key is the identifier

Cite keys (`okafor2024thermonet2`) are generated and can collide, duplicate or
change. The **item key** — the 8-character string that names the `storage/`
folder and appears in the `Key` column of the CSV — is stable. When you are
unsure whether two records are the same thing, compare item keys, DOIs and
attachments, not titles.

## Before citing anything

1. **Find its attachment.** `storage/<KEY>/`. Read the PDF.
2. **Check the metadata against the PDF.** The year, journal and DOI in an export
   are whatever was true when the item was imported. The PDF is what the item
   actually is. Where they disagree, the PDF wins and you say so.
3. If there is no attachment, or the attachment is missing from `storage/`, the
   entry is **metadata only**. You may still cite it, but mark it
   `[metadata only — not read]` in the annotation. Never summarise a paper you
   have not opened.

## Reconcile in both directions

- Every `file =` / `File Attachments` path should exist. Report the ones that do not.
- Every folder in `storage/` should belong to an entry. Report the ones that do not.

An orphaned attachment is a paper that is invisible to every bibliography you
build from the `.bib`, which is the whole point of checking.

## Writing a bibliography

Use `_templates/bibliography.md`. For every entry:

- cite key, item key, and full reference
- one or two sentences on **what it contributes to this specific topic** — not a
  summary of the paper
- the page or table the claim comes from
- `[metadata only — not read]` where that applies

Never list an entry you cannot trace to a file in `storage/` or explicitly mark
as unread. Never invent a page number, a DOI or a volume.

## Reporting back

Finish with: entries used, entries excluded and why, problems found in the library,
and anything you marked `[metadata only]`. The problems list is the useful part.
