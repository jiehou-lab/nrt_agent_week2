# Instructor — setting up the shared Overleaf project

Fifteen minutes, once, before the session.

1. **New Project → Blank Project.** Name it for the session.
2. Upload `main.tex` from this folder, replacing the default one.
3. Create a folder called `groups` (New Folder, top of the file tree).
4. Upload `example-plan.tex` into `groups/`. It gives the class something
   to look at, and it proves the `\input` wiring works before anyone
   depends on it.
5. Create an empty `refs.bib` at the top level. Paste in the header
   comment from `refs/refs.bib` so the key-prefix rule is visible to
   anyone who opens it.
6. **Recompile.** You should get a title page, a table of contents, and
   one example section. If this does not work now, it will not work with
   twenty people pushing into it.
7. **Share → Turn on link sharing → "Anyone with this link can edit".**
   Put that link on a slide.

## During the session

Attendees do three things: upload `groups/firstname-lastname.tex`, paste
their entries into `refs.bib`, and add one `\input` line to `main.tex`.
Overleaf is a real-time collaborative editor, so twenty people adding one
line each to the same file is what it is built for.

## When it breaks

It will, and that is the useful part of step 7. The three failures, in
order of likelihood:

**Every citation turns into a question mark, the reference list vanishes
entirely, and the log says `Repeated entry`.** Two
people used the same cite key. BibTeX fails, so the whole bibliography
fails --- not just that entry. Download the project (Menu → Download →
Source) and run:

    python3 tools/bibcheck.py refs.bib

It names the duplicate. Prefix one of them and recompile.

**`File groups/xyz.tex not found`.** Someone added the `\input` line but
the upload failed, or the filename does not match. Check the file tree.

**A stray `\documentclass` or `\usepackage` inside a group file.** The
compile dies with something unhelpful about a missing `\begin{document}`.
`texcheck.py` catches this before upload --- which is why it is in
the attendee steps and not here.

## Afterwards

**Turn link sharing off.** The link grants edit access to anyone who kept
it, permanently. Or treat the project as disposable and abandon it.
