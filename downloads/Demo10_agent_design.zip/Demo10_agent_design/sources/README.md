# sources/ — what you collected

**Not just papers.** Anything that describes the work your agent would help
with, or the problem it would solve:

| | |
|---|---|
| papers, preprints | `.pdf` |
| slide decks | `.pptx` — or export to PDF |
| reports, SOPs, protocols | `.docx`, `.pdf`, `.md` |
| blog posts, docs pages | save the page (below) |
| meeting notes, emails | `.md`, `.txt` |
| a README or a script | `.md`, `.py` — code counts |

    cp ~/Downloads/*.pdf sources/

**Two or three is plenty.** This is not a literature review. You need
enough that the tool you design has something concrete to be about.

## Getting a web page in

The `notes` agent has **no web tools**, on purpose — see below. So save the
page first:

- **Browser → Print → Save as PDF.** Works everywhere, keeps the figures.
- Or **File → Save Page As → Web page, complete**, which gives an `.html`.

Reader mode first, if the site has it, strips the navigation and ads.

## Reading formats that are not PDF or text

A `.pptx` or `.docx` is a zip of XML. `pdftotext` fails on one and nothing
renders it, so:

    python3 tools/totext.py sources/deck.pptx     # slides + speaker notes
    python3 tools/totext.py sources/report.docx
    python3 tools/totext.py sources/post.html     # script/style stripped

Standard library only, nothing to install. For a PDF, Claude reads it
directly, or `pdftotext file.pdf -`.

Slides that are entirely images extract nothing. Export the deck as PDF and
let Claude read the pages.

## Why the notes agent cannot browse

Its tool list has no `WebSearch` and no `WebFetch`. Given a URL, an agent
that can browse will write a fluent, confident note from an abstract, a
landing page, or a search result — and **that note is indistinguishable
from one written from the source**. Saving the page takes five seconds and
removes the whole failure mode.

The cost is real and worth seeing: this is the capability layer doing its
job, and it is doing it to you as well as for you. The `writer` agent *does*
have web tools, because for a draft, "found this online" is a legitimate
tier that gets marked as such.

## Flat, on purpose

No subfolders. A document can be relevant to two things at once and a
folder can only hold it in one place.

> The test before adding any subfolder: *can one document belong to two of
> these at the same time?* If yes, it is a field, not a folder.

## Nothing to hand?

Three real, open-access papers (CC BY 4.0 — you may cite them):

| DOI | what it is |
|---|---|
| `10.1038/s41598-023-49831-6` | machine-learning dose prediction, primary cohort |
| `10.3390/jpm12050717` | review of nonlinear ML for the same problem |
| `10.31083/RCM33425` | a second cohort, different population |

They share one question and answer it differently, which gives you a real
synthesis to attempt and a real gap: none reports error stratified by
whether the patient ever reached a therapeutic range.

## Your sources are never copied or shared

`snapshot.py` skips them and `.gitignore` excludes them, so the only copy
is the one on your disk. They are usually not yours to redistribute, and a
6 MB PDF committed once would stay in a repository's history forever.

    ls sources/
