# Demo 10 — Design your own agent, and write the plan

**Week 4, in class.** Two hours, eight steps, one shared paper at the end.

You will end with a section of a real LaTeX document, in a project everyone
in the room contributed to, describing **an agent tool you want to build** —
with citations to whatever you brought.

No Zotero. No git. No LaTeX install. A folder, a browser, and Claude Code.

---

## Before you start (two minutes)

    cd Demo10_agent_design
    python3 tools/doctor.py
    python3 tools/snapshot.py

`doctor.py` needs `python3` and Claude Code. Everything else it mentions is
optional and it says so.

`snapshot.py` is the undo button: it zips your notes, refs and plan into
`.snapshots/` so an agent cannot lose work you wanted to keep. Put it back
with `python3 tools/snapshot.py --restore`.

**There is no git in this package, and no shell scripts either.** Every
tool is Python, so Windows needs `python3` and nothing else — no Git Bash,
no WSL. If you already use git, `git init && git add -A && git commit` is
better than the snapshot and you should use that instead.

---

## 1 · Collect your sources  — 10 min

**Not just papers.** Drop anything into `sources/` that describes the work
your agent would help with: a paper, a slide deck, a blog post, an SOP, a
report, meeting notes, a README, a script.

    cp ~/Downloads/*.pdf sources/

**Two or three is plenty.** This is not a literature review. You want
enough that the agent you design has something concrete to be about.

**A web page?** Save it first — Browser → Print → Save as PDF. The notes
agent has no web tools, deliberately; `sources/README.md` says why, and
the reason is worth reading before you decide it is annoying.

**A deck or a Word file?** Those are zips of XML, so nothing reads them
out of the box:

    python3 tools/totext.py sources/deck.pptx      # slides + speaker notes
    python3 tools/totext.py sources/report.docx

Standard library, nothing to install. Tested on a 62-slide deck.

> Nothing to hand? `sources/README.md` lists three open-access papers with
> their DOIs. They are real and you may cite them.

---

## 2 · Turn them into notes  — 20 min

    claude
    /agents          # you should see: notes, writer, citecheck

Then, once per source:

    Use the notes subagent on sources/<file>

Watch what it does. It works out how to read the thing, writes
`sources/notes/<name>.md` against a fixed eight-section template, sets
`kind:` to what it actually is, and adds one row to `sources/_index.md`.

**The template fits a blog post as well as a paper**, and the sections that
go thin are the point. A launch announcement gets
`## Evidence given: none — asserted, not shown`, and writing that down is a
finding rather than a hole. `check_notes.py` only expects numbers there when
`kind:` is `paper` or `preprint`.

Check it with a tool that fixes nothing:

    python3 tools/check_notes.py

**Then read one note like a reviewer.** Two sections matter:

- **`## My take` is empty.** It always is. No agent writes there. In six
  months it is the only section you can trust to be your own thinking.
- **`## What it is` is the provenance line.** It matters most for the
  things that are not papers: who made it, when, and — for anything not
  peer reviewed — who benefits from believing it. A vendor post claiming a
  tool saves 40% is evidence of a claim, not of 40%.
- **`## Relevance to my tool` is the bridge to step 4.** It is the agent's
  guess, and you should argue with it.

---

## 3 · Get a `.bib` entry for anything you will cite  — 5 min

Only for real publications. Skip it entirely if your documents are internal.

**Easiest route:** on the paper's own page, find *Cite* or *Export
citation* and choose **BibTeX**. Every major publisher has this.

**No publisher page?** Paste the DOI into <https://www.doi2bib.org> and copy
what comes back.

Paste the entry into `refs/refs.bib`. Then **rename the cite key so it
starts with your first name and a colon**:

    @article{alice:horne2012,          <-- was horne2012pharmacogenetic
      ...
      doi = {10.1160/TH11-06-0388},
    }

That prefix is not decoration. In step 6 twenty people paste into one
shared `refs.bib`, and **two identical cite keys make BibTeX fail, every citation in the whole
document render as `(?)`, and the reference list disappear completely** —
not just the duplicated entry. One person's collision breaks everybody's PDF.
Measured, not assumed. A name prefix makes a
collision impossible.

> **Keep the `doi` field.** It is the only identifier that survives moving
> between tools. Google Scholar's BibTeX export does not include one, which
> is why it is not the route recommended here.

    python3 tools/bibcheck.py        # duplicate keys, missing DOIs

---

## 4 · Design your agent, out loud, with Claude  — 15 min

**This is the part the rest of the session exists for.** Open
`IDEAS.md` for starter questions, then just talk:

    Use the design skill. I want an agent that <describe the job>.

Argue with what comes back. The skill is under instruction to ask you
questions before proposing anything, and to put every rule in the **lowest
layer that can hold it**:

| layer | where it lives | what it is |
|---|---|---|
| context | `CLAUDE.md` | a **request** — can be misread or forgotten |
| permission | `.claude/settings.json` | a **refusal** — the call is blocked |
| capability | a subagent's `tools:` list | an **absence** — there is nothing to call |

A good proposal names which layer each rule belongs in and why. A proposal
that answers everything with "I will tell the agent to..." has put all three
in the weakest one.

**Write down what you decide.** The next step turns it into a document.

---

## 5 · Draft the implementation plan  — 25 min

    Use the writer subagent: an implementation plan for the agent we just
    designed. LaTeX, into writing/myplan.tex. Cite anything from refs/refs.bib
    that supports a design choice.

What comes back marks **where every claim came from**:

| marker | means |
|---|---|
| `\cite{alice:horne2012}` | in `refs/refs.bib`, and you read the paper |
| `% [UNREAD: ...]` | the agent read the PDF just now; you have not |
| `% [WEB: ...]` | found online, not in your refs. **Not a citation yet.** |
| `% [GAP: ...]` | nothing supports this. Say so rather than writing smoothly. |

The last three are LaTeX comments, so they never typeset — but they are
visible to you, and to anyone who opens the source.

**Leave the gaps in.** They are the plan telling you what you still have to
find out. Deleting them so it reads finished is the one move that turns an
honest plan into a confident wrong one.

Then check the citations with an agent that cannot edit:

    Use the citecheck subagent on writing/myplan.tex

It reads your notes first, the `.bib` second, and opens a PDF only when
those cannot settle the claim. It has **no `Write` tool** — look at
`.claude/agents/citecheck.md` if you do not believe it. A verifier that can
edit is one that can make its own findings disappear.

Last, before you upload:

    python3 tools/texcheck.py writing/myplan.tex

Unbalanced environments, stray preamble, and cite keys that are not in
`refs.bib`. Those are the three things that break **somebody else's**
build, which is why this runs before the upload and not after.

---

## 6 · Upload to the shared Overleaf project  — 10 min

The link is on the slide. It opens the project with edit access.

**Rename your file first.** In the Overleaf file tree:

    groups/firstname-lastname.tex        <-- your plan
                                             e.g. groups/alice-nguyen.tex

Select the `groups` folder, then **Upload**. If you upload as `myplan.tex`
you will silently overwrite whoever uploaded before you.

Then two more things, both in the browser:

1. Open `refs.bib` and **paste your entries at the end**. Your keys are
   prefixed, so nothing can collide.
2. Open `main.tex` and add **one line** in the marked block:

       \input{groups/firstname-lastname}

Overleaf is a real-time collaborative editor — twenty people adding one
line each to `main.tex` is exactly what it is for. Watch the PDF rebuild
with your section in it.

---

## 7 · The instructor assembles  — 10 min

Live, on the projector. Compile, look at what twenty people produced in one
document, and see what broke.

Something usually does. That is the useful part.

---

## 8 · If time: add a skill of your own  — 15 min

A skill is a folder with a `SKILL.md` in it. Look at
`.claude/skills/design/SKILL.md` — that is the whole format.

    Create a skill called <name> that <does the thing you kept
    re-explaining to Claude today>.

**Agent or skill?** Needs a narrower tool list → agent. Needs a consistent
procedure → skill. `citecheck` is an agent because the point is what it
*cannot* do. `design` is a skill because the point is the order it works in.

---

## What is deliberately not here

Zotero, Better BibTeX, pandoc, git, Overleaf tokens, Word field
codes. All of that is real and all of it works — it is
**Demo 10x**, on the course site. It is the same workflow with a reference
manager underneath and a Word exit. Come back to it when this one feels small.
