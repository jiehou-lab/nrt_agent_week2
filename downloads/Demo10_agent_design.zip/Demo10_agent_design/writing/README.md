# writing/

`myplan.tex` is the deliverable. It is a **fragment**: it will be `\input`
into a shared `main.tex` that somebody else owns.

## That means no preamble

No `\documentclass`, no `\begin{document}`, no `\usepackage`, no
`\bibliography`. Those lines live in `main.tex`. One of them in your file
breaks the build for the whole class, which is the single most common way
a shared LaTeX document falls over.

    python3 tools/texcheck.py writing/myplan.tex

catches exactly that, plus unbalanced environments and any `\cite{}` key
that is not in `refs/refs.bib`. **It does not need LaTeX installed** — it
is a text check, because requiring a TeX install would have excluded half
the room.

## You will not compile this locally

Overleaf does it. Upload, add your `\input` line, watch the PDF rebuild.
If you do have LaTeX and want to see your own section alone, wrap it:

    \documentclass{article}
    \usepackage{natbib}
    \begin{document}
    \input{myplan}
    \bibliographystyle{plainnat}
    \bibliography{../refs/refs}
    \end{document}

That wrapper is for you only. Never upload it.

## Markers

The `writer` agent leaves LaTeX comments in the source:

    % [UNREAD: key]   it read the PDF; you have not
    % [WEB: url]      found online, not in refs — not a citation yet
    % [GAP: ...]      nothing supports this

They never typeset. **Leave them in.** They are the plan telling you what
you still have to find out, and `## Open questions` is where they get
promoted to prose.
