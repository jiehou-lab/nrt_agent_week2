# What would you actually build?

Starter questions for step 4. You do not need to answer all of them — one
good answer is enough to start the conversation with Claude.

## Find the task

- What did you do more than three times last month that felt mechanical?
- What do you explain to every new student or new hire, in the same words?
- Which step in your analysis do you most often get wrong, or skip?
- What takes you an hour and produces something that is mostly the same
  each time?
- What do you not do, because doing it properly would take a week?

## Make it concrete

A good target has an input you can point at and an output you could check.

| vague | concrete |
|---|---|
| "help with my literature" | "given a PDF, tell me whether its cohort overlaps a paper I already filed" |
| "clean my data" | "given a plate-reader CSV, flag wells outside 3 SD and write a one-line log" |
| "help me write" | "given a results table, draft the paragraph in my group's house style" |
| "manage my code" | "before I push, check the notebook has no hard-coded paths" |

## Then the design questions

These are the ones the `design` skill will push you on. Thinking about them
first makes the fifteen minutes count.

1. **What must it never be able to do?** Not *should not* — *could not*.
   That answer becomes a missing tool or a deny rule, not a sentence in a
   prompt.
2. **How would you know it got it wrong?** If the answer is "I would read
   the output carefully", the design is not finished. What is the check?
3. **Who checks the checker?** If the thing that verifies can also edit,
   it can make its own findings disappear.
4. **What does it need that is not in the folder?** A database, an
   instrument, a web service, a calendar — that is where an MCP server
   earns its place. If everything it needs is a file on disk, you do not
   need one.
5. **Agent, skill, or neither?** Narrower tool list → agent. Consistent
   procedure → skill. Runs once → just ask.

## The honest version

Write one sentence here before you start, and compare it with what you have
at the end of the session.

> I want an agent that ...
