# This folder

A workspace for designing an agent tool and writing the implementation plan
for it, with citations. Read `START_HERE.md` for the order of work.

## What lives where

| path | who writes it | what it is |
|---|---|---|
| `sources/` | **you** | whatever you collected — papers, decks, posts, SOPs, code |
| `sources/notes/` | the `notes` agent | one note per document, fixed template |
| `sources/_index.md` | the `notes` agent | one row per note |
| `refs/refs.bib` | **you** | BibTeX entries, keys prefixed `yourname:` |
| `writing/myplan.tex` | the `writer` agent, then you | the deliverable |
| `IDEAS.md` | **you** | what you are trying to build |

## Rules

**Never write in `## My take`.** It is the human's section. An empty one is
correct. A filled one is a lie about who thought it.

**Never invent a cite key.** If a claim needs a source that is not in
`refs/refs.bib`, mark it `% [GAP: ...]` and say what would settle it. A
`\cite{}` to a key that does not exist renders as a question mark, and a
*duplicate* key breaks the bibliography for the whole shared document.

**Cite keys are prefixed with the author's first name** — `alice:horne2012`.
Twenty people share one `refs.bib`; duplicate keys make BibTeX fail for all
of them. Preserve the prefix when you copy an entry.

**Keep the `doi` field** on every entry that has one. It is the only
identifier that survives moving between tools.

**`sources/` is flat.** No subfolders. A source can be relevant to two
things at once, and a folder can only hold it in one place. If you want to
group, add a field to the note's frontmatter and generate a view.

> The test before adding any subfolder: *can one document belong to two of
> these at the same time?* If yes, it is a field, not a folder.

## The three layers

When you propose a rule, say which layer it belongs in — and prefer the
lowest one that can hold it.

- **context** — this file. A *request*. It can be misread or forgotten.
- **permission** — `.claude/settings.json`. A *refusal*. The call is blocked.
- **capability** — a subagent's `tools:` list. An *absence*. Nothing to call.

"Do not edit the notes" in this file is a request. `citecheck` having no
`Write` tool is an absence, and it is the only one that cannot be argued with.
