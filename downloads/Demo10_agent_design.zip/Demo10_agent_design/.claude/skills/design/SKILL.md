---
name: design
description: Work out the design of an agent tool with me — what it does, what it must not be able to do, and which of the three layers each rule belongs in. Use when I describe something I want to build and want it turned into a design.
---

# Designing an agent tool

The human has an idea for something they want built. Your job is **not** to
agree with it and produce a plan. It is to ask the four questions below
first, and only then propose.

## Ask before you propose

Ask these as a short numbered list and **wait for answers.** Do not answer
them yourself from assumption — the whole value of this conversation is the
human's knowledge of their own work.

1. **What is the input, concretely?** A file, a folder, a message, a
   reading off an instrument? What does one look like? If the answer is
   abstract, ask for a real example.
2. **What is the output, and how would you know it was wrong?** If the
   answer is "I would read it carefully", push: what is the *check*? A
   design with no failure detection is a wish.
3. **What must it never be able to do?** Not *should not* — *could not*.
   Push for something concrete: never write to the raw data, never send
   mail, never delete, never edit the thing it is checking.
4. **How often, and who else sees the output?** A thing you run once is a
   prompt. A thing you run weekly is a skill. A thing other people depend
   on needs the failure modes written down.

If the human's idea is vague, say which of the four is missing and offer
two concrete versions of it to choose between. Do not proceed on a vague
answer — a vague design produces a plan that reads well and cannot be built.

## Then propose, in this shape

### 1. One sentence
What it does, with the input and output named. If you cannot write this
sentence, the design is not ready.

### 2. Agent, skill, or neither

| | use it when |
|---|---|
| **subagent** | the point is a **narrower tool list** — it must not be able to do something, or it needs its own context window |
| **skill** | the point is a **consistent procedure** — the same steps, the same order, every time |
| **neither** | it runs once. Just ask. Do not build a thing. |

Say which and why. "Both" is usually wrong and means the job has two parts
that should be named separately.

### 3. Each rule, in the lowest layer that holds it

Make a table. Every rule the tool needs gets one row:

| rule | layer | why not a weaker one |
|---|---|---|
| never edit the raw data | **permission** — deny in `settings.json` | a request in `CLAUDE.md` can be forgotten mid-task |
| the checker cannot fix | **capability** — no `Write` in its `tools:` | a checker that can edit can erase its own findings |
| prefer SI units | **context** — `CLAUDE.md` | nothing to deny; a preference, not a boundary |

- **context** (`CLAUDE.md`) — a *request*. It can be misread or forgotten.
- **permission** (`.claude/settings.json`) — a *refusal*. The call is blocked.
- **capability** (a subagent's `tools:`) — an *absence*. There is nothing to call.

**If every row says "context", say so out loud and try again.** That is the
most common failure of a first design and it is the one worth catching here
rather than in production.

### 4. Does it need an MCP server?

Only if the tool must reach something that is **not a file on this disk** —
a database, an instrument, a ticketing system, a calendar, a web service
with credentials. If everything it needs is a file, it does not need one,
and saying so is a better answer than inventing a reason.

If it does: name the two or three operations it would expose, and what each
returns. An MCP server with one operation is usually a script.

### 5. The smallest version worth building
What you would build first, in an afternoon, that would already be useful.
Then what you would add second, and what would make you abandon it.

## Finally

End with the **one assumption that, if wrong, makes the whole design
pointless** — and how the human could check it this week. Every design has
one. Finding it is worth more than the rest of the output.
