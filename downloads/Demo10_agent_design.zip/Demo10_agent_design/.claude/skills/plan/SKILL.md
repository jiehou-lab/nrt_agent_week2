---
name: plan
description: Turn a design we have discussed into a LaTeX implementation plan with citations, ready to drop into a shared document. Use after the design skill, or when I ask for the plan written up.
---

# Writing the implementation plan

Hand this to the `writer` subagent. This skill is the shape; the agent is
the one with the tier rules.

## Before writing

- Re-read what was decided. If the design conversation did not settle
  **what the tool must not be able to do**, ask now. A plan without that
  section is missing the only part that is hard.
- Grep `refs/refs.bib` for the keys you intend to cite. **Every `\cite{}`
  must resolve.** An invented key renders as `(?)`. A *duplicate* key is
  worse: BibTeX fails and the entire reference list disappears from the
  shared document.
- Check `sources/notes/` for anything relevant that was not mentioned. If
  the human collected a document and the plan ignores it, say so — either
  it is not relevant, which is fine, or the plan has a hole.

## The file

Write to `writing/myplan.tex`. **No `\documentclass`, no `\begin{document}`,
no `\bibliography`.** It is a fragment that will be `\input` into someone
else's main file. A stray preamble line breaks their build, not yours.

Start at `\section{}`. Keep it to roughly one and a half pages — this is a
plan, not a paper.

## Required structure

    \section{<Tool name>: <what it does, in six words>}

    \subsection{The problem}
    What is done by hand today, how often, and what it costs.
    One paragraph. Cite anything that establishes the problem is real.

    \subsection{What it does}
    Input, output, and ONE worked example with real values.
    The example is the part readers actually understand.

    \subsection{Design}
    A table: every rule, which of the three layers it belongs in, and why
    not a weaker one. Name the subagents and skills.

    \subsection{How it can fail}
    At least three failure modes. For each: what it looks like from
    outside, and what check catches it. Say which checks are automatic.

    \subsection{What I would build first}
    The smallest version that is already useful. What comes second.

    \subsection{Open questions}
    Promote every `% [GAP: ...]` marker to a sentence here. These are the
    most useful part of the document for anyone reading it later.

## After writing

    python3 tools/texcheck.py writing/myplan.tex

It catches unbalanced environments, a stray preamble, and cite keys missing
from `refs.bib` — the three things that break the shared build. Fix what it
reports before telling the human it is ready.

Then say, in one line each: how many claims are cited, how many are marked
`[WEB:]`, and how many `[GAP:]` remain. A plan with no gaps either solved
everything or stopped looking.
