#!/usr/bin/env python3
"""Check refs.bib before it reaches a shared document.

One duplicate cite key makes BibTeX fail and every citation in the whole
document render as a question mark and the whole reference list vanish --
not just the duplicated entry. Measured: latexmk exits 12, a .bbl is still
written, but the pass that uses it never runs. In a project twenty
people paste into, that is one person breaking everybody's build. This
reports and repairs nothing.

    python3 tools/bibcheck.py                  # refs/refs.bib
    python3 tools/bibcheck.py a.bib b.bib ...  # across several files
"""
import re, sys, os
from collections import defaultdict

KEY = re.compile(r'^\s*@(\w+)\s*\{\s*([^,\s]+)\s*,', re.M)

def main(paths):
    if not paths:
        paths = ['refs/refs.bib']
    seen, missing_doi, unprefixed, total = defaultdict(list), [], [], 0

    for p in paths:
        if not os.path.exists(p):
            print('  no such file: %s' % p); continue
        text = open(p, encoding='utf-8', errors='replace').read()
        # split into entries so we can look inside each one
        starts = [m.start() for m in KEY.finditer(text)] + [len(text)]
        for i, m in enumerate(KEY.finditer(text)):
            key = m.group(2)
            body = text[starts[i]:starts[i + 1]]
            total += 1
            seen[key].append(os.path.basename(p))
            if not re.search(r'^\s*doi\s*=', body, re.M | re.I):
                missing_doi.append((key, os.path.basename(p)))
            if ':' not in key:
                unprefixed.append((key, os.path.basename(p)))

    dups = {k: v for k, v in seen.items() if len(v) > 1}

    print('\n  %d entr%s across %d file(s)\n' % (total, 'y' if total == 1 else 'ies', len(paths)))

    if dups:
        print('  FAIL  %d duplicate cite key(s). BibTeX will fail and EVERY' % len(dups))
        print('        citation become a question mark and the reference list')
        print('        vanish -- not just the duplicated entry.')
        for k, where in sorted(dups.items()):
            print('          %-34s %s' % (k, ', '.join(where)))
        print('        Fix: give each owner their own prefix, so the two keys')
        print('        differ — alice:smith2024 and bob:smith2024.')
    else:
        print('  ok    no duplicate keys')

    if unprefixed:
        print('\n  warn  %d key(s) with no "name:" prefix. Safe alone, a collision'
              % len(unprefixed))
        print('        waiting to happen in the shared file:')
        for k, p in unprefixed[:10]:
            print('          %-34s %s' % (k, p))
        if len(unprefixed) > 10:
            print('          ... and %d more' % (len(unprefixed) - 10))
    else:
        print('  ok    every key is prefixed')

    if total == 0:
        print('\n  note  no entries yet. Add one per paper you will cite,')
        print('        with the key prefixed: @article{yourname:smith2024, ...}')
        print()
        return 0

    if missing_doi:
        print('\n  warn  %d entr%s with no doi field. The DOI is the only identifier'
              % (len(missing_doi), 'y' if len(missing_doi) == 1 else 'ies'))
        print('        that survives moving between tools, and citecheck joins on it.')
        print('        Google Scholar\'s BibTeX never includes one -- use the')
        print('        publisher\'s own export, or doi2bib.org.')
        for k, p in missing_doi[:10]:
            print('          %-34s %s' % (k, p))
    else:
        print('  ok    every entry has a doi')

    print()
    return 1 if dups else 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
