#!/usr/bin/env python3
"""What is installed, what is missing, and the exact command to fix it.

Pure Python so it runs the same on macOS, Linux and Windows. There are no
shell scripts in this package, which is why Windows needs nothing beyond
python3 -- no Git Bash, no WSL.

    python3 tools/doctor.py
"""
import os, shutil, sys, glob, json, subprocess

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def ok(m):   print('  ok      %s' % m)
def miss(m, fix): print('  MISSING %s\n          -> %s' % (m, fix))
def note(m): print('  note    %s' % m)

def main():
    print('\n== Core — these must work ==')
    ok('python3 %s' % '.'.join(map(str, sys.version_info[:3])))

    s = os.path.join(HERE, '.claude', 'settings.json')
    try:
        json.load(open(s)); ok('.claude/settings.json is valid JSON')
    except Exception as e:
        miss('.claude/settings.json (%s)' % e.__class__.__name__, 're-unzip the package')

    agents = glob.glob(os.path.join(HERE, '.claude', 'agents', '*.md'))
    (ok('3 subagents (notes, writer, citecheck)') if len(agents) == 3
     else miss('subagents (found %d, expected 3)' % len(agents), 're-unzip the package'))

    tools = ['totext.py', 'check_notes.py', 'bibcheck.py', 'texcheck.py', 'snapshot.py']
    gone = [t for t in tools if not os.path.exists(os.path.join(HERE, 'tools', t))]
    ok('5 tools present') if not gone else miss('tools: %s' % ', '.join(gone), 're-unzip the package')

    print('\n== Nice to have ==')
    if shutil.which('pdftotext'):
        ok('pdftotext — citecheck can search inside PDFs cheaply')
    else:
        note('no pdftotext. citecheck still works, it just reads whole PDFs.\n'
             '          macOS: brew install poppler   Windows: Claude reads PDFs directly.')

    print('\n== Not needed, on purpose ==')
    note('git, LaTeX, Zotero, pandoc, Git Bash. Overleaf compiles for you,\n'
         '          the .bib is a text file, and every tool here is Python.\n'
         '          For the full system with a reference manager, see Demo 10x.')

    print('\n== Your work so far ==')
    src = [f for f in glob.glob(os.path.join(HERE, 'sources', '*'))
           if os.path.isfile(f) and os.path.basename(f) not in ('README.md', '_index.md')]
    notes = glob.glob(os.path.join(HERE, 'sources', 'notes', '*.md'))
    bib = os.path.join(HERE, 'refs', 'refs.bib')
    nb = sum(1 for l in open(bib, encoding='utf-8', errors='replace')
             if l.startswith('@')) if os.path.exists(bib) else 0
    print('  %d source(s) in sources/, %d note(s), %d bib entr%s'
          % (len(src), len(notes), nb, 'y' if nb == 1 else 'ies'))

    plan = os.path.join(HERE, 'writing', 'myplan.tex')
    if os.path.exists(plan) and 'Tool name: what it does' in open(plan, encoding='utf-8').read():
        note('writing/myplan.tex is still the template — step 5 has not run yet')
    else:
        ok('writing/myplan.tex has been written')

    snaps = sorted(glob.glob(os.path.join(HERE, '.snapshots', '*.zip')))
    if snaps:
        ok('%d snapshot(s), newest %s' % (len(snaps), os.path.basename(snaps[-1])))
    else:
        note('no snapshot yet. Before you let an agent write anything:\n'
             '          python3 tools/snapshot.py')
    print()

if __name__ == '__main__':
    main()
