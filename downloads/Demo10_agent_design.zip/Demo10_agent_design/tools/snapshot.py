#!/usr/bin/env python3
"""An undo button that does not need git.

Zips the text you would be sad to lose -- your notes, your refs, your plan,
your IDEAS.md -- into .snapshots/ with a timestamp. Source PDFs are skipped;
they are the one thing no agent will overwrite.

    python3 tools/snapshot.py            # take one, before you start
    python3 tools/snapshot.py --list     # what you have
    python3 tools/snapshot.py --restore  # put the newest one back

This is a zip, not version control. It has no history and no diff. If you
use git, `git init && git add -A && git commit` is strictly better and this
script is unnecessary -- but git is not a requirement of this package and
this is what stands in for it.
"""
import os, sys, glob, time, zipfile, shutil

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SNAP = os.path.join(HERE, '.snapshots')
INCLUDE = ('sources/notes', 'refs', 'writing', 'IDEAS.md', 'CLAUDE.md', 'sources/_index.md')
SKIP_EXT = {'.pdf', '.pptx', '.docx', '.png', '.jpg', '.zip'}

def collect():
    out = []
    for item in INCLUDE:
        p = os.path.join(HERE, item)
        if os.path.isfile(p):
            out.append(p)
        elif os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for f in files:
                    if os.path.splitext(f)[1].lower() in SKIP_EXT: continue
                    out.append(os.path.join(root, f))
    return out

def take():
    os.makedirs(SNAP, exist_ok=True)
    name = time.strftime('%Y-%m-%d_%H%M%S') + '.zip'
    path = os.path.join(SNAP, name)
    files = collect()
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, os.path.relpath(f, HERE))
    print('\n  ok    %s — %d file(s)' % (os.path.join('.snapshots', name), len(files)))
    print('        restore with:  python3 tools/snapshot.py --restore\n')

def listing():
    s = sorted(glob.glob(os.path.join(SNAP, '*.zip')))
    if not s:
        print('\n  no snapshots yet. Take one:  python3 tools/snapshot.py\n'); return
    print()
    for p in s:
        with zipfile.ZipFile(p) as z:
            print('  %-24s %d file(s)' % (os.path.basename(p), len(z.namelist())))
    print()

def restore():
    s = sorted(glob.glob(os.path.join(SNAP, '*.zip')))
    if not s:
        raise SystemExit('\n  nothing to restore from.\n')
    newest = s[-1]
    with zipfile.ZipFile(newest) as z:
        names = z.namelist()
        print('\n  about to overwrite %d file(s) from %s:' % (len(names), os.path.basename(newest)))
        for n in names[:12]: print('      %s' % n)
        if len(names) > 12: print('      ... and %d more' % (len(names) - 12))
        if input('\n  type yes to go ahead: ').strip().lower() != 'yes':
            raise SystemExit('  nothing changed.\n')
        z.extractall(HERE)
    print('  ok    restored from %s\n' % os.path.basename(newest))

if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: take()
    elif a[0] == '--list': listing()
    elif a[0] == '--restore': restore()
    else: raise SystemExit(__doc__)
