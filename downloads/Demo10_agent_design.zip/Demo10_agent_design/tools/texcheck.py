#!/usr/bin/env python3
"""Check a contributed .tex fragment WITHOUT needing LaTeX installed.

It looks for the three things that break SOMEBODY ELSE's build once your
file is \\input into the shared document:

  1. a stray preamble    \\documentclass, \\begin{document}, \\usepackage, \\bibliography
  2. unbalanced          \\begin{...} / \\end{...}
  3. a \\cite key that is not in refs/refs.bib

Having LaTeX installed is NOT required and nothing here assumes it.

    python3 tools/texcheck.py writing/myplan.tex
    python3 tools/texcheck.py writing/myplan.tex refs/refs.bib
"""
import os, re, sys
from collections import Counter

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# \b after a closing brace never matches -- } and the line end are both
# non-word -- so \begin{document} slipped through the first version of
# this. Word-ending commands keep \b; brace-ending ones must not have it.
STRAY = re.compile(r'^\s*\\(?:documentclass\b|usepackage\b'
                   r'|bibliographystyle\b|bibliography\b'
                   r'|begin\{document\}|end\{document\})')
CITE  = re.compile(r'\\[a-zA-Z]*cite[a-zA-Z]*\*?(?:\[[^\]]*\])*\{([^}]*)\}')
BIBKEY = re.compile(r'^\s*@[a-zA-Z]+\s*\{\s*([^,\s]+)', re.M)

def main(argv):
    if not argv:
        raise SystemExit('usage: python3 tools/texcheck.py writing/myplan.tex')
    src = argv[0]
    bib = argv[1] if len(argv) > 1 else os.path.join(HERE, 'refs', 'refs.bib')
    if not os.path.exists(src):
        raise SystemExit('  no such file: %s' % src)
    text = open(src, encoding='utf-8', errors='replace').read()
    fail = False
    print('\n  %s\n' % src)

    # 1 — preamble that belongs to main.tex
    stray = [(i, l.rstrip()) for i, l in enumerate(text.splitlines(), 1) if STRAY.match(l)]
    if stray:
        fail = True
        print('  FAIL  preamble in a fragment. These lines belong in main.tex')
        print('        and will break it:')
        for i, l in stray: print('          %d:%s' % (i, l))
        print('        Your file should start at \\section{...}')
    else:
        print('  ok    no stray preamble')

    # 2 — environments, named so the message is usable
    b = Counter(re.findall(r'\\begin\{([A-Za-z*]+)\}', text))
    e = Counter(re.findall(r'\\end\{([A-Za-z*]+)\}', text))
    bad = [(n, b[n], e[n]) for n in sorted(set(b) | set(e)) if b[n] != e[n]]
    if bad:
        fail = True
        print('  FAIL  unbalanced environments:')
        for n, x, y in bad: print('          %-18s %d begin, %d end' % (n, x, y))
    else:
        print('  ok    \\begin / \\end balanced')

    # 3 — cite keys. Work on the whole text, so a \cite wrapped across a
    #     line break is still found; a line-by-line grep silently misses it.
    keys = set()
    for group in CITE.findall(text):
        for k in group.split(','):
            k = k.strip()
            if k: keys.add(k)
    if not os.path.exists(bib):
        print('  warn  no %s — skipping the cite-key check' % bib)
    elif not keys:
        print('  warn  no \\cite{} in this file — fine if the plan needs no sources')
    else:
        have = set(BIBKEY.findall(open(bib, encoding='utf-8', errors='replace').read()))
        missing = sorted(keys - have)
        if missing:
            fail = True
            print('  FAIL  cite key(s) not in %s — these render as (?):' % os.path.basename(bib))
            for k in missing: print('          %s' % k)
        else:
            print('  ok    all %d cite key(s) are in %s' % (len(keys), os.path.basename(bib)))

    g = text.count('[GAP:'); w = text.count('[WEB:')
    print('  note  %d open [GAP:] marker(s), %d [WEB:] marker(s)' % (g, w))
    print('        Gaps are a result, not a defect. Leave them in.')

    if fail:
        print('\n  Not ready — fix the FAIL lines above first.\n'); return 1
    print('\n  Ready to upload.\n'); return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
