#!/usr/bin/env python3
"""Conformance check for sources/notes/. Reports; repairs nothing.

A checker that edits is one that can make its own findings disappear, so
this one cannot. Every problem it prints is for a person to fix.

    python3 tools/check_notes.py
"""
import os, re, sys, glob

SECTIONS = ['What it is', 'Problem and aim', 'What it covers', 'Main claim',
            'Evidence given', 'Limits', 'Relevance to my tool', 'My take']
FRONT = ['title', 'kind', 'authors', 'year', 'doi', 'source_file', 'read', 'added']
KINDS = ['paper', 'preprint', 'blog', 'slides', 'doc', 'video', 'code', 'other']

def body_of(text, heading):
    m = re.search(r'^##\s+%s\s*$' % re.escape(heading), text, re.M)
    if not m: return None
    nxt = re.search(r'^##\s+', text[m.end():], re.M)
    return text[m.end(): m.end() + nxt.start()] if nxt else text[m.end():]

def main():
    notes = sorted(glob.glob('sources/notes/*.md'))
    if not notes:
        print('\n  no notes yet in sources/notes/\n'); return 0
    index = open('sources/_index.md', encoding='utf-8').read() if os.path.exists('sources/_index.md') else ''
    errs = warns = 0
    print()
    for p in notes:
        t = open(p, encoding='utf-8').read()
        print('  %s' % p)
        fm = re.match(r'^---\n(.*?)\n---\n', t, re.S)
        meta = {}
        if not fm:
            print('    ERROR   no YAML frontmatter'); errs += 1
        else:
            for line in fm.group(1).splitlines():
                if ':' in line:
                    k, v = line.split(':', 1)
                    meta[k.strip()] = v.strip().strip('"').strip("'")
            for k in FRONT:
                if k not in meta:
                    print('    ERROR   frontmatter missing: %s' % k); errs += 1

        have = [s for s in SECTIONS if re.search(r'^##\s+%s\s*$' % re.escape(s), t, re.M)]
        if len(have) == len(SECTIONS):
            print('    ok      %d of %d sections' % (len(have), len(SECTIONS)))
        else:
            for s in SECTIONS:
                if s not in have:
                    print('    ERROR   section missing: ## %s' % s); errs += 1

        mt = body_of(t, 'My take')
        if mt is not None and mt.strip():
            print('    WARN    ## My take is not empty. If you wrote it, good.')
            print('            If an agent did, delete it — that section is yours.')
            warns += 1

        kind = meta.get('kind', '')
        if kind and kind not in KINDS:
            print('    WARN    kind: %s is not one of %s' % (kind, '/'.join(KINDS)))
            warns += 1

        ev = body_of(t, 'Evidence given')
        if ev is not None:
            body = ev.strip().lower()
            if not body:
                print('    ERROR   ## Evidence given is empty. If the source shows')
                print('            nothing, write: none — asserted, not shown')
                errs += 1
            elif kind in ('paper', 'preprint') and not re.search(r'\d', ev):
                # only a research paper is expected to carry numbers
                print('    WARN    ## Evidence given has no numbers and kind is %s.' % kind)
                print('            citecheck would have to reopen the source to do')
                print('            what this section is for.')
                warns += 1
            elif 'none' in body and kind in ('paper', 'preprint'):
                print('    note    evidence recorded as none for a %s — unusual,' % kind)
                print('            but correct for a commentary or an editorial.')

        doi = meta.get('doi', '')
        if doi in ('', 'none') and not meta.get('url'):
            if kind not in ('doc', 'code', 'other', ''):
                print('    WARN    no doi and no url — where did this come from?')
                warns += 1
        if doi and doi != 'none':
            if not doi.startswith('10.'):
                print('    WARN    doi does not look like a DOI: %s' % doi); warns += 1
            if index and doi not in index:
                print('    ERROR   doi not found in sources/_index.md'); errs += 1
        elif doi == 'none':
            src = meta.get('url') or 'an internal document'
            print('    note    doi: none — from %s' % src)

        sf = meta.get('source_file', '')
        if sf and not os.path.exists(sf):
            print('    ERROR   source_file does not exist: %s' % sf); errs += 1

    print('\n  %d note(s), %d error(s), %d warning(s)\n' % (len(notes), errs, warns))
    return 1 if errs else 0

if __name__ == '__main__':
    sys.exit(main())
