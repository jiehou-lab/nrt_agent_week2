#!/usr/bin/env python3
"""Turn a source document into plain text the notes agent can read.

A .pptx or .docx is a zip of XML. `pdftotext` fails on one, Read cannot
render one, and `strings` finds nothing once the zip is compressed -- so
without this, a slide deck or a Word document is simply unreadable.

Standard library only. No install, no network.

    python3 tools/totext.py sources/deck.pptx
    python3 tools/totext.py sources/post.html
    python3 tools/totext.py sources/*.docx

Handles  .pptx .ppt(x-like)  .docx  .html .htm  .md .txt .csv
PDFs are not handled here: use `pdftotext file.pdf -`, or just Read it.
"""
import html as _html
import os, re, sys, zipfile

def _xml_text(xml, tag, joiner='\n'):
    """Pull the text out of <...:tag> elements, in document order."""
    parts = re.findall(r'<(?:\w+:)?%s[^>]*>(.*?)</(?:\w+:)?%s>' % (tag, tag),
                       xml, re.S)
    return joiner.join(_html.unescape(re.sub(r'<[^>]+>', '', p)) for p in parts)

def from_pptx(path):
    out = []
    with zipfile.ZipFile(path) as z:
        slides = sorted((n for n in z.namelist()
                         if re.match(r'ppt/slides/slide\d+\.xml$', n)),
                        key=lambda n: int(re.search(r'(\d+)', n).group(1)))
        notes = {int(re.search(r'(\d+)', n).group(1)): n for n in z.namelist()
                 if re.match(r'ppt/notesSlides/notesSlide\d+\.xml$', n)}
        for i, s in enumerate(slides, 1):
            body = _xml_text(z.read(s).decode('utf-8', 'replace'), 't')
            out.append('--- slide %d ---\n%s' % (i, body.strip()))
            if i in notes:
                n = _xml_text(z.read(notes[i]).decode('utf-8', 'replace'), 't')
                if n.strip():
                    out.append('[speaker notes] ' + n.strip())
    return '\n\n'.join(out)

def from_docx(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read('word/document.xml').decode('utf-8', 'replace')
    # paragraph by paragraph, so runs inside one paragraph stay on one line
    paras = re.findall(r'<w:p[ >].*?</w:p>', xml, re.S)
    lines = []
    for p in paras:
        runs = re.findall(r'<w:t[^>]*>(.*?)</w:t>', p, re.S)
        line = ''.join(_html.unescape(r) for r in runs).strip()
        lines.append(line)
    return '\n'.join(lines)

def from_html(path):
    s = open(path, encoding='utf-8', errors='replace').read()
    s = re.sub(r'(?is)<(script|style|nav|footer|aside)[^>]*>.*?</\1>', ' ', s)
    s = re.sub(r'(?i)<(br|/p|/div|/h[1-6]|/li|/tr)[^>]*>', '\n', s)
    s = re.sub(r'<[^>]+>', ' ', s)
    s = _html.unescape(s)
    s = re.sub(r'[ \t]+', ' ', s)
    return re.sub(r'\n\s*\n\s*\n+', '\n\n', s).strip()

def convert(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.pptx': return from_pptx(path)
    if ext == '.docx': return from_docx(path)
    if ext in ('.html', '.htm'): return from_html(path)
    if ext in ('.md', '.txt', '.csv', '.tsv', '.json', '.tex'):
        return open(path, encoding='utf-8', errors='replace').read()
    if ext == '.pdf':
        raise SystemExit('  %s is a PDF. Use:  pdftotext "%s" -\n'
                         '  or just let Claude Read it directly.' % (path, path))
    raise SystemExit('  do not know how to read %s (%s).\n'
                     '  Save it as PDF, HTML or plain text and try again.' % (path, ext or 'no extension'))

def main(argv):
    if not argv:
        raise SystemExit(__doc__)
    for path in argv:
        if not os.path.exists(path):
            print('  no such file: %s' % path, file=sys.stderr); continue
        text = convert(path)
        if len(argv) > 1:
            print('\n========== %s ==========\n' % path)
        print(text)
        if not text.strip():
            print('  (no text found — the file may be images only. '
                  'Export it as PDF and Read that instead.)', file=sys.stderr)

if __name__ == '__main__':
    main(sys.argv[1:])
