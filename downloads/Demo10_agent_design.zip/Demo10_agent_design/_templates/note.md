---
title: ""
kind: paper          # paper | preprint | blog | slides | doc | video | code | other
authors: ""          # or the organisation, or "unknown"
year:
doi: ""              # or `none` — only publications have one
url: ""              # where it came from, if it came from the web
source_file: "sources/"
read: full           # full | skimmed | extracted-text-only
added: YYYY-MM-DD
---

## What it is

One line. A 2019 randomised trial; a vendor's launch post; our group's
plate-QC SOP; a conference keynote. Who made it, when, and why it exists.
For anything that is not peer reviewed, **say who benefits from believing it**.

## Problem and aim

What did they think was missing, and why? Before the claim — a note that
opens with the claim has already accepted their framing.

## What it covers

A paper: design, data, n, method. A deck or a post: what ground it actually
covers, and what it skips. Enough that someone could tell whether it
applies to their own case.

## Main claim

What it says it showed, or is arguing for. One or two sentences, in their
terms.

## Evidence given

Numbers with their source. `0.71 → 0.78 AUC, Table 2, n=418` — not
"accuracy improved". A number without its source cannot be checked later.

If there is none — an opinion piece, a product announcement, a tutorial —
then write **`none — asserted, not shown`**. That is a finding, not a gap
in your note.

## Limits

What it cannot tell you, including anything the author admits. For a
non-peer-reviewed source this is usually the most useful section.

## Relevance to my tool

Why did you collect this? What part of the thing you want to build does it
bear on? Phrased so you can disagree with it.

## My take

<!-- Yours. No agent writes here. An empty section is correct until you
     have read the thing and formed a view. -->
