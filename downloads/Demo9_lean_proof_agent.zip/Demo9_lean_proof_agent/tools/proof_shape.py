#!/usr/bin/env python3
"""Measure the SHAPE of a Lean proof against a contract you wrote.

This is not a proof checker. Lean's kernel decides whether something is a
proof; this decides whether it is the proof you asked for. The two checks are
different jobs and neither replaces the other:

    lake build            exact, semantic   -> is it a proof?
    check_proof_shape     heuristic, textual -> is it THE proof you wanted?

Everything here is syntactic. It reads text and counts. It can be fooled by
unusual formatting, and it is meant to be - a shape budget is a guide rail you
tune, not a guarantee. The guarantee is the kernel.
"""
import argparse
import json
import re
import sys
from pathlib import Path

# tactic-ish leading tokens we recognise; anything else still counts as a step
TACTIC_RE = re.compile(r"^\s*(?:·\s*|\.\s*|<;>\s*)?([A-Za-z_][A-Za-z0-9_'.]*)")
SORRY_RE = re.compile(r"\b(sorry|admit|stop)\b")


def strip_comments(src):
    src = re.sub(r"/-.*?-/", " ", src, flags=re.S)      # block comments
    src = re.sub(r"--[^\n]*", "", src)                   # line comments
    return src


def theorem_block(src, name):
    """Text of `theorem <name> ... := by ...` up to the next top-level decl."""
    pat = re.compile(r"^\s*(?:private\s+|protected\s+)?"
                     r"(theorem|lemma|example|def)\s+" + re.escape(name) + r"\b",
                     re.M)
    m = pat.search(src)
    if not m:
        return None
    start = m.start()
    nxt = re.compile(r"^\s*(?:private\s+|protected\s+)?"
                     r"(theorem|lemma|example|def|namespace|end|open)\b", re.M)
    m2 = nxt.search(src, m.end())
    return src[start:m2.start()] if m2 else src[start:]


def steps_of(block):
    """One step per non-blank line inside the proof body, with its depth."""
    if ":= by" in block:
        body = block.split(":= by", 1)[1]
    elif re.search(r"\bby\b", block):
        body = re.split(r"\bby\b", block, 1)[1]
    else:
        body = block
    out = []
    for raw in body.split("\n"):
        if not raw.strip():
            continue
        indent = len(raw) - len(raw.lstrip())
        stripped = raw.strip()
        if stripped.startswith("|"):
            # `| inl h =>` is a case arm, not a tactic; name it for readability
            tac = "case"
        else:
            m = TACTIC_RE.match(raw)
            tac = m.group(1) if m else (stripped.split() or ["?"])[0]
        out.append({"text": stripped, "tactic": tac, "indent": indent})
    if out:
        base = min(s["indent"] for s in out)
        for s in out:
            s["depth"] = (s["indent"] - base) // 2
    return out


def normalise(s):
    return re.sub(r"\s+", " ", s).strip()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--proof", required=True, help="the .lean file holding the candidate")
    p.add_argument("--contract", required=True, help="the JSON shape contract")
    p.add_argument("--out")
    a = p.parse_args()

    try:
        src = Path(a.proof).read_text()
    except FileNotFoundError:
        sys.stderr.write("no such file: %s\n" % a.proof)
        raise SystemExit(2)
    try:
        contract = json.loads(Path(a.contract).read_text())
    except FileNotFoundError:
        sys.stderr.write("no such file: %s\n" % a.contract)
        raise SystemExit(2)

    name = contract["theorem"]
    clean = strip_comments(src)
    block = theorem_block(clean, name)

    checks = []

    def check(n, ok, detail):
        checks.append({"check": n, "passed": bool(ok), "detail": detail})

    if block is None:
        check("theorem_present", False,
              "no theorem, lemma or example named %r in %s" % (name, a.proof))
        out = {"tool": "check_proof_shape", "theorem": name, "measured": {},
               "checks": checks, "n_failed": 1, "verdict": "rejected",
               "failed_checks": ["theorem_present"]}
        text = json.dumps(out, indent=2)
        if a.out:
            Path(a.out).parent.mkdir(parents=True, exist_ok=True)
            Path(a.out).write_text(text + "\n")
        print(text)
        return

    check("theorem_present", True, "found %r" % name)

    steps = steps_of(block)
    tactics = [s["tactic"] for s in steps]
    haves = [s["text"] for s in steps if s["tactic"] == "have"]
    depth = max((s["depth"] for s in steps), default=0)
    measured = {"n_steps": len(steps), "n_haves": len(haves),
                "max_depth": depth, "tactics_used": sorted(set(tactics))}

    # 1. an incomplete proof is not a short proof
    holes = SORRY_RE.findall(block)
    check("no_holes", not holes,
          "found %s" % ", ".join(sorted(set(holes))) if holes
          else "no sorry / admit")

    # 2. the step budget - this is the detour check
    budget = contract.get("max_steps")
    if budget is not None:
        check("within_step_budget", len(steps) <= budget,
              "%d steps, budget %d" % (len(steps), budget))

    # 3. the route you asked for survived
    required = contract.get("required_haves", [])
    missing = [r for r in required
               if not any(normalise(r) in normalise(h) for h in haves)]
    if required:
        check("required_steps_present", not missing,
              "missing intermediate statement(s): %s" % "; ".join(missing)
              if missing else "all %d present" % len(required))

    # 4. stayed inside the toolbox
    allowed = contract.get("allowed_tactics")
    if allowed:
        stray = sorted({t for t in tactics if t not in allowed})
        check("only_allowed_tactics", not stray,
              "used outside the allowed set: %s" % ", ".join(stray)
              if stray else "all %d tactics allowed" % len(set(tactics)))

    banned = contract.get("forbidden_tactics", [])
    if banned:
        used = sorted({t for t in tactics if t in banned})
        check("no_forbidden_tactics", not used,
              "used: %s" % ", ".join(used) if used else "none used")

    # 5. flatness
    maxd = contract.get("max_depth")
    if maxd is not None:
        check("within_depth", depth <= maxd, "depth %d, limit %d" % (depth, maxd))

    failed = [c for c in checks if not c["passed"]]
    detour = None
    if budget:
        detour = round(len(steps) / budget, 2)

    out = {"tool": "check_proof_shape",
           "theorem": name,
           "proof_from": a.proof,
           "contract_from": a.contract,
           "measured": measured,
           "detour_ratio": detour,
           "checks": checks,
           "n_failed": len(failed),
           "verdict": "accepted" if not failed else "rejected",
           "failed_checks": [c["check"] for c in failed]}
    text = json.dumps(out, indent=2, ensure_ascii=False)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
