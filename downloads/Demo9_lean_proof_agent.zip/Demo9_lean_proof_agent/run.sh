#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
exec streamlit run app.py
