# Demo 9 — a checker that cannot be argued with, and one that can

A Lean project, a shape checker, and two subagents. It exists to make one
distinction concrete:

    lake build          exact, semantic      is it a proof?
    check_proof_shape   heuristic, textual   is it THE proof you wanted?

Mathematics is nearly the only field that gets the first kind. Almost every
check in the other demos on this site is the second kind wearing a lab coat.

## The problem it addresses

You know the argument goes step 1 → step 2. The model finds step 1 → a → b → c
→ step 2. It compiles. Lean is satisfied. You are not: the proof is valid and
no longer shows the argument you cared about.

Nothing in the kernel's verdict rewards brevity or your route. So you supply
both — as a **skeleton** the agent may not rewrite, and a **contract** a script
can measure.

## Try it with no Lean installed

    python3 tools/proof_shape.py --proof lean/Demo/Detour.lean \
                                 --contract contracts/sum_bound.json

`rejected`, detour ratio 5.0, and — the interesting one — the intermediate
statement `n + n = 2 * n` has disappeared from a proof that still compiles.

## With Lean

See `SETUP.md`. **The Lean half of this package has not been run by its author**
— no toolchain was available. It is core Lean 4, no Mathlib, so it should build
in seconds. Please report what breaks.

## Layout

    lean/Demo/Skeleton.lean   the route a person chose, with `sorry` holes
    lean/Demo/Direct.lean     the proof they had in mind        (3 steps)
    lean/Demo/Detour.lean     a valid proof that wandered       (15 steps)
    contracts/sum_bound.json  the shape they asked for
    tools/proof_shape.py      the measurement - no model in it
    server.py                 MCP server exposing check_proof_shape
    .claude/agents/           hole-filler, shape-referee
    prompts/                  three prompts, ready to paste
    app.py                    the GUI

Full guide: https://jiehou-lab.github.io/nrt_agent_week2/guides/demo9.html
