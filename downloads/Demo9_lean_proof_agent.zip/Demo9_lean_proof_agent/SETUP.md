# Setup

> **Read this first.** The Python half of this package (the shape checker, the
> MCP server, the app) was built and tested. **The Lean half was not run** by
> whoever assembled it — no Lean toolchain was available on that machine. The
> Lean files are short and written against core Lean 4 with no Mathlib, but
> treat `lake build` as unconfirmed until it works on yours, and report what
> breaks.

## 1. The part that works with no Lean at all

```bash
unzip Demo9_lean_proof_agent.zip
cd Demo9_lean_proof_agent
python3 tools/proof_shape.py \
    --proof lean/Demo/Detour.lean \
    --contract contracts/sum_bound.json
```

No toolchain, no install, no model. You should see `"verdict": "rejected"` and a
detour ratio of 5.0.

For the app:

```bash
python3 -m venv .demo_venv && source .demo_venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The **Does it compile?** tab will tell you Lean is missing and disable itself.
Everything else works.

## 2. Lean

```bash
curl https://elan.lean-lang.org/elan-init.sh -sSf | sh
# restart your shell, then:
cd lean
lake build
```

The project pins a toolchain in `lean/lean-toolchain` and uses **no Mathlib**, so
the build should be seconds rather than the hour a Mathlib download takes. If
the pinned version is not available, edit that file to a Lean 4 release you have.

## 3. The Lean MCP server

The Lean side is reached through **lean-lsp-mcp**, which is a separate project:

    https://github.com/oOo0oOo/lean-lsp-mcp

Follow its own README for installation — it documents Claude Code setup, and its
instructions will be current in a way that a copy pasted in here would not be.
It needs `uv`, and it recommends running `lake build` manually once before
starting the MCP server so the first call does not time out.

`.mcp.json` in this package already declares both servers:

```json
{
  "mcpServers": {
    "proof-shape": { "command": "python3", "args": ["server.py"] },
    "lean-lsp":    { "command": "uvx", "args": ["lean-lsp-mcp"],
                     "env": { "LEAN_PROJECT_PATH": "${PWD}/lean" } }
  }
}
```

If `lean-lsp-mcp` wants a different invocation or a different environment
variable, fix it here — that one file is the whole integration.

## 4. Check it

```bash
claude
/mcp
```

You want `proof-shape` connected with one tool, and `lean-lsp` connected with
its own set. If only `proof-shape` connects, prompts 2 and 3 still work; prompt
1 needs Lean.
