Put agent-written attempts here. The app picks up any `.lean` file in this
folder, so you can compare a generated proof against the skeleton and the
contract without touching `lean/Demo/`.

`.claude/settings.json` allows writing here and only *asks* before writing into
`lean/` — the skeleton is the human's file.
