/-
  The route YOU already know, written down before the agent sees it.

  Each `sorry` is a hole. The agent's job is to replace holes, not to choose
  a path between them. Detours can still happen inside a hole - but a hole is
  small, and the statement on either side of it is fixed by you.

  Core Lean 4 only. No Mathlib, so `lake build` takes seconds.
-/

namespace Demo

/-- Step 1 -> step 2, stated by hand.
    a ≤ n and b ≤ n, therefore a + b ≤ 2 * n. -/
theorem sum_bound (a b n : Nat) (ha : a ≤ n) (hb : b ≤ n) :
    a + b ≤ 2 * n := by
  have h1 : a + b ≤ n + n := by sorry
  have h2 : n + n = 2 * n := by sorry
  sorry

end Demo
