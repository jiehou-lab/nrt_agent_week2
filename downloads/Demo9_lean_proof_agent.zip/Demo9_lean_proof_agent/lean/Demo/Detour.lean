/-
  A proof that COMPILES and is still the wrong answer for a human reader:
  it reaches the goal by a different route, restates things, and buries the
  two steps the mathematician cared about.

  Lean's kernel is perfectly happy with this. That is the point.
-/
namespace Demo

theorem sum_bound (a b n : Nat) (ha : a ≤ n) (hb : b ≤ n) :
    a + b ≤ 2 * n := by
  cases Nat.eq_zero_or_pos n with
  | inl hz =>
    subst hz
    have ha0 : a = 0 := Nat.le_zero.mp ha
    have hb0 : b = 0 := Nat.le_zero.mp hb
    subst ha0
    subst hb0
    simp
  | inr hpos =>
    have step : a + b ≤ n + b := Nat.add_le_add_right ha b
    have step2 : n + b ≤ n + n := Nat.add_le_add_left hb n
    have chain : a + b ≤ n + n := Nat.le_trans step step2
    have two : 2 * n = n + n := by omega
    rw [two]
    exact chain

end Demo
