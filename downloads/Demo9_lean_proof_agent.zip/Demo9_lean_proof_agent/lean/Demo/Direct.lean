/- The proof the mathematician had in mind: three steps, no wandering. -/
namespace Demo

theorem sum_bound (a b n : Nat) (ha : a ≤ n) (hb : b ≤ n) :
    a + b ≤ 2 * n := by
  have h1 : a + b ≤ n + n := Nat.add_le_add ha hb
  have h2 : n + n = 2 * n := by omega
  omega

end Demo
