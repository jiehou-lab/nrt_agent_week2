#!/usr/bin/env python3
"""Demo 9 — a proof, and two different checks on it.

    Lean's kernel        is it a proof?            exact, semantic
    check_proof_shape    is it THE proof?          heuristic, textual

The app runs the second one always, and the first one only if a Lean toolchain
is actually installed. It is honest about which of the two it managed to run.
"""
import json
import os
import shutil
import subprocess
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
LEAN = ROOT / "lean"

st.set_page_config(page_title="Lean — proof shape", layout="wide")


def lean_available():
    return shutil.which("lake") is not None


def run_shape(proof, contract):
    p = subprocess.run(
        ["python3", str(ROOT / "tools" / "proof_shape.py"),
         "--proof", str(proof), "--contract", str(contract)],
        cwd=str(ROOT), capture_output=True, text=True)
    try:
        return json.loads(p.stdout), p.stderr
    except json.JSONDecodeError:
        return None, (p.stderr or p.stdout)


def run_build():
    p = subprocess.run(["lake", "build"], cwd=str(LEAN),
                       capture_output=True, text=True, timeout=600,
                       env=os.environ.copy())
    return p.returncode, (p.stdout or "") + (p.stderr or "")


# ----------------------------------------------------------------- sidebar
st.sidebar.header("Inputs")
candidates = sorted(list((LEAN / "Demo").glob("*.lean")) +
                    list((ROOT / "candidates").glob("*.lean")))
labels = [str(p.relative_to(ROOT)) for p in candidates]
default = next((i for i, l in enumerate(labels) if l.endswith("Detour.lean")), 0)
choice = st.sidebar.selectbox("Candidate proof", labels, index=default)
proof_path = ROOT / choice

contracts = sorted((ROOT / "contracts").glob("*.json"))
clabels = [str(p.relative_to(ROOT)) for p in contracts]
cchoice = st.sidebar.selectbox("Shape contract", clabels, index=0)
contract_path = ROOT / cchoice

st.sidebar.divider()
st.sidebar.caption("Environment")
st.sidebar.markdown("Lean toolchain (`lake`): **%s**"
                    % ("found" if lean_available() else "not found"))
st.sidebar.markdown("Shape checker: **always available** (pure Python)")

# ----------------------------------------------------------------- header
st.title("Two checks on one proof")
st.code("lake build          exact, semantic      -> is it a proof?\n"
        "check_proof_shape   heuristic, textual   -> is it THE proof you wanted?",
        language="text")
st.write(
    "A proof can pass the first and fail the second. That is not a bug in Lean — "
    "the kernel has no opinion about whether an argument is the one you meant to "
    "make. **The second check is yours to write, and yours to tune.**"
)

tab_shape, tab_side, tab_build = st.tabs(
    ["Shape check", "Side by side", "Does it compile?"])

# ----------------------------------------------------------------- shape
with tab_shape:
    contract = json.loads(contract_path.read_text())
    st.subheader("The contract — what the mathematician asked for")
    c1, c2 = st.columns(2)
    c1.metric("step budget", contract.get("max_steps", "—"))
    c2.metric("max nesting depth", contract.get("max_depth", "—"))
    st.markdown("**Intermediate statements that must survive**")
    for h in contract.get("required_haves", []):
        st.markdown("- `%s`" % h)
    st.caption("Allowed tactics: " +
               ", ".join("`%s`" % t for t in contract.get("allowed_tactics", [])))

    st.divider()
    result, err = run_shape(proof_path, contract_path)
    if result is None:
        st.error("the checker did not return JSON")
        st.code(err[:2000], language="text")
    else:
        m = result["measured"]
        v = result["verdict"]
        (st.success if v == "accepted" else st.error)(
            "**%s** — %d step%s against a budget of %s"
            % (v, m.get("n_steps", 0), "" if m.get("n_steps") == 1 else "s",
               contract.get("max_steps", "—")))
        k1, k2, k3 = st.columns(3)
        k1.metric("steps", m.get("n_steps", 0))
        k2.metric("detour ratio", result.get("detour_ratio") or "—")
        k3.metric("nesting depth", m.get("max_depth", 0))

        for c in result["checks"]:
            icon = "✅" if c["passed"] else "❌"
            st.markdown("%s **%s** — %s" % (icon, c["check"], c["detail"]))

        with st.expander("raw tool output"):
            st.json(result)

# ----------------------------------------------------------------- side by side
with tab_side:
    st.subheader("The route you asked for, and the route you got")
    skel = LEAN / "Demo" / "Skeleton.lean"
    a, b = st.columns(2)
    with a:
        st.markdown("**Skeleton** — written by the mathematician")
        st.code(skel.read_text() if skel.exists() else "(no skeleton)", language="lean")
    with b:
        st.markdown("**Candidate** — `%s`" % choice)
        st.code(proof_path.read_text(), language="lean")
    st.info(
        "The holes are the only thing an agent is allowed to change. Everything "
        "between them is the argument, and it was chosen by a person."
    )

# ----------------------------------------------------------------- build
with tab_build:
    st.subheader("The check that cannot be argued with")
    if not lean_available():
        st.warning(
            "No Lean toolchain found on PATH, so this tab cannot run. "
            "The shape check still works — it is pure Python and never needed Lean. "
            "See `SETUP.md` for installing `elan`, then reload."
        )
        st.code("curl https://elan.lean-lang.org/elan-init.sh -sSf | sh\n"
                "cd lean && lake build", language="bash")
    else:
        st.write("Runs `lake build` in `lean/`. First run compiles the project; "
                 "later runs are cached.")
        if st.button("lake build", type="primary"):
            with st.spinner("building…"):
                try:
                    code, out = run_build()
                except subprocess.TimeoutExpired:
                    code, out = 1, "timed out after 600s"
            if code == 0:
                st.success("Lean accepted it. It is a proof.")
            else:
                st.error("Lean rejected it (exit %d). It is not a proof — the "
                         "shape check is irrelevant until this passes." % code)
            st.code(out[-6000:] or "(no output)", language="text")

st.divider()
st.markdown(
    "#### The question to take to your own work\n"
    "The kernel is an oracle: it cannot be persuaded, and it cannot be wrong about "
    "whether something is a proof. Almost no other field gets one. But notice that "
    "**it still could not tell you the proof had wandered** — that took a second, "
    "much weaker, entirely hand-written check. Ask of your own verifier: which of "
    "these two am I building, and am I pretending it is the other?"
)
