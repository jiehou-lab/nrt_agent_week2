# Lean proof agent — two checkers, two jobs

This project pairs a theorem prover with a shape checker. They answer different
questions and neither replaces the other.

    lake build / lean-lsp     exact, semantic     is it a proof?
    check_proof_shape         heuristic, textual  is it THE proof we wanted?

## Workflow

1. Start from a skeleton in `lean/Demo/Skeleton.lean`. The `have` statements are
   the route a person chose; the `sorry` holes are the work.
2. Fill **one hole at a time**, via the `hole-filler` subagent. Never rewrite a
   neighbouring step to make a hole easier.
3. When the file builds, check the shape with `check_proof_shape` against the
   contract in `contracts/`.

## Rules

- A proof containing `sorry` is not a short proof. It is not a proof.
- Do not edit `contracts/*.json`. The contract is the human's statement of
  intent; loosening it to make a check pass defeats the purpose.
- Report step counts as the tool measured them. Do not round "15 steps" into
  "a few extra steps".
- Lean files under `lean/` are edited only with permission — the settings file
  is deliberately set to `ask` there.
