# Prompt 3 — the loop that actually converges

    lean/Demo/Detour.lean compiles but fails the shape contract.

    Rewrite it so that it still compiles AND satisfies contracts/sum_bound.json:
    at most 3 steps, no nesting, and both required `have` statements present.

    After each attempt: build it, then run check_proof_shape. Keep going until
    both pass, or tell me why the contract cannot be met.

This is the evaluator-optimiser pattern from Demo 8, in the one setting where it
genuinely converges: the acceptance test is exact, so "it got shorter and still
compiles" is a fact rather than an opinion.
