# Prompt 1 — fill the holes, one at a time

    Open lean/Demo/Skeleton.lean. It has three `sorry` holes.

    Use the hole-filler subagent to close the FIRST hole only. Do not touch
    any other line. Report the goal you saw, the tactic you used, and whether
    the file still builds.

    Then do the same for the second hole, and the third, one at a time.

Why one at a time: a subagent given the whole file will rewrite the skeleton to
suit whatever route it finds easiest. Handing it one hole makes the route
non-negotiable.
