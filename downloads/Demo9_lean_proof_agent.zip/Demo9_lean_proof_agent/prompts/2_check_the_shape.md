# Prompt 2 — is it the proof I asked for?

    Use the shape-referee subagent to check lean/Demo/Detour.lean against
    contracts/sum_bound.json.

    Report the verdict, the detour ratio, and every failed check. Tell me
    specifically which intermediate statement disappeared.

This file compiles. Lean is perfectly happy with it. The referee is not.
