#!/usr/bin/env python3
"""MCP server for the proof-shape checker - standard library only.

It exposes ONE tool. Lean itself is reached through a separate MCP server
(lean-lsp-mcp), which is the thing that decides whether a proof is a proof.
This server only decides whether it is the proof you asked for.
"""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

TOOLS = [
    {
        "name": "check_proof_shape",
        "description": ("Check a Lean proof against a shape contract: a step budget, the "
                        "intermediate `have` statements that must survive, the tactics "
                        "allowed, and the nesting depth. Use this AFTER Lean has accepted "
                        "the proof, to decide whether it took the intended route or "
                        "wandered. It does not check correctness - Lean does that."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "proof": {"type": "string",
                          "description": "path to the .lean file holding the candidate"},
                "contract": {"type": "string",
                             "description": "path to the JSON shape contract"},
                "out": {"type": "string"},
            },
            "required": ["proof", "contract"],
        },
        "script": "tools/proof_shape.py",
        "flags": {"proof": "--proof", "contract": "--contract", "out": "--out"},
    },
]
BY_NAME = {t["name"]: t for t in TOOLS}


def validate(schema, args):
    errs, props = [], schema.get("properties", {})
    for k in schema.get("required", []):
        if k not in args:
            errs.append("missing required argument '%s'" % k)
    for k, v in args.items():
        if k not in props:
            errs.append("unknown argument '%s' (allowed: %s)" % (k, ", ".join(props)))
            continue
        s = props[k]
        if s.get("type") == "string" and not isinstance(v, str):
            errs.append("'%s' must be a string, got %r" % (k, v))
    return errs


def call(name, args):
    spec = BY_NAME.get(name)
    if not spec:
        return "unknown tool: %s" % name, True
    errs = validate(spec["inputSchema"], args)
    if errs:
        return "argument validation failed (nothing was run):\n- " + "\n- ".join(errs), True
    cmd = [sys.executable, str(ROOT / spec["script"])]
    for k, v in args.items():
        cmd += [spec["flags"][k], str(v)]
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return (p.stdout or "") + (("\n[stderr]\n" + p.stderr) if p.stderr else ""), p.returncode != 0


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            ver = (msg.get("params") or {}).get("protocolVersion") or "2024-11-05"
            res = {"protocolVersion": ver, "capabilities": {"tools": {}},
                   "serverInfo": {"name": "proof-shape", "version": "1.0.0"}}
        elif method == "tools/list":
            res = {"tools": [{k: t[k] for k in ("name", "description", "inputSchema")}
                             for t in TOOLS]}
        elif method == "tools/call":
            pr = msg.get("params") or {}
            text, err = call(pr.get("name"), pr.get("arguments") or {})
            res = {"content": [{"type": "text", "text": text}], "isError": err}
        elif mid is None:
            continue
        else:
            print(json.dumps({"jsonrpc": "2.0", "id": mid,
                              "error": {"code": -32601, "message": "no method " + str(method)}}),
                  flush=True)
            continue
        if mid is not None:
            print(json.dumps({"jsonrpc": "2.0", "id": mid, "result": res}), flush=True)


if __name__ == "__main__":
    main()
