# What you should see

## The shape checker, on the three files

| file | steps | detour ratio | verdict | failed |
|---|---|---|---|---|
| `Direct.lean` | 3 | 1.0 | `accepted` | — |
| `Detour.lean` | 15 | 5.0 | `rejected` | `within_step_budget`, `required_steps_present`, `only_allowed_tactics`, `within_depth` |
| `Skeleton.lean` | 3 | 1.0 | `rejected` | `no_holes`, `only_allowed_tactics`, `no_forbidden_tactics` |

The skeleton row matters: **an unfinished proof is not a short proof.** `sorry`
is caught by its own check, before any question of length.

The row that carries the lesson is `Detour.lean` failing
`required_steps_present`:

    missing intermediate statement(s): n + n = 2 * n

That proof is correct. Lean accepts it. And the step the mathematician actually
wanted to see is gone.

## Through the MCP server

`tools/list` returns one tool, `check_proof_shape`. Calling it on `Direct.lean`
returns `accepted` with `isError: false`; on `Detour.lean`, `rejected`. Omitting
the `contract` argument is refused before anything runs:

    argument validation failed (nothing was run):
    - missing required argument 'contract'

## Lean itself

**Unverified.** `lake build` in `lean/` should succeed for `Direct.lean` and
`Detour.lean` and report three `sorry` warnings for `Skeleton.lean`. If your
run disagrees, the Lean files are the suspect part of this package — not the
Python.
