# Demo 12 — Zotero + Obsidian + Claude Code

**Level:** anyone who finished Week 3. The capstone for Demos 10 and 11.
**Time:** 30–40 minutes.

---

## There is nothing to connect

Both halves are folders.

A Zotero library on disk is a `.bib` export, a `.csv` export, and a
`storage/` folder of PDFs. An Obsidian vault is a folder of Markdown. Put them
side by side, `cd` to the parent, run `claude`. That is the integration.

No MCP server, no API key, no Local REST API plugin, no `.mcp.json`. Every
guide to this subject spends its first ten minutes on setup you do not need.

```
workspace/
├── CLAUDE.md          one contract covering both halves
├── .claude/
│   ├── settings.json  zotero/ read-only, vault/topics/ unwritable
│   └── agents/
│       ├── linker.md  repairs the join. may change one field.
│       └── drift.md   reports divergence. no Write tool.
├── zotero/            the library. READ ONLY.
│   ├── My Library.bib
│   ├── My Library.csv
│   └── storage/
└── vault/
    ├── papers/        seven notes, written over ten months
    ├── topics/        what I believe. denied to every agent.
    ├── proposals/     where changes to topics/ get suggested
    └── _templates/
```

## So what is the demo?

The setup is trivial. **Keeping the two in step is not**, and that is the part
no workflow post covers.

Seven notes in `vault/papers/`, written between November 2025 and August 2026.
Nine items in the library. Every note was correct the day it was written.
Since then the library has been corrected, a duplicate has been typed in by
hand, an attachment has been replaced with a published version, and a PDF has
appeared in `storage/` that no item claims.

**None of the notes know any of this.**

The one field that holds the two systems together:

```yaml
zotero_key: 4J8KQW2M
```

Eight characters, stable, and the only thing in either system that is. Not the
title, which gets retyped. Not the cite key, which Better BibTeX regenerates
whenever you fix metadata. Not the filename, which carries a year that may turn
out to be wrong.

In this workspace, **two of the seven notes have a `zotero_key` that resolves.**

## Run it

```bash
cd workspace
git init && git add -A && git commit -m "before the agent"
claude
```

Then the five prompts in `SETUP.md`.

## Files

| File | What it is |
|---|---|
| `SETUP.md` | Five prompts, and what to watch for |
| `ANSWER_KEY.md` | **After you run it.** Every planted drift. |

## Where this sits

| | |
|---|---|
| **Demo 10** | The vault. Are the notes right? |
| **Demo 11** | The library. Can you cite what you have? |
| **Demo 12** | The join. **Do the two still agree?** |

Same literature across all three, so this one can spend its time on the
connection rather than re-teaching the papers.
