# Setup and run

> **New here?** Read the [handbook](https://jiehou-lab.github.io/nrt_agent_week2/guides/research-system.html)
> first. This demo assumes the vocabulary of Demos 10 and 11.
>
> **Already run it?** `MAINTENANCE.md` has the monthly reconcile — the routine
> this whole demo exists to justify.

---

## What is in this package

```
Demo12_zotero_obsidian_claude/
├── README.md
├── SETUP.md                  ← you are here
├── MAINTENANCE.md            the monthly reconcile. the point of the demo.
├── ANSWER_KEY.md             SPOILER — read last
└── workspace/                ← run `claude` from HERE
    ├── CLAUDE.md             ★ ONE contract covering TWO owners
    ├── .claude/
    │   ├── settings.json     ★ zotero/ and vault/topics/ both denied
    │   └── agents/
    │       ├── linker.md         repairs the join. may change ONE field.
    │       └── drift.md          reports divergence.  NO Write
    ├── zotero/               NEVER   the Demo 11 library, unchanged
    │   ├── My Library.bib
    │   ├── My Library.csv
    │   └── storage/
    └── vault/
        ├── papers/           7 notes, written Nov 2025 → Aug 2026
        ├── topics/           what YOU believe.  Edit AND Write denied
        ├── proposals/        where changes to topics/ get suggested
        └── _templates/paper.md    ★ note the zotero_key field
```

**Two owners in one folder.** `zotero/` is the system of record for *what you
have*; `vault/` is the record of *what you think*. Information flows one way
and the deny list enforces it.

**The whole integration is one frontmatter field:**

```yaml
zotero_key: 4J8KQW2M
```

Nine library items. Seven notes. **Two of the seven keys resolve.**

## 0. What you need

- **Claude Code**, working.
- **`pdftotext`** — `brew install poppler` / `sudo apt install poppler-utils`.
- **Obsidian** — optional. Point it at `workspace/vault/` if you want to see
  the property tables. Nothing here requires it.
- **Zotero** — not required at all. The library is on disk.

## 1. Look at both halves

```bash
cd workspace
ls zotero/ vault/papers/
column -s, -t < "zotero/My Library.csv" | cut -c1-110
```

**Expected:** nine rows in the CSV, seven notes in `vault/papers/`.

A quick look at the state of the join before you start:

```bash
grep -H "^zotero_key:" vault/papers/*.md
```

**Expected:** seven lines, one of them absent entirely. Note the dates in the note frontmatter —
November 2025 through August 2026. They were written over ten months, and the
library has moved under them.

```bash
git init && git add -A && git commit -m "before the agent"
```

## 2. Read the contract

```bash
cat CLAUDE.md
cat .claude/settings.json
```

Two owners, one folder:

| Path | Owner | Agent may |
|---|---|---|
| `zotero/` | Zotero | **read only** |
| `vault/papers/` | me, with help | read, write |
| `vault/topics/` | **me** | read, link — **never write** |
| `vault/proposals/` | the agent | write |

Both `Edit` and `Write` are denied on `zotero/` and on `vault/topics/`. The
first protects the system of record; the second protects your own thinking.
`Bash(mv:./zotero/**)` is denied too — one plausible "tidy up" and every
attachment path in the library stops resolving.

---

# The five prompts

### Prompt 1 — how bad is it?

```
Check the zotero_key in every note in vault/papers/ against
My Library.csv. Report which resolve and which do not. Change nothing.
```

> Resolve: ____ of 7

Before continuing, ask it the other question:

```
Now the other direction: which library items have no note, and which
folders in zotero/storage/ belong to no library item?
```

That second one is the direction everybody forgets, and it is where the most
valuable document in this workspace is hiding.

### Prompt 2 — repair the join

```
Use the linker subagent to repair the zotero_key field in vault/papers/.
Change nothing else.
```

`linker` may change **one field**. Not the prose, not the claims, not the
years — even the ones that are wrong. Those are a different problem and
belong to the next prompt.

Watch for the note it should refuse to fix. One paper appears in the library
**twice**, and picking one key silently would bury that.

```bash
git diff
```

Every hunk should be a single `zotero_key:` line. If anything else changed,
the agent exceeded its brief — tell it so and `git checkout .`.

### Prompt 3 — now find the drift

```
Use the drift subagent on the whole workspace.
```

`drift` has **no Write tool**. Six kinds of divergence, both directions: dead
joins, wrong records, stale metadata, unverifiable notes, orphans, and two
notes about one paper that contradict each other.

Read the last section of its report first. It answers: **which of my
conclusions rest on a note you just flagged?** A broken join is bookkeeping.
A belief resting on one is the reason to care.

### Prompt 4 — the belief that is wrong

Open `vault/topics/Tm prediction — what I believe.md`. It says, in writing,
that it asserts two incompatible things and has not reconciled them.

```
Use the drift findings to write a proposal for
vault/topics/Tm prediction — what I believe.md. Quote the exact lines to
remove and the exact lines to add, and cite the zotero_key behind each claim.
```

The proposal goes to `vault/proposals/`. **`topics/` is denied** — check:

```bash
git status --short vault/topics/
```

Empty. The agent could not have touched it even if it tried.

Apply the proposal by hand, or don't. That choice is the feature: a belief you
accepted is yours, and one that appeared while you weren't looking is not.

### Prompt 5 — the note you cannot cite

```
What is in vault/papers/supplement_table_s3.md, where did it come from,
and why can I not cite it?
```

This note holds the strongest evidence in the workspace. Its source sits in
`zotero/storage/` and belongs to **no library item**, so it will never appear
in a bibliography, a citation manager, or a reference list.

The fix is not a vault fix. It is: open Zotero, add the file, give it metadata.
The agent should say exactly that, and should not pretend it can do it.

---

## Afterwards

1. `cat ANSWER_KEY.md`.
2. For each miss: **which layer should have caught it?** A line in
   `CLAUDE.md`, a rule in `settings.json`, or a tool the agent should not have
   had. Change that one file and `git checkout .`.

## Using this on your own work

From Zotero: select a collection → right-click → **Export Collection** →
Better BibTeX with *Export Files* ticked, and again as CSV. Drop both next to
your vault. Copy `CLAUDE.md` and `.claude/` across.

Then add `zotero_key` to your note template and start filling it in. That one
field is the entire integration, and it is worth more than any MCP server you
could install — because it survives a Zotero update, a vault rename, a change
of reference manager, and a laptop.

---

## Next

**`MAINTENANCE.md`** — the operating manual: the daily and weekly loops, how to add each kind of new material, what decays over time and how to notice, and a troubleshooting table.

**The [handbook](https://jiehou-lab.github.io/nrt_agent_week2/guides/research-system.html)** — all four demos as one system, with the full file map and the prerequisites.

**`ANSWER_KEY.md`** — now, but not before.
