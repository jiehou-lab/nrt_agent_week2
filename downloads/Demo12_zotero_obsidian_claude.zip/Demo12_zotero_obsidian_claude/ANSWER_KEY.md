# Answer key — where the two systems went out of step

**Read after running the demo.**

Seven notes, nine library items, six storage folders. **Two of the seven notes
have a `zotero_key` that resolves.** Every note was correct the day it was
written.

---

## The join, as shipped

| Note | `zotero_key` | Status |
|---|---|---|
| `thermonet2_reread.md` | `4J8KQW2M` | ✅ resolves |
| `lindqvist2024_benchmark.md` | `R2M9VKHT` | ✅ resolves — but see #3 |
| `okafor2024_thermonet2.md` | `WQ7TN4LC` | ⚠️ resolves to the **wrong record** |
| `tanaka_1998_values.md` | `P5HD6ZXN` | ⚠️ resolves, **attachment missing** |
| `deep_ensembles_notes.md` | `K9PLM4XT` | ❌ **dead key** |
| `ferrara_assays.md` | *(absent)* | ❌ **no key** |
| `supplement_table_s3.md` | `unknown` | ❌ source has **no library item** |

---

## 1. Dead key — `deep_ensembles_notes.md`
`K9PLM4XT` is in nothing. The paper it describes **is** in the library, as
`N7XC3BQD` (the 2023 preprint). Matchable on DOI `10.1101/2023.08.19.554021`
and on the title.

A `linker` run should fix this with high confidence. It is the easy one, and
it is the one everybody tests on.

## 2. No key at all — `ferrara_assays.md`
Written November 2025, before the convention existed. Matchable on DOI
`10.1016/abr.2022.612` → `8QW4LJ3F`.

Note that the same defect appears from the other side as *"library item
`8QW4LJ3F` has no note."* One problem, two symptoms, and an agent that checks
only one direction reports it twice as if they were two.

## 3. Wrong record of the right paper — `okafor2024_thermonet2.md`
`WQ7TN4LC` **resolves**, so a naive check passes it. But `WQ7TN4LC` is the
hand-typed duplicate from Demo 11: same DOI as `4J8KQW2M`, wrong year (2023),
title-case mangled, **no attachment**, and an `Extra` field reading *"added by
hand from the conference programme -- check before citing."*

So the note is attached to a record that cannot be verified, for a paper whose
real record is sitting right there.

**`linker` should refuse to fix this silently.** Two library items share one
DOI; choosing one buries the duplicate. The correct behaviour is to report both
keys, say which has the attachment, and stop. An agent that quietly repoints
the note to `4J8KQW2M` has done the right thing for the wrong reason and hidden
a library problem you needed to see.

## 4. Stale metadata propagated into a note — `lindqvist2024_benchmark.md`
The key is correct. Everything else is a year out of date:

| | Note says | Library says | **PDF says** |
|---|---|---|---|
| Year | 2024 | 2024 | **2025** |
| Venue | bioRxiv | bioRxiv | **Methods in Protein Science 12(1)** |
| DOI | 10.1101/2024.06.03.597112 | same | **10.3310/mps.2025.0044** |

The library's `Extra` column says it outright: *"replaced attachment with
published version 2026-06-30."* The file was updated; the metadata never was;
the note copied the metadata before any of it happened.

Three artefacts now carry the wrong year — the note's frontmatter, its
filename, and the line in it reading *"Cited in the group slides as 'Lindqvist
2024 preprint'."* **The error has already left the workspace.**

This is the one to dwell on. It shows why `CLAUDE.md` says the attachment
outranks the library and the library outranks the note: three copies of a fact
in three places, and only one of them is the paper.

## 5. Valid key, unverifiable note — `tanaka_1998_values.md`
`P5HD6ZXN` resolves. Its attachment path points at a folder that does not
exist. The note's numbers — lysozyme 72.1, RNase A 62.8, myoglobin 78.4 — may
be perfectly correct, and **nothing in this workspace can confirm them**.

The right verdict is `cannot tell from what is here`. An agent that marks these
numbers verified has verified a note against itself.

The paper is in `storage/` under `TD53BV9K`, the junk `scan0043` entry. A good
run connects those. A very good run notices that the scan has **no text layer**,
so even after the link is repaired the numbers can only be read visually.

## 6. Two notes, one paper, opposite conclusions
`okafor2024_thermonet2.md` (March) says **23% improvement**, taken from the
abstract.
`thermonet2_reread.md` (July) says **7.5%**, taken from Table 2, and adds:
*"My earlier note on this paper is wrong. Leaving it there for now because I
cannot remember which of the two I cited in the group slides."*

The vault holds both. Worse: **they point at different `zotero_key`s**, so
nothing in the join reveals they are about the same paper. The duplicate in
Zotero has propagated into the vault, and the vault no longer knows it is
contradicting itself.

`drift` should catch this by DOI, not by key. The PDF settles it: 5.3 → 4.9 is
7.5%, and TSP-Struct at 4.6 is better than both.

## 7. The orphan, one level up — `supplement_table_s3.md`
`zotero_key: unknown`. The source is
`zotero/storage/9FGM2XPQ/...Supplementary Information.pdf`, which **belongs to
no library item** — the orphan from Demo 11, now with a note attached to it.

The note is right and its numbers check out:

> 148 of 212 unique sequences (69.8%) appear in both splits.
> Sequence not seen in training: n=43, **RMSE 8.0 °C**.

This is the strongest evidence in the whole workspace — the ThermoNet-2
authors' own data confirming their critic — and it **cannot appear in any
bibliography**, because bibliographies are built from the library and the
library does not know the file exists.

The note says so itself: *"This is the most important number I have and I
cannot cite it."*

**The fix is not a vault fix.** It is: open Zotero, add the file, give it
metadata. An agent that offers to "add it to the library" is about to write to
`zotero/`, which is denied — and should instead say plainly that this one is
yours to do.

## 8. Items with no note
`C8VJ2RWD` (SeqTm, the baseline everything compares against) and `H4KX7MBT`
(TSP-Struct, the method that actually beats ThermoNet-2) are both in the
library, both with no attachment and no note.

Not a defect — an accurate picture. The two methods the whole topic turns on
are the two you have never read.

---

## What Prompt 4 should produce

`vault/topics/Tm prediction — what I believe.md` currently says:

> 1. Sequence-only prediction improved substantially in 2023–24 — see
>    [[deep_ensembles_notes]] (4.4 °C) and [[okafor2024_thermonet2]] (23%).
> 2. But [[lindqvist2024_benchmark]] says most of that disappears.
> 3. I have not reconciled 1 and 2. **This note currently says both.**

Every citation in point 1 is compromised:

- `deep_ensembles_notes` has a **dead key**, and its 4.4 °C is the
  **preprint's** number — superseded by 4.9 in the published version.
- `okafor2024_thermonet2` points at the **wrong record** and its 23% is
  contradicted by `thermonet2_reread`.

So point 1 does not survive, and points 2 and 3 resolve together. The proposal
should remove point 1, replace it, and cite keys rather than note names:

> Sequence-only Tm prediction has **not** been shown to improve much on
> unseen proteins. On a sequence-disjoint split ThermoNet-2 scores 7.8 °C
> against a mean-predictor baseline of 8.4 (`R2M9VKHT`), and the authors'
> own supplement reports 8.0 °C on the 43 held-out records whose sequences
> were not in training (`9FGM2XPQ`, unfiled). The 4.4 and the 23% that this
> note previously rested on come from a preprint and from an abstract that
> its own Table 2 contradicts.

And it should note that one of its two sources **is not in the library**.

---

## Scoring

| Caught | Reading |
|---|---|
| 0–2 | It checked keys resolve and stopped. |
| 3–4 | It repaired the join in one direction. |
| 5–6 | Both directions, including the orphan. |
| 7–8 | It also refused to silently fix #3, and connected #6 by DOI. |

## Which layer catches what

| Defect | What catches it |
|---|---|
| 1, 2 | Any join check. The easy ones. |
| 3 | Comparing **DOIs**, not keys — a `CLAUDE.md` instruction |
| 4 | "The attachment outranks the library outranks the note" |
| 5 | Admitting `cannot tell`, rather than verifying a note against itself |
| 6 | Cross-note comparison by DOI — impossible for a per-file pass |
| 7 | Reconciling `storage/` **back** against the library |
| Writes to `zotero/` or `topics/` | `settings.json`. Only that. |

## The point

Demo 10 asked whether the notes are right. Demo 11 asked whether you can cite
what you have. This one asks the question that only shows up after a year:
**do the two still agree?**

Nothing here was anyone's mistake. Metadata got corrected, a duplicate got
typed in, an attachment got replaced, a file got dropped in a folder. Every
note was right when written. The drift is what ordinary use does to two systems
that have no shared identifier — which is why the one line that matters in this
entire package is `zotero_key:`.
