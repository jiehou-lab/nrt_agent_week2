# Living with the join

This is the one that needs maintaining, because it is the only part of the
system that breaks **without anyone doing anything wrong.**

---

## What drift is, and why it is nobody's fault

Two systems that agreed when each note was written:

- You fix a year in Zotero. The note still has the old one.
- You replace an attachment with the published version. The note cites the
  preprint.
- You merge a duplicate. Half your notes point at the key that lost.
- You drag in a supplement. It is in `storage/` and in no bibliography.

Every one of those is ordinary, correct behaviour in both tools. **Drift
accumulates at roughly the rate you edit Zotero** — fix metadata on ten items
this month and expect ten stale notes.

That is the whole reason this demo exists.

---

## The monthly reconcile — ten minutes

Run it on the first of the month, **and always after a Zotero clean-up
session.**

```bash
cd ~/research-system/Demo12_zotero_obsidian_claude/workspace
git add -A && git commit -m "before reconcile"
claude
```

### 1. Check the joins

```
Check the zotero_key in every note in vault/papers/ against
My Library.csv. Report which resolve and which do not. Change nothing.
```

Then the direction people forget:

```
Now the other direction: which library items have no note, and which
folders in zotero/storage/ belong to no library item?
```

### 2. Repair

```
Use the linker subagent to repair the zotero_key field in vault/papers/.
Change nothing else.
```

```bash
git diff
```

**Every hunk should be a single `zotero_key:` line.** If anything else changed,
the agent exceeded its brief — say so and `git checkout .`.

### 3. Find the drift the join cannot see

```
Use the drift subagent on the whole workspace.
```

Read **the last section first**: *which conclusions in `topics/` rest on a note
you just flagged?* A broken link is bookkeeping. A belief resting on one is why
you ran this.

### 4. Fix each finding in the right place

`drift` says whether each fix belongs in the vault or in Zotero. They are
different jobs:

| Finding | Where it gets fixed |
|---|---|
| Dead or wrong `zotero_key` | Here — `linker` |
| Note's year/venue/DOI is stale | Here — update the note's frontmatter from the attachment |
| **Library** metadata is stale | **Zotero.** Then re-export, then re-run this. |
| Attachment missing from `storage/` | **Zotero.** Re-attach the file. |
| Orphan in `storage/` | **Zotero.** Add it as an attachment to the right item. |
| Two notes, one paper, contradicting | **You.** Read both, keep one, note why. |

---

## The one field

```yaml
zotero_key: 4J8KQW2M
```

Everything in this demo is about that line. Three things are **not** joins and
should never be used as one:

| Not a join | Why |
|---|---|
| The **title** | Gets retyped, truncated, title-cased. |
| The **cite key** | Better BibTeX regenerates it whenever you fix metadata. |
| The **filename** | Carries a year that may turn out to be wrong. |

**A key that resolves is not a key that is right.** The nastiest case in this
demo points at a real record — the hand-typed duplicate, same DOI, no
attachment — so every naive check passes it. When two items share a DOI,
`linker` is told to **refuse and report both**, because silently picking one
buries a library problem you needed to see.

### Adopting the convention in a vault that predates it

Add `zotero_key:` to your note template, then let `linker` backfill in batches:

```
Use the linker subagent on the 20 oldest notes in vault/papers/.
```

Twenty at a time, `git diff` after each batch. Expect maybe 80% matched
automatically on DOI and title; the rest need you, and the ones that need you
are usually the ones with a real problem underneath.

---

## Adding new material

### A paper, start to finish
1. Add it in **Zotero** by DOI — *Add Item by Identifier*.
2. Re-export the `.bib`, `.csv` and `storage/` **as a set** into `zotero/`.
3. Note its item key from the `Key` column.
4. Write the note in `vault/papers/` with that key in the frontmatter.
5. `pdftotext zotero/storage/<KEY>/*.pdf -` and read it before writing claims.

### After any Zotero clean-up
Re-export, then run the monthly reconcile immediately. **That is exactly when
new drift appears**, and it is far cheaper to fix the week it happens than a
year later when you cannot remember which version you read.

---

## Two rules that keep it honest

**The attachment outranks the library, and the library outranks the note.**
Three copies of a fact in three places, and only one of them is the paper.
When they disagree, the PDF wins, and the note gets corrected — not the
library, and never by an agent.

**Nothing in `vault/` ever writes to `zotero/`.** Enforced by the deny list,
and worth keeping even when it is inconvenient.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Every key suddenly dead after a re-export | You exported from a different library or group. Check the `Key` column against `ls zotero/storage/`. |
| `linker` repointed a note and I think it was wrong | `git diff` shows exactly which key changed. Revert the one line. |
| Keys changed after merging duplicates in Zotero | Expected — a merge keeps one key. Run `linker`; this is its main job. |
| `drift` reports more every month | Normal if you are actively curating Zotero. It is a backlog, not a regression. Clear it monthly and it stays small. |
| An agent wrote into `zotero/` | Shouldn't be possible. You launched `claude` above `workspace/`, or the JSON does not parse. |
| Start over | `git checkout . && git clean -fd` |
