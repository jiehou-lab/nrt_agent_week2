# Research workspace — Zotero and Obsidian, one folder

Two systems, one working directory. They have different owners and different
rules, and the whole point of this folder is the **join** between them.

| Path | Owner | You may |
|---|---|---|
| `zotero/` | Zotero. The system of record for *what I have*. | **Read only.** |
| `vault/papers/` | Me, with your help. One note per paper. | Read, write. |
| `vault/topics/` | **Me.** What I think. | Read, link to. **Never write.** |
| `vault/proposals/` | You. Suggested changes to `topics/`. | Write. |
| `vault/web/` | Clipped pages. | Read, write. |

Nothing in `vault/` ever writes to `zotero/`. Changes to the library are made
by me, in Zotero. You propose; I apply.

## The join

A note and a library item are connected by **one field and one field only**:

```yaml
zotero_key: 4J8KQW2M
```

The item key is the eight-character string that names the `zotero/storage/`
folder and appears in the `Key` column of `My Library.csv`. It is stable.

**Nothing else is a join.** Not the title, which gets retyped. Not the cite key,
which Better BibTeX regenerates whenever metadata changes. Not the filename,
which carries a year that may turn out to be wrong. Those are all hints for
*finding* the right key, never substitutes for it.

Every note in `vault/papers/` must carry a `zotero_key` that resolves, or
`zotero_key: none` with a line saying why.

## Metadata belongs to Zotero

A note records **what I think**. The library records **what the item is**.
Where a note's frontmatter repeats metadata — year, venue, DOI — that copy is a
convenience and the library is authoritative. When they disagree, the note is
stale and you say so; you do not edit the library to match the note.

And where the *library* disagrees with its own attachment, the attachment wins —
the metadata is whatever was true on import.

## Drift

These two systems go out of step through ordinary use. Both directions matter:

- A note whose `zotero_key` no longer resolves.
- A note pointing at the wrong record of the right paper.
- A note repeating metadata the library has since corrected.
- A library item with an attachment and no note.
- Two notes about one paper that disagree with each other.
- A file in `zotero/storage/` that no library item claims — invisible to both
  systems at once.

Report all of these. Never silently pick one side.

## Before writing or changing a note

1. Resolve the `zotero_key` against `My Library.csv`.
2. Open the attachment in `zotero/storage/<KEY>/` and read it.
3. Compare what the note says against what the document says.
4. If you cannot do 1 or 2, say so in the note and stop. A note you could not
   verify is more useful labelled than silently rewritten.

Never state a number that is not in a source you opened. Never invent an item key.
