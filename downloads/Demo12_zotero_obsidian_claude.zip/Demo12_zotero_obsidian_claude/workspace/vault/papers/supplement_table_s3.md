---
type: paper
title: "ThermoNet-2 Supplementary Information"
authors: [Okafor, A.]
year: 2024
zotero_key: unknown
source_file: "zotero/storage/9FGM2XPQ/Okafor et al. - 2024 - Supplementary Information.pdf"
added: 2026-08-22
status: read
tags: [topic/thermostability, topic/evaluation]
---

# ThermoNet-2 supplement — Table S3

Found this by accident while looking through the storage folder. It is not
in my Zotero library and I do not know how it got there.

## Evidence
Note S2: **148 of 212 unique sequences (69.8%) appear in both splits.**

Table S3:

| Held-out records | n | RMSE |
|---|---|---|
| Sequence seen in training | 198 | 4.1 |
| **Sequence not seen** | 43 | **8.0** |
| All | 241 | 4.9 |

## My take
The authors measured the thing Lindqvist criticises them for, and reported it
in their own supplement. 8.0 and 7.8 are the same answer from two directions.
This is the most important number I have and I cannot cite it.
