---
type: paper
title: "Thermal denaturation assays: a practical comparison"
authors: [Ferrara, G.]
year: 2022
doi: "10.1016/abr.2022.612"
added: 2025-11-30
status: read
tags: [topic/methods]
---

# Ferrara 2022 — DSF vs DSC vs CD

Written before I started recording Zotero keys.

## Evidence
DSF and DSC agree within 1.2 °C for reversibly unfolding proteins; up to
6.4 °C apart for aggregation-prone ones.
**Buffer composition shifts Tm by 2–9 °C** across the conditions tested.

## My take
That buffer range is larger than the gap between any two predictors I have
read. Keep coming back to this.
