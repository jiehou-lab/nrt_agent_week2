---
type: paper
title: "ThermoNet-2 (re-read, with the tables this time)"
authors: [Okafor, A.]
year: 2024
zotero_key: 4J8KQW2M
doi: "10.4821/jcb.2024.0288"
added: 2026-07-14
status: read
tags: [topic/thermostability]
---

# Okafor 2024 — ThermoNet-2, second pass

Went back to this after RK could not reproduce it.

## What the tables actually say
Table 2: SeqTm 5.3, TSP-Struct **4.6**, ThermoNet-2 **4.9**.
So the improvement over the sequence baseline is **7.5%, not 23%** — and
TSP-Struct, which the paper's own Section 2 calls the strongest published
predictor, is *better* than ThermoNet-2.

Section 3: 1,204 **measurements** over **212 unique sequences**. Not 1,204 proteins.

## My take
My earlier note on this paper is wrong. Leaving it there for now because I
cannot remember which of the two I cited in the group slides.
