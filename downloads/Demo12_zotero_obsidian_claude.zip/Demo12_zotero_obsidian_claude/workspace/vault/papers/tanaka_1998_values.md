---
type: paper
title: "Calorimetric measurement of protein conformational stability"
authors: [Tanaka, H., Mori, S.]
year: 1998
zotero_key: P5HD6ZXN
added: 2026-04-19
status: read
tags: [topic/methods, reference-values]
---

# Tanaka & Mori 1998 — reference Tm values

## Evidence
Lysozyme 72.1 °C · RNase A 62.8 °C · Myoglobin 78.4 °C ·
Carbonic anhydrase n.d. (aggregates).
All in 20 mM sodium phosphate pH 7.0, 60 °C/hr scan rate.

## My take
These are the numbers I check our DSF runs against.
