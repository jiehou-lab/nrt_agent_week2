---
type: paper
title: "Sequence-only prediction of thermal stability with deep ensembles"
authors: [Okafor, A.]
year: 2023
zotero_key: K9PLM4XT
added: 2025-12-04
status: read
tags: [topic/thermostability]
---

# Okafor 2023 — deep ensembles

## Evidence
RMSE **4.4 °C** on a held-out set from 1,510 measurements. Beats the
structure-based predictor outright.

## My take
Best sequence-only number I have seen. This is the one to cite.
