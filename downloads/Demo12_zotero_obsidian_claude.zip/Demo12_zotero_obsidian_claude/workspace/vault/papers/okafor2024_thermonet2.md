---
type: paper
title: "ThermoNet-2: sequence-only prediction of protein melting temperature"
authors: [Okafor, A.]
year: 2023
zotero_key: WQ7TN4LC
doi: "10.4821/jcb.2024.0288"
added: 2026-03-02
status: read
tags: [topic/thermostability]
---

# Okafor 2024 — ThermoNet-2

## Claim
Sequence alone is enough for competitive Tm prediction.

## Evidence
Reduces prediction error by **23%** over the previous state of the art.
RMSE 4.9 °C, evaluated on 1,204 proteins.

## My take
Looks like the structure-based pipeline is now optional. Worth telling RK.
