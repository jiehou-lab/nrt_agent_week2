---
type: paper
title: "A sequence-disjoint benchmark for Tm prediction reveals optimistic reporting"
authors: [Lindqvist, K., Boateng, E.]
year: 2024
venue: "bioRxiv"
zotero_key: R2M9VKHT
doi: "10.1101/2024.06.03.597112"
added: 2026-01-09
status: read
tags: [topic/thermostability, topic/evaluation]
---

# Lindqvist & Boateng 2024 — BENCH-TM

## Claim
Record-level splitting inflates reported accuracy. On a sequence-disjoint
split, nothing beats a mean predictor by much.

## Evidence
ThermoNet-2: 7.8 °C on BENCH-TM against 4.9 reported.
Mean-predictor baseline 8.4 °C.

## My take
This is the paper that explains RK's reproduction failure.
Cited in the group slides as "Lindqvist 2024 preprint".
