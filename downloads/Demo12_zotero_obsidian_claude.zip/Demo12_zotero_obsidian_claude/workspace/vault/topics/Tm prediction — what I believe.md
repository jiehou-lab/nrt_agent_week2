---
type: topic
title: "Tm prediction — what I believe"
status: active
updated: 2026-08-22
tags: [topic/thermostability]
---

# Tm prediction — what I believe

My own note. Agents may link here and propose changes; they may not edit it.

## Current position

1. Sequence-only prediction improved substantially in 2023–24 —
   see [[deep_ensembles_notes]] (4.4 °C) and [[okafor2024_thermonet2]] (23%
   improvement).
2. But [[lindqvist2024_benchmark]] says most of that disappears under a
   sequence-disjoint split.
3. I have not reconciled 1 and 2. **This note currently says both.**

## Open

- Which number do I put in the proposal — 4.4, 4.9, or 7.8?
- RK's reproduction failure: unresolved as of the Sept meeting.
