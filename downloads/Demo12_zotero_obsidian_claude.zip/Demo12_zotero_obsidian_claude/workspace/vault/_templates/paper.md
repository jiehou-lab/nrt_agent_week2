---
type: paper
title: ""
authors: []
year:
venue: ""
doi: ""
zotero_key: ""          # 8 chars, from My Library.csv. REQUIRED, or `none` + a reason.
attachment_read:        # true | false — did I actually open the PDF?
added:
status: unread
tags: []
---

# <Author><Year> — <short title>

## Claim

## Evidence
Numbers, with the table or section they came from.

## Checks
Where the note, the library and the PDF agree or do not.

## Links

## My take
<!-- mine. agents do not write here. -->
