# Living with the radar

The demo runs once. The value is entirely in the second year, when the same
calls come round and you already know what you decided.

---

## The weekly loop — ten minutes

```bash
cd ~/research-system/Demo13_funding_radar/radar
python3 pipeline/export_vault.py
claude
```

**Expected output from the exporter:**

```
  new                 grants-gov-412903.md
  kept decision=pass  grants-gov-398812.md

1 new, 6 refreshed. Decisions preserved.
```

Then, always in this order:

```
Use the recurrence subagent. Which calls in this cycle are reissues
of ones I have already decided on?
```

**Before reading anything.** One prompt, and it regularly removes half the
list. A reissue whose blocker has not moved needs one paragraph quoting last
year's reason, not an afternoon.

Then triage whatever survives:

```
Use the triage subagent on inbox/<the solicitation>.
```

---

## Writing decisions down — the whole point

After each triage, open the note in `opportunities/` and fill in:

```yaml
decision: pass          # submit | watch | pass | ineligible
because: "one line, with the number that decided it"
decided_on: 2026-10-03
```

and the prose under `## Decision`.

**`because` must contain the actual reason, not the verdict.** Compare:

| Useless | Useful |
|---|---|
| `because: "not a good fit"` | `because: "$200k total cap. At 54.5% indirect that's ~$129k direct over 2 years. Can't staff a student."` |
| `because: "missed it"` | `because: "institutional down-select closed in October; LOI was due 1 Dec. Start in August next cycle."` |

Next year the second kind answers the question in five seconds. The first kind
makes you read the solicitation again.

**Distinguish `pass` from `ineligible`.** One says you chose not to; the other
says the door was shut. Next cycle that difference tells you whether to start
early or not at all.

---

## Why this exists

A real funding-radar database:

```sql
CREATE TABLE items    (uid, feed, source, title, url, org, score, rationale, ...);
CREATE TABLE feedback (uid TEXT, vote INTEGER, ts TEXT);
```

`items`: 90 rows. **`feedback`: 0 rows.**

The slot for the decision exists and is empty, because *"the $200k cap is below
what the work costs"* does not fit in an `INTEGER`. The reason goes nowhere, and
next year you read the call again.

Every habit on this page is about keeping that from happening.

---

## Keeping the profile true

`profile/research_profile.md` is the most important file here and the one that
decays silently. **Four of the five traps in this demo are caught by its
constraints table alone**, so a stale table produces confidently wrong triage.

### Re-check quarterly — four numbers

| | Changes when |
|---|---|
| **Uncommitted FTE** | you win or lose an award, or a student graduates |
| **Indirect rate** | your institution renegotiates. It moves. |
| **Smallest viable project** | stipends and tuition go up every year |
| **Collaborators in place** | someone leaves, or a new platform comes online |

### Re-check annually — the standing questions

The *"what I am trying to fund, in order"* list is what makes a fit memo
specific instead of enthusiastic. If it has not changed in two years, either
your programme is unusually stable or you stopped updating it.

### Ask the agent to check it against your actual work

```
Read my recent papers and notes. Does the research profile still describe
what I am working on? Propose changes — do not edit the profile.
```

`profile/` is denied, so it can only propose. Good: the profile is a statement
about yourself and should not be edited by something that inferred it.

---

## Adding new material

### A solicitation PDF or saved page
```bash
cp ~/Downloads/NSF-27-xxx.pdf radar/inbox/
```
Then `recurrence` first, `triage` second. If you have **both** the programme
page and the solicitation PDF, put both in — they often disagree on dates, and
the solicitation is authoritative.

### Pointing it at your own pipeline
`pipeline/export_vault.py` needs these columns: `uid`, `title`, `org`,
`ident`, `url`, `score`, `rationale`, `posted_date`, `close_date`.

```bash
python3 pipeline/export_vault.py --db /path/to/your.db --out opportunities/
```

**Test the preservation behaviour before you trust it.** Write a decision into
one note, re-run, confirm the text survived:

```bash
python3 pipeline/export_vault.py >/dev/null
grep -A3 "## Decision" opportunities/<the-one-you-edited>.md
```

A generator that silently eats your writing is the worst bug a system like this
can have, and it is invisible until the day you need what it ate. An earlier
version of this exporter did exactly that.

### Your own notes on a call
Under `## Decision` in the opportunity note. The exporter copies everything
below that heading through verbatim on every run.

---

## What the pipeline score is for

**It means "worth reading", never "worth applying for".**

In this demo the highest-scoring call is unsubmittable and the lowest-scoring
one is the only live fit. Both are the scorer working correctly — it matched
keywords in a title, which is all it had.

So: **do not tune the threshold.** A keyword filter cannot match a description
of your work that avoids your words, and lowering the cutoff just adds noise at
the bottom. The fix is a reader, not a number.

Two habits that follow from that:

1. **Read a few low scorers every cycle.** That is where the DOE call was.
2. **When triage disagrees with the score, write down which signal the scorer
   could not have had.** Over a year that list tells you what to add to the
   profile — or confirms the scorer is doing fine and the gap is structural.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Exporter wiped my decision | Should not happen — the `## Decision` block is preserved verbatim and tested. `git checkout .` restores it. If you modified the script, that is the bug to look for. |
| Triage recommends things I would decline | The constraints table is stale, or a constraint is missing. Add the rule that would have caught it to the decline list. |
| It missed a deadline buried in the document | Add to `CLAUDE.md`: *"list every date in the document, not the one on the cover."* |
| It wrote a memo for an ineligible call | `fitmemo` is told to refuse. Check triage actually ran first and returned `ineligible`. |
| `recurrence` found nothing, but I know I've seen this | It matches on agency, programme name and the reissue notice. If your log has no previous cycle recorded, there is nothing to match — that is the backlog, not a bug. |
| Agent tried to write to `radar.db` | Denied. Also `Bash(sqlite3:*)` is denied, which is the back door people forget. |
| Start over | `git checkout . && git clean -fd` |
