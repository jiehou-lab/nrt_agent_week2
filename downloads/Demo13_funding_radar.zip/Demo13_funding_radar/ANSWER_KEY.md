# Answer key — what is wrong with these six calls

**Read after running the demo.**

Six documents. The pipeline ranked them 96, 91, 90, 88, 85, 38.
**By fit, that ordering is close to reversed** — and the scorer was not wrong.
It matched keywords in a title and an abstract, which is all it had.

---

## NSF 26-512 — AI Institutes (pipeline: 96) → **ineligible**

The best scientific match in the set. Five of seven profile domains: genomic
foundation models, RNA structure, 3D genome, AI-ready datasets, agentic systems.
$16–20M over five years. Everything about the science says yes.

Three dates in the document, and the cover date is the one that does not matter:

| Date | What |
|---|---|
| **October 2025** | institutional down-select "typically closes" |
| **December 1, 2025** | Letter of Intent — **required** |
| February 3, 2026 | full proposal — the only date on the cover |

> *"An organization may appear as lead on **no more than one (1) proposal**…
> NSF will return without review all proposals in excess of this limit."*

> *"Proposals for which no Letter of Intent was received will not be accepted."*

> *"Prospective leads are strongly encouraged to contact their Office of
> Sponsored Programs no later than **October 2025**, as institutional
> down-select processes typically close well before the Letter of Intent
> deadline."*

The profile's decline list says: *"Anything whose LOI or institutional
down-select has already closed."* Today's date is past both.

**Verdict: `ineligible`, not `pass`.** The door is shut; you did not choose to
walk away. A triage that blurs those two is less useful, because next cycle the
difference tells you whether to start in August.

*Partial credit for finding the LOI. Full credit needs the down-select line,
which is the one that actually ends it — it is in the middle of an eligibility
paragraph nobody reads to the end.*

## NSF 26-512 program page — **two documents, one call, different deadlines**

`NSF-26-512_program_page.html` says **January 20, 2026**. The solicitation PDF
says **February 3, 2026**. Both are in `inbox/`.

The page settles it itself, in the footer:

> *"Program pages summarise the solicitation and are not authoritative; always
> check the solicitation PDF."*

It also omits the LOI and the submission limit entirely. **A triage run on the
program page alone would conclude the call is open and worth pursuing** — which
is exactly what happens when a scraper ingests the page rather than the PDF.

## NSF 26-534 — Foundation Models for Materials (pipeline: 85) → **pass**

Six profile keyword domains, all genuinely in the document: *foundation
models*, *machine learning*, *agentic AI*, *continual learning*, *AI-ready
datasets*, *deep learning*, *large language model*. The scorer did its job
perfectly.

Two independent killers:

**1. Cost share.** 25% non-federal, required, documented at submission. The
profile's decline list: *"Anything requiring cost share. A cost-share
requirement is a decline, not a negotiation."* **This needs no reading at all**
— it is on the cover panel, and the profile already decided.

**2. Wrong domain.** The out-of-scope paragraph:

> *"Proposals whose primary application domain is the life sciences — including
> genomics, structural biology, protein or nucleic acid modelling, plant
> science, agriculture, or biomedical applications — are **not responsive** to
> this solicitation and will be returned without review."*

Note where that sits: **after** the topic list, not before. Funders put the
invitation first and the refusal second, and a reader who stops when the
keywords look good never reaches it.

*A good triage names the cost share first, because it is cheaper to check.*

## USDA-NIFA-AFRI-0010447 — Crop Resilience (pipeline: 91) → **already decided**

Scientifically the best fit in the set: sorghum, gene expression prediction,
PlantCV phenotyping. Three profile domains, dead centre.

And the document says, in its own Reissue Notice:

> *"This funding opportunity **reissues USDA-NIFA-AFRI-0009812 (FY2025)**
> without substantive change to program area priorities, eligibility or award
> size."*

`opportunities/grants-gov-398812.md` is the FY2025 note, and it carries:

```yaml
decision: pass
decided_on: 2025-02-20
```

> *"$200,000 **total including indirect**. At our 54.5% rate that is about
> $129k of direct cost for a two-year project. One PhD student for two years is
> ~$180k direct. … If this is reissued at the same cap, the answer is the same.
> **Do not spend another afternoon reading it.**"*

The cap is unchanged. **The correct output is one paragraph quoting last
year's reason, and nothing else.**

The arithmetic is also in the new document, which is worth noticing
independently:

> *"An application requesting the full $200,000 therefore has approximately
> **$153,850** available for direct costs across the full project period."*

$153,850 over two years, against a smallest-viable-project of ~$180k direct.
The funder did the subtraction for you and it still does not reach.

*This is the prompt-1 payoff. An agent that triages this call from scratch has
produced a correct assessment and wasted the entire value of the decision log.*

## NIH PAR-26-118 — Genomic Data Science (pipeline: 88) → **gone**

Strong NHGRI alignment, $499k direct per year for five years, no limits, no
cost share. On the numbers it is the best fundable match in the set.

The first thing on the page:

> *"**NOTICE:** This Funding Opportunity has been **superseded by PAR-27-042**,
> published 14 August 2026. Applications submitted after the final receipt date
> of 5 June 2026 will be withdrawn without review. **Program area priorities
> have changed**; see the replacement announcement."*

Two failures are possible here and they are different:

- Missing the banner entirely and writing a memo for a dead call.
- Finding the banner and stopping. **The useful answer is: go and read
  PAR-27-042.** The programme still exists; only this announcement is dead, and
  the notice says the priorities changed, which is the thing worth knowing.

## DOE DE-FOA-0003291 — Predictive Biology (pipeline: **38**) → **submit**

The lowest score in the set, and the best fit.

The scorer's rationale is honest about why: *"Low keyword overlap. 'Predictive
understanding', 'feedstock', 'canopy scale'. One match on sorghum."* The
document simply does not use the profile's vocabulary — no "foundation model",
no "machine learning", no "deep learning".

Read AOI 1 against standing question 1:

| | |
|---|---|
| **Profile, standing question 1** | *"Cross-species transfer for expression prediction — a model trained on reference species, evaluated honestly on a feedstock genome it has not seen. **This is the one I most want funded.**"* |
| **DOE AOI 1** | *"…building models that predict expression from sequence in genotypes for which no measurement exists. Applications proposing to **transfer models trained in reference species to feedstock genomes** are encouraged to address the generalisation problem explicitly."* |

That is the same sentence written by two people who have never met.

And it clears every constraint:

| Constraint | This call |
|---|---|
| Cost share | not required |
| Submission limits | none |
| Award size | $500k–900k/yr × 3 — comfortably above the ~$180k floor |
| Domain | bioenergy feedstocks, sorghum named |
| Equipment | computation and field imaging; no wet lab needed |
| Pre-application | encouraged, not required — low cost to find out |

AOI 2 is the phenomics programme, including *"the calibration and drift
problems that arise when instruments are deployed across seasons and sites."*
AOI 3 is held-out benchmarks and shared evaluation.

**All three AOIs map onto the profile. It scored 38.**

*This is the finding. Not "the threshold needs tuning" — a keyword filter cannot
match a description of your work that avoids your words, and the fix is a reader,
not a number.*

---

## Final ordering

| Pipeline | Call | Reality |
|---|---|---|
| 96 | NSF 26-512 | **ineligible** — down-select closed |
| 91 | USDA 0010447 | **already passed**, same cap |
| 88 | NIH PAR-26-118 | **superseded** — go read PAR-27-042 |
| 85 | NSF 26-534 | **pass** — cost share, and out of scope |
| **38** | **DOE DE-FOA-0003291** | **submit** |

One call out of five is live, and it is the one the scorer ranked last.

## Scoring a run

| Caught | Reading |
|---|---|
| 0–2 | It read the science and not the eligibility. |
| 3–4 | It checked constraints, but triaged the USDA call from scratch. |
| 5–6 | It used the decision log and found the DOE fit. |
| 7+ | It also compared the two NSF documents and said to go read PAR-27-042. |

## Which layer catches what

| Trap | What catches it |
|---|---|
| Down-select closed | The **constraints half** of the profile. Nothing else. |
| Cost share | The decline list — before reading the document at all. |
| Budget cap | The indirect rate and the floor, both numbers in the profile. |
| USDA reissue | The decision log, checked **first**. `CLAUDE.md` order of work. |
| Out-of-scope paragraph | Reading past the topic list. |
| Superseded banner | Reading the top of the page. |
| Two documents disagreeing | "The solicitation is authoritative" — a `CLAUDE.md` rule. |
| **DOE at 38** | A reader. No rule and no threshold produces this one. |

## The point

Four of the five live traps are caught by the **constraints half of the
profile**, which is the half nobody writes down. A profile listing only research
interests cannot produce a triage — it can only produce enthusiasm, which you
already had.

The pipeline was never wrong. It scored titles. The agent's job is the thing
that comes after: reading the document, applying your constraints, and
remembering what you decided last February.
