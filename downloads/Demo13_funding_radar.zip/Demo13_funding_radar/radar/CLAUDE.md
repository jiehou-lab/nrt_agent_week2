# Funding radar

A pipeline already finds solicitations. This folder is where **I decide what to
do about them**, and the two jobs have different owners.

| Path | Owner | You may |
|---|---|---|
| `pipeline/` | the scraper. System of record for *what exists*. | **Read only.** Never write to `radar.db`. |
| `inbox/` | documents I dropped in myself | read |
| `opportunities/` | one note per call. Generated, then annotated. | write — **except** the `## Decision` block and the `decision` / `because` / `decided_on` fields |
| `profile/` | **me** | read. **Never write.** |
| `memos/` | fit memos | write |

## The pipeline score is not a fit

`pipeline_score` comes from a keyword and LLM pass over a title and an abstract.
It has not read the solicitation and it knows nothing in `profile/`. Treat it as
*"worth reading"*, never as *"worth applying for"*.

A high score with a low fit is the normal case and the one that wastes time.

## Read the constraints before the science

`profile/research_profile.md` has two halves. The second half — the constraints
table and the decline list — is what decides. Check it **first**, because a call
I am ineligible for does not need a scientific assessment:

1. **Eligibility.** Limited submission? PI limits? Early-career only? If the
   institutional down-select has closed, the call is gone whatever the fit.
2. **Deadlines, all of them.** A letter of intent or pre-application deadline is
   a real deadline. Find every date in the document, not the one on the cover.
3. **Money.** Compare the cap against the indirect rate and the smallest viable
   project in the profile. A cap stated as *total* is not the same as *direct*.
4. **Cost share.** Listed as an automatic decline. Say so and stop.
5. **Scope.** Does the document exclude my domain? Read the out-of-scope
   paragraph before the topic list; funders put the refusal after the invitation.

Only then: is the science a fit?

## Check the decision log before writing anything

`opportunities/*.md` carries `decision:` and `because:` from previous cycles.
Solicitations reissue annually under new numbers. **Before assessing a call,
look for a previous cycle of the same programme** — match on agency, title and
the reissue notice in the document, not on the opportunity number, which always
changes.

If I passed on it before, lead with that and with the reason. If the reason
still holds, say so and stop. The point of the log is that I do not read the
same call twice.

## Two documents, one call

A programme page and a solicitation PDF often disagree, and the **solicitation
is authoritative**. Where they differ on a date, say which you used and why.

## What a fit memo is

Not a summary of the solicitation — I can read that myself. A memo answers:

- **Can I submit at all?** Eligibility, limits, deadlines, cost share. One line each.
- **What would I actually propose?** Named against the standing questions in the
  profile. If none of them fit, the honest memo says the call is fundable and
  not mine.
- **What is missing?** The collaborator, the preliminary data, the platform I do
  not have.
- **What does it cost me to find out?** LOI effort, down-select timing.

Every claim about the solicitation cites the page or section it came from.
Never state a deadline, a dollar figure or an eligibility rule that is not in
the document.

## Never

- Write to `pipeline/radar.db` or anything in `pipeline/`.
- Write to `profile/`. Propose changes in a memo instead.
- Overwrite a `## Decision` block. Those are mine, and they are the only thing
  here that cannot be regenerated.
