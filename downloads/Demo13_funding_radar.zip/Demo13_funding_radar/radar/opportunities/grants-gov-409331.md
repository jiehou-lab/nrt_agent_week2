---
type: opportunity
uid: "grants.gov:409331"
title: "Predictive Biology for Sustainable Bioenergy Feedstocks"
agency: "DOE Office of Science"
ident: "DE-FOA-0003291"
url: "https://grants.gov/search-results-detail/409331"
posted: 2026-01-06
closes: 2026-03-26
pipeline_score: 38
matched_domains: [Plant / crop / bioenergy science]
solicitation_file:
decision: undecided
because:
decided_on:
---

# DE-FOA-0003291 — Predictive Biology for Sustainable Bioenergy Feedstocks

## Pipeline rationale

> Low keyword overlap. 'Predictive understanding', 'feedstock', 'canopy scale'. One match on sorghum.

*This is the keyword/LLM scorer talking, from the title and abstract only.*
*It has not read the solicitation and knows nothing about my constraints.*

## What the solicitation actually says

<!-- filled in after reading the document in inbox/ -->

## Decision

<!-- mine. the exporter never overwrites this block. -->

