---
type: opportunity
uid: "nih:PAR-26-118"
title: "Genomic Data Science and Computational Genomics (R01)"
agency: "NIH NHGRI"
ident: "PAR-26-118"
url: "https://grants.nih.gov/grants/guide/pa-files/PAR-26-118.html"
posted: 2025-10-22
closes: 2026-06-05
pipeline_score: 88
matched_domains: [Genomic foundation models, 3D genome / Hi-C, AI/ML for science]
solicitation_file:
decision: undecided
because:
decided_on:
---

# PAR-26-118 — Genomic Data Science and Computational Genomics (R01)

## Pipeline rationale

> Regulatory genomics, 3D genome, sequence-to-function and benchmarking; strong NHGRI alignment.

*This is the keyword/LLM scorer talking, from the title and abstract only.*
*It has not read the solicitation and knows nothing about my constraints.*

## What the solicitation actually says

<!-- filled in after reading the document in inbox/ -->

## Decision

<!-- mine. the exporter never overwrites this block. -->

