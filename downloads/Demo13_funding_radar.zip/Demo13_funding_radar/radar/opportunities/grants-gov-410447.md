---
type: opportunity
uid: "grants.gov:410447"
title: "AFRI Foundational — Computational Approaches to Crop Resilience"
agency: "USDA-NIFA"
ident: "USDA-NIFA-AFRI-0010447"
url: "https://grants.gov/search-results-detail/410447"
posted: 2026-01-12
closes: 2026-04-09
pipeline_score: 91
matched_domains: [Genomic foundation models, Plant phenomics, Plant / crop / bioenergy science]
solicitation_file:
decision: undecided
because:
decided_on:
---

# USDA-NIFA-AFRI-0010447 — AFRI Foundational — Computational Approaches to Crop Resilience

## Pipeline rationale

> Direct hit on sorghum, gene expression prediction and high-throughput phenotyping; three profile domains matched.

*This is the keyword/LLM scorer talking, from the title and abstract only.*
*It has not read the solicitation and knows nothing about my constraints.*

## What the solicitation actually says

<!-- filled in after reading the document in inbox/ -->

## Decision

<!-- mine. the exporter never overwrites this block. -->

