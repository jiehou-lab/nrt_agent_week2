---
type: opportunity
uid: "grants.gov:398812"
title: "AFRI Foundational — Computational Approaches to Crop Resilience (FY2025)"
agency: "USDA-NIFA"
ident: "USDA-NIFA-AFRI-0009812"
url: "https://grants.gov/search-results-detail/398812"
posted: 2025-01-15
closes: 2025-04-10
pipeline_score: 90
matched_domains: [Genomic foundation models, Plant phenomics, Plant / crop / bioenergy science]
solicitation_file:
decision: pass
because: "$200k total cap. At 54.5% indirect that is ~$129k direct over 2 years. Cannot staff a student. Scientifically the best fit of the FY25 cycle - the number killed it."
decided_on: 2025-02-20
---

# USDA-NIFA-AFRI-0009812 — AFRI Foundational — Computational Approaches to Crop Resilience (FY2025)

## Pipeline rationale

> Sorghum, gene expression prediction, phenotyping.

*This is the keyword/LLM scorer talking, from the title and abstract only.*
*It has not read the solicitation and knows nothing about my constraints.*

## What the solicitation actually says

<!-- filled in after reading the document in inbox/ -->

## Decision

**Passed, 20 Feb 2025.**

Read the whole thing. Priorities are exactly my aim 2 — sorghum, sequence to
expression, PlantCV phenotyping. I wanted this one.

$200,000 **total including indirect**. At our 54.5% rate that is about $129k of
direct cost for a two-year project. One PhD student for two years is ~$180k
direct. There is no version of the proposed work that fits inside it, and
padding the scope down to fit produces a project I would not want to run.

If this is reissued at the same cap, the answer is the same. **Do not spend
another afternoon reading it.**
