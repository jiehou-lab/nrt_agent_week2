---
type: profile
updated: 2026-09-28
fte_uncommitted: 0.35
indirect_rate: 0.545
---

# Research profile

> Two halves. The first says what I work on. **The second says what I can
> actually do**, and it is the half that decides whether a solicitation is a
> fit. A profile with only interests produces memos that are wishes.

## Programs

1. **RNA structural bioinformatics** — hairpin motifs, GNRA tetraloops vs GNRNA
   pentaloops, X3DNA-DSSR, RMSD structural clustering.
2. **Genomic foundation models** — predicting sorghum gene expression from DNA;
   long-context models, ATAC/ChIP/splicing tracks, cross-species transfer.
3. **Plant phenomics** — PlantCV, VIS/NIR, NDVI, multispectral, LemnaTec.
4. **Agricultural robotics and continual learning** — leaf-angle from
   RGB/depth/LiDAR, catastrophic forgetting, ICRA/IROS.
5. **3D genome / Hi-C** analysis platforms.
6. **AI/ML for scientific discovery**, agentic LLM systems, AI-ready datasets.

Organisms: sorghum, bioenergy crops, plants.

## Constraints — read these before scoring anything

| | |
|---|---|
| **Uncommitted effort** | 0.35 FTE. Anything needing more than that needs a co-PI who is not me. |
| **Indirect rate** | 54.5% on MTDC. A $200k *total* cap is roughly $129k of direct cost. |
| **Smallest viable project** | One PhD student for two years ≈ $180k direct. Below that I am writing a proposal I cannot staff. |
| **Cost share** | The college does not commit cost share for federal awards. A cost-share requirement is a decline, not a negotiation. |
| **Limited submissions** | Institutional down-select runs 8–10 weeks before an NSF LOI deadline. If the down-select has closed, the call is gone regardless of fit. |
| **Can be PI** | Yes. Not currently eligible for early-career programs (PhD 2013). |
| **Equipment** | No wet lab. Computation, field imaging, and existing collaborator platforms only. |
| **Collaborators in place** | Sorghum field trials (Agronomy); HPC allocation; no materials-science or clinical partner. |

## What I decline, by default

- Anything requiring cost share.
- Anything capped below ~$180k direct.
- Anything whose application domain is outside the life and plant sciences,
  however well the AI keywords match.
- Anything whose LOI or institutional down-select has already closed.

## Standing questions

What I am trying to fund, in order:

1. **Cross-species transfer for expression prediction** — a model trained on
   reference species, evaluated honestly on a feedstock genome it has not seen.
   This is the one I most want funded.
2. Held-out benchmarks for plant genomic ML, with buffer-equivalent covariates
   recorded rather than folded into the label.
3. Season-scale phenotyping with calibration drift handled explicitly.
