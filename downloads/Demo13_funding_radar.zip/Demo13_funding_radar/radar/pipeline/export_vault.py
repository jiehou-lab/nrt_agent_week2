#!/usr/bin/env python3
"""Export pipeline rows to opportunity notes. One way. Never overwrites a decision.

The database is the system of record for WHAT EXISTS.
The notes are the record of WHAT YOU DECIDED.
This script only ever moves information in the first direction.
"""
import argparse, os, re, sqlite3, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

PRESERVE = ("decision", "because", "decided_on")   # yours. never touched.

def slug(uid):
    return re.sub(r"[^a-z0-9]+", "-", uid.lower()).strip("-")

DECISION_H = "## Decision"

def read_existing(path):
    """Return (preserved frontmatter fields, everything from '## Decision' onward).

    The body below the Decision heading is yours and is copied through
    verbatim. Losing it on a re-export would make the whole exercise
    pointless, so this is the part to be careful about.
    """
    if not os.path.exists(path):
        return {}, None
    text = open(path, encoding="utf-8").read()

    fields, inside = {}, False
    for line in text.splitlines():
        if line.strip() == "---":
            if inside:
                break
            inside = True
            continue
        if inside:
            m = re.match(r"^(\w+):\s*(.*)$", line)
            if m and m.group(1) in PRESERVE:
                fields[m.group(1)] = m.group(2).strip()

    i = text.find(DECISION_H)
    body = text[i + len(DECISION_H):].lstrip("\n") if i != -1 else None
    return fields, body

def note(r, kept, body):
    d = dict(r)
    f = [
        "---",
        "type: opportunity",
        f'uid: "{d["uid"]}"',
        f'title: "{d["title"]}"',
        f'agency: "{d["org"]}"',
        f'ident: "{d["ident"]}"',
        f'url: "{d["url"]}"',
        f'posted: {d["posted_date"] or "unknown"}',
        f'closes: {d["close_date"] or "unknown"}',
        f'pipeline_score: {d["score"]}',
        f'matched_domains: [{", ".join(x.strip() for x in (d["matched_domains"] or "").split(";") if x.strip())}]',
        f'solicitation_file: {kept.get("solicitation_file", "")}'.rstrip(),
        f'decision: {kept.get("decision", "undecided")}',
        f'because: {kept.get("because", "")}'.rstrip(),
        f'decided_on: {kept.get("decided_on", "")}'.rstrip(),
        "---",
        "",
        f'# {d["ident"]} — {d["title"]}',
        "",
        "## Pipeline rationale",
        "",
        f'> {d["rationale"]}',
        "",
        "*This is the keyword/LLM scorer talking, from the title and abstract only.*",
        "*It has not read the solicitation and knows nothing about my constraints.*",
        "",
        "## What the solicitation actually says",
        "",
        "<!-- filled in after reading the document in inbox/ -->",
        "",
        "## Decision",
        "",
    ]
    tail = body if body is not None else (
        "<!-- Mine. Everything below this heading is copied through verbatim\n"
        "     on every re-export. Write the reason here, not just the verdict. -->\n")
    return "\n".join(f) + "\n" + tail

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=os.path.join(HERE, "radar.db"))
    ap.add_argument("--out", default=os.path.join(ROOT, "opportunities"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    con = sqlite3.connect(a.db); con.row_factory = sqlite3.Row
    new = kept_n = 0
    for r in con.execute("SELECT * FROM items ORDER BY close_date"):
        p = os.path.join(a.out, slug(r["uid"]) + ".md")
        existed = os.path.exists(p)
        kept, body = read_existing(p)
        open(p, "w", encoding="utf-8").write(note(r, kept, body))
        if existed:
            kept_n += 1
            if kept.get("decision", "undecided") != "undecided":
                print(f"  kept decision={kept['decision']:9s} {os.path.basename(p)}")
        else:
            new += 1
            print(f"  new                 {os.path.basename(p)}")
    print(f"\n{new} new, {kept_n} refreshed. Decisions preserved.")

if __name__ == "__main__":
    sys.exit(main())
