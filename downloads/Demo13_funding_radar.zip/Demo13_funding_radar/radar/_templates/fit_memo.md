---
type: fit-memo
uid: ""
ident: ""
agency: ""
written:
verdict:              # submit | worth a conversation | pass | ineligible
standing_question:    # which one from the profile, or `none`
---

# Fit memo — <ident>

**Verdict:** <one sentence>

## 1. Can I submit?

| Check | Finding | Where in the document |
|---|---|---|
| Eligibility | | |
| Submission limits | | |
| All deadlines | | |
| Budget vs. constraints | | |
| Cost share | | |
| Scope exclusions | | |

<!-- If any row is a blocker, stop here. -->

## 2. What I would propose

**Standing question:** "<quoted from the profile>"

**The solicitation says:** "<quoted from the document, with the section>"

**The proposal:** two or three sentences.

## 3. What is missing

| Gap | What it would take |
|---|---|

## 4. What finding out costs

## Where I would not be responsive

The parts of this call my work does not address, and who would.
