# Demo 13 — Funding radar: an agent layer over a system you already have

**Level:** anyone who finished Week 3. Pairs with Demos 10–12.
**Time:** 35–45 minutes.

---

## The premise

A scraper already finds solicitations. Maybe you built one; maybe it's an email
alert. Either way the pipeline part is **deterministic work that Python does
better than an agent** — faster, cheaper, reproducible, testable.

So this demo does not rebuild the scraper. It adds the two things a scraper
structurally cannot do:

1. **Read the actual solicitation** — the PDF or the saved HTML page, which the
   scraper only ever saw as a title and an abstract.
2. **Remember what you decided last time**, and why.

## The one-line diagnosis

Here is the schema of a real funding-radar project:

```sql
CREATE TABLE items    (uid, feed, source, title, url, org, score, rationale, ...);
CREATE TABLE feedback (uid TEXT, vote INTEGER, ts TEXT);
```

`items`: 90 rows. **`feedback`: 0 rows.**

The slot for the decision exists and is empty, because *"passed — the $200k cap
is below what the work costs"* does not fit in an `INTEGER`. So the reason goes
nowhere, and next year the same call comes round and you read it from scratch.

That is what this demo is about.

## What is in it

`radar/inbox/` — **six solicitations you dropped in yourself.** Four PDFs, two
saved HTML pages. This is the half the scraper never sees.

`radar/pipeline/` — a small SQLite database and a one-way exporter, standing in
for whatever system you already run. **Read-only.** The agent never writes to it.

`radar/profile/research_profile.md` — your profile, in two halves:

- what you work on
- **what you can actually do**: uncommitted FTE, indirect rate, smallest viable
  project, cost-share appetite, whether the institutional down-select has closed

The second half is the one that decides. A profile with only interests produces
memos that are wishes.

`radar/opportunities/` — one note per call, generated from the database and then
annotated by you. One of them already carries a `decision: pass` from February
2025, with the reason.

## The shape

```
pipeline/radar.db          system of record for WHAT EXISTS.     read-only
      ↓  export_vault.py — one way, idempotent, never eats a decision
opportunities/*.md         one note per call
      ↓
inbox/*.pdf                the document itself. triage reads THIS.
      ↓
YOU: decision + because    ← the record that doesn't exist today
      ↓
memos/*.md                 the deliverable
```

## Run it

```bash
cd radar
git init && git add -A && git commit -m "before the agent"
claude
```

Then the six prompts in `SETUP.md`.

## Files

| File | What it is |
|---|---|
| `SETUP.md` | Six prompts, and what to watch for |
| `ANSWER_KEY.md` | **After you run it.** Every trap in the six documents. |

## One number to hold on to

The pipeline's **highest**-scoring call in this set is one you cannot submit to.
Its **lowest**-scoring call is the best fit in the set.

Both of those are the scorer working correctly. It matched keywords in a title,
which is all it had.
