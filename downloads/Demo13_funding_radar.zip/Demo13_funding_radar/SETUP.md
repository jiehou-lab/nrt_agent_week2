# Setup and run

> **New here?** Read the [handbook](https://jiehou-lab.github.io/nrt_agent_week2/guides/research-system.html)
> first — prerequisites and the file map for all four demos.
>
> **Already run it?** `MAINTENANCE.md` has the weekly loop, how to write a
> decision that is still useful next year, and how to point this at your own
> pipeline.

---

## What is in this package

```
Demo13_funding_radar/
├── README.md
├── SETUP.md                  ← you are here
├── MAINTENANCE.md            the weekly loop and keeping the profile true
├── ANSWER_KEY.md             SPOILER — read last
└── radar/                    ← run `claude` from HERE
    ├── CLAUDE.md             ★ the ORDER OF WORK: eligibility before science
    ├── .claude/
    │   ├── settings.json     ★ denies pipeline/, profile/, inbox/, .env*
    │   └── agents/
    │       ├── recurrence.md     have I decided this before?   NO Write
    │       ├── triage.md         is this worth an afternoon?
    │       └── fitmemo.md        writes the memo. refuses if ineligible.
    ├── profile/
    │   └── research_profile.md   ★★ interests AND CONSTRAINTS. the key file.
    ├── inbox/                6 solicitations  ← drop new ones here
    │   ├── NSF-26-512_AI_Institutes…pdf
    │   ├── NSF-26-512_program_page.html       ← same call, different deadline
    │   ├── NSF-26-534_Foundation_Models…pdf
    │   ├── USDA-NIFA-AFRI-0010447…pdf
    │   ├── NIH_PAR-26-118…html
    │   └── DE-FOA-0003291…pdf
    ├── pipeline/             NEVER
    │   ├── radar.db              what EXISTS. the scraper owns it.
    │   └── export_vault.py       db → notes. one way. preserves decisions.
    ├── opportunities/        generated, PLUS your decision blocks
    ├── memos/                the deliverable
    └── _templates/fit_memo.md
```

**The file that decides everything** is `profile/research_profile.md`. It has
two halves — what you work on, and **what you can actually do**: uncommitted
FTE, indirect rate, smallest viable project, cost-share appetite, down-select
timing. Four of the five traps here are caught by that second half alone.

## 0. What you need

- **Claude Code**, working.
- **`pdftotext`** — essential here. The solicitations are 2–3 pages each and the
  traps are in the middle of them.
  - macOS `brew install poppler` · Ubuntu `sudo apt install poppler-utils`
- Python 3 for the exporter. No packages beyond the standard library.

## 1. Look at the two halves

```bash
cd radar
ls inbox/                      # six solicitations you dropped in
ls opportunities/              # six notes, generated from the pipeline
cat profile/research_profile.md
```

Read the **constraints table** in the profile properly. Uncommitted FTE 0.35,
indirect 54.5%, smallest viable project ~$180k direct, no cost share, no wet
lab. Those numbers decide most of what follows.

```bash
git init && git add -A && git commit -m "before the agent"
```

## 2. See what the pipeline thinks

```bash
grep -H "pipeline_score" opportunities/*.md | sort -t: -k3 -rn
```

| Score | Call |
|---|---|
| 96 | NSF 26-512 — AI Institutes: AI for Biological Discovery |
| 91 | USDA-NIFA-AFRI-0010447 — Crop Resilience |
| 88 | NIH PAR-26-118 — Genomic Data Science |
| 85 | NSF 26-534 — Foundation Models for Materials |
| 90 | *(USDA FY2025 — already decided)* |
| **38** | DOE DE-FOA-0003291 — Predictive Biology for Bioenergy |

Hold onto that ordering. By the end of the demo it will be close to reversed,
and **the scorer will not have been wrong** — it matched keywords in a title,
which is all it ever had.

## 3. The exporter, and why it matters

```bash
head -12 pipeline/export_vault.py
python3 pipeline/export_vault.py
```

**Expected:**

```
  kept decision=pass      grants-gov-398812.md

0 new, 6 refreshed. Decisions preserved.
```

`kept decision=pass` is the line that matters. Run it a third time and confirm the prose under `## Decision` in that note is still there:

```bash
grep -c "Do not spend" opportunities/grants-gov-398812.md
```

**Expected: `1`.** Test this before you ever point the exporter at your own data — a generator that silently eats your writing is invisible until the day you need what it ate.

It refreshes every note from the database **and preserves your
`## Decision` block verbatim**. Run it twice; nothing you wrote is lost.

That property is the whole design. The database owns *what exists*; the notes
own *what you decided*; information only ever flows one way. `settings.json`
denies writes to `pipeline/` so the agent cannot reverse it.

---

# The six prompts

### Prompt 1 — have I seen any of these before?

```
Use the recurrence subagent. Which calls in this cycle are reissues of ones
I have already decided on?
```

Before anything else. One of the six is a reissue, the document says so in
writing, and there is a `decision: pass` from February 2025 with the reason.

**If the reason still holds, that call is finished** — no reading, no memo,
no afternoon.

### Prompt 2 — the top of the list

```
Use the triage subagent on inbox/NSF-26-512_AI_Institutes_Biological_Discovery.pdf.
```

The pipeline's highest score, 96, and the science is a genuine match across
five domains.

> Verdict: ____________________

Read `CLAUDE.md`'s order of work and check the agent followed it — eligibility
before science. There are **three** separate dates in that document and the one
on the cover is not the binding one.

### Prompt 3 — two documents, one call

```
inbox/ also has NSF-26-512_program_page.html. Compare it against the
solicitation PDF. Which is right?
```

They disagree about the deadline. One of them says, in its own footer, that it
is not authoritative.

### Prompt 4 — the keyword trap

```
Use the triage subagent on inbox/NSF-26-534_Foundation_Models_Materials.pdf.
```

Scored 85. Contains *foundation models*, *machine learning*, *agentic AI*,
*continual learning*, *AI-ready datasets*, *deep learning* — six of your
profile's keyword domains, all genuinely present.

Two independent reasons this is a dead end, and **one of them is in the
profile's decline list**, so it needs no reading at all.

### Prompt 5 — the one at the bottom

```
Use the triage subagent on inbox/DE-FOA-0003291_Predictive_Biology_Bioenergy.pdf.
```

Scored **38**, the lowest in the set. Read AOI 1 against standing question 1 in
your profile.

This is the prompt that justifies the whole demo. A keyword filter cannot find
work described in vocabulary your profile does not use, and no amount of
tuning the scorer fixes that — it is not a threshold problem.

### Prompt 6 — the deliverable

```
Use the fitmemo subagent on the call that survived triage.
```

Written to `memos/`. Check three things by hand:

- Does section 1 cite a **page or section** for every eligibility claim?
- Does section 2 **quote** a standing question from the profile, rather than
  paraphrasing one into agreement?
- Is section 3 — *what is missing* — specific? A memo with an empty gap section
  is a memo that has not been thought about.

Then:

```bash
git status --short pipeline/ profile/
```

Empty. Both were denied.

---

## Afterwards

1. `cat ANSWER_KEY.md`.
2. **Write the decisions down.** Open each note, set `decision:` and write the
   reason under `## Decision`. Re-run the exporter and watch them survive.
   That log is the only artefact here that gets more valuable every year.
3. For each trap the agent missed: which layer should have caught it — a line
   in `CLAUDE.md`, a rule in `settings.json`, or a constraint missing from the
   profile? Most misses in this demo are the third.

## Using this on your own radar

Point `export_vault.py` at your own database — it needs `uid`, `title`, `org`,
`ident`, `url`, `score`, `rationale`, `posted_date`, `close_date`. Rewrite
`profile/research_profile.md` with **your** numbers; the constraints half is
not optional, and it is the part nobody writes down.

Then drop solicitations into `inbox/` as they arrive. The agent's job starts
where the scraper's ends.

---

## Next

**`MAINTENANCE.md`** — the operating manual: the daily and weekly loops, how to add each kind of new material, what decays over time and how to notice, and a troubleshooting table.

**The [handbook](https://jiehou-lab.github.io/nrt_agent_week2/guides/research-system.html)** — all four demos as one system, with the full file map and the prerequisites.

**`ANSWER_KEY.md`** — now, but not before.
