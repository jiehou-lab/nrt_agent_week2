# Setup and run

## 0. What you need

- **Claude Code**, working.
- **`pdftotext`** — essential here. The solicitations are 2–3 pages each and the
  traps are in the middle of them.
  - macOS `brew install poppler` · Ubuntu `sudo apt install poppler-utils`
- Python 3 for the exporter. No packages beyond the standard library.

## 1. Look at the two halves

```bash
cd radar
ls inbox/                      # six solicitations you dropped in
ls opportunities/              # six notes, generated from the pipeline
cat profile/research_profile.md
```

Read the **constraints table** in the profile properly. Uncommitted FTE 0.35,
indirect 54.5%, smallest viable project ~$180k direct, no cost share, no wet
lab. Those numbers decide most of what follows.

```bash
git init && git add -A && git commit -m "before the agent"
```

## 2. See what the pipeline thinks

```bash
grep -H "pipeline_score" opportunities/*.md | sort -t: -k3 -rn
```

| Score | Call |
|---|---|
| 96 | NSF 26-512 — AI Institutes: AI for Biological Discovery |
| 91 | USDA-NIFA-AFRI-0010447 — Crop Resilience |
| 88 | NIH PAR-26-118 — Genomic Data Science |
| 85 | NSF 26-534 — Foundation Models for Materials |
| 90 | *(USDA FY2025 — already decided)* |
| **38** | DOE DE-FOA-0003291 — Predictive Biology for Bioenergy |

Hold onto that ordering. By the end of the demo it will be close to reversed,
and **the scorer will not have been wrong** — it matched keywords in a title,
which is all it ever had.

## 3. The exporter, and why it matters

```bash
cat pipeline/export_vault.py | head -12
python3 pipeline/export_vault.py
```

It refreshes every note from the database **and preserves your
`## Decision` block verbatim**. Run it twice; nothing you wrote is lost.

That property is the whole design. The database owns *what exists*; the notes
own *what you decided*; information only ever flows one way. `settings.json`
denies writes to `pipeline/` so the agent cannot reverse it.

---

# The six prompts

### Prompt 1 — have I seen any of these before?

```
Use the recurrence subagent. Which calls in this cycle are reissues of ones
I have already decided on?
```

Before anything else. One of the six is a reissue, the document says so in
writing, and there is a `decision: pass` from February 2025 with the reason.

**If the reason still holds, that call is finished** — no reading, no memo,
no afternoon.

### Prompt 2 — the top of the list

```
Use the triage subagent on inbox/NSF-26-512_AI_Institutes_Biological_Discovery.pdf.
```

The pipeline's highest score, 96, and the science is a genuine match across
five domains.

> Verdict: ____________________

Read `CLAUDE.md`'s order of work and check the agent followed it — eligibility
before science. There are **three** separate dates in that document and the one
on the cover is not the binding one.

### Prompt 3 — two documents, one call

```
inbox/ also has NSF-26-512_program_page.html. Compare it against the
solicitation PDF. Which is right?
```

They disagree about the deadline. One of them says, in its own footer, that it
is not authoritative.

### Prompt 4 — the keyword trap

```
Use the triage subagent on inbox/NSF-26-534_Foundation_Models_Materials.pdf.
```

Scored 85. Contains *foundation models*, *machine learning*, *agentic AI*,
*continual learning*, *AI-ready datasets*, *deep learning* — six of your
profile's keyword domains, all genuinely present.

Two independent reasons this is a dead end, and **one of them is in the
profile's decline list**, so it needs no reading at all.

### Prompt 5 — the one at the bottom

```
Use the triage subagent on inbox/DE-FOA-0003291_Predictive_Biology_Bioenergy.pdf.
```

Scored **38**, the lowest in the set. Read AOI 1 against standing question 1 in
your profile.

This is the prompt that justifies the whole demo. A keyword filter cannot find
work described in vocabulary your profile does not use, and no amount of
tuning the scorer fixes that — it is not a threshold problem.

### Prompt 6 — the deliverable

```
Use the fitmemo subagent on the call that survived triage.
```

Written to `memos/`. Check three things by hand:

- Does section 1 cite a **page or section** for every eligibility claim?
- Does section 2 **quote** a standing question from the profile, rather than
  paraphrasing one into agreement?
- Is section 3 — *what is missing* — specific? A memo with an empty gap section
  is a memo that has not been thought about.

Then:

```bash
git status --short pipeline/ profile/
```

Empty. Both were denied.

---

## Afterwards

1. `cat ANSWER_KEY.md`.
2. **Write the decisions down.** Open each note, set `decision:` and write the
   reason under `## Decision`. Re-run the exporter and watch them survive.
   That log is the only artefact here that gets more valuable every year.
3. For each trap the agent missed: which layer should have caught it — a line
   in `CLAUDE.md`, a rule in `settings.json`, or a constraint missing from the
   profile? Most misses in this demo are the third.

## Using this on your own radar

Point `export_vault.py` at your own database — it needs `uid`, `title`, `org`,
`ident`, `url`, `score`, `rationale`, `posted_date`, `close_date`. Rewrite
`profile/research_profile.md` with **your** numbers; the constraints half is
not optional, and it is the part nobody writes down.

Then drop solicitations into `inbox/` as they arrive. The agent's job starts
where the scraper's ends.
