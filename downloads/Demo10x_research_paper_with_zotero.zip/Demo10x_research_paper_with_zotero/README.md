# research-paper-with-zotero (Demo 10)

A paper-reading and paper-writing workspace for Claude Code, wired to a real
Zotero library — from an empty folder to a Word document with live citations
you can keep editing.

**Start with `SETUP.md`.** It goes step by step and assumes nothing.

## What this is

    papers/      PDFs in, notes out, one index, one library export
    writing/     markdown drafts, then Word
    writing/tex/ or LaTeX / Overleaf, if that is your world
    tools/       scripts that check things, so a README does not have to ask
    .claude/     the agents, the skills, and the permission boundary
    CLAUDE.md    the contract. Read it.

Four subagents, five skills, six scripts. Nothing else.

## What it is not

No projects, no proposals, no topic syntheses, no benchmarks. This workspace
does one thing: read papers, write about them, cite them correctly. A bigger
research system is a different package.

## The three ideas worth taking away

**1. Three layers, and they are not interchangeable.** `CLAUDE.md` is a
request, `.claude/settings.json` is a refusal, a subagent's missing tool is
an absence. Put each rule in the lowest layer that can hold it.

**2. A verifier that can edit is a verifier you cannot trust.** `citecheck`
and `prose` have no `Write` tool. They report; you decide. An agent that can
fix what it finds can also make its findings disappear.

**3. `[GAP:]` is a result.** When the library cannot support a claim, the
correct output says so. Deleting the gaps to make a draft read finished is
how a confident, wrong paragraph gets written.

## Requirements

    python3, python-docx          required
    Zotero 7 + Better BibTeX      for citations
    pandoc built WITH http        for live Word citations — see SETUP.md
    latexmk + a TeX engine        only if you write LaTeX — writing/tex/README.md
    pdftotext                     optional, helps citecheck read PDFs

Run `tools/doctor.sh` and it will tell you what is missing and the exact
command to fix it.

## Licence

The scaffold is yours to reuse and adapt. The three demo papers are not
included — `papers/inbox/PAPERS.md` lists their DOIs; all three are CC BY 4.0
and you add them through Zotero.
