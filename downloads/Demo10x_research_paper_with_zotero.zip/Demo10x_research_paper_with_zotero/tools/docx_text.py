#!/usr/bin/env python3
"""Read a Word document that Zotero owns. READ ONLY — opens nothing for writing.

    python3 tools/docx_text.py <file.docx>                      numbered blocks
    python3 tools/docx_text.py <file.docx> --media out/         write the figures out
    python3 tools/docx_text.py <file.docx> --json               machine-readable
    python3 tools/docx_text.py <new.docx> --against <old.docx>  did anything break?

Once a .docx carries live Zotero field codes it is the source of truth, and
pandoc cannot round-trip it. Measured on this project's own draft:

    pandoc rich.docx -o x.md && pandoc x.md -o y.docx
      zotero fields  3 -> 0      images  2 -> 0      tables  1 -> 1

Both the citations and every figure are gone; only the tables survive. So
agents read the document through this, and never regenerate it.

WHAT YOU GET
  - body order preserved: paragraphs and tables interleaved as they appear
  - tables as pipe tables, so an agent sees rows and columns, not 16 stray
    one-word paragraphs
  - citations folded to «citation:N», the reference list to «bibliography:N»:
    visible as live, impossible to mistake for text to rewrite
  - figures as «figure:N …» naming the file inside the archive, plus its alt
    text. With --media the images are written out so they can be LOOKED AT.
"""
import sys, json, re, zipfile, os
import xml.etree.ElementTree as ET

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
WP = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
PIC = '{http://schemas.openxmlformats.org/package/2006/relationships}'


def parts(path):
    with zipfile.ZipFile(path) as z:
        doc = ET.fromstring(z.read('word/document.xml'))
        try:
            rels = ET.fromstring(z.read('word/_rels/document.xml.rels'))
            rmap = {r.get('Id'): r.get('Target') for r in rels}
        except KeyError:
            rmap = {}
    return doc, rmap


class Reader:
    def __init__(self, root, rmap):
        self.rmap = rmap
        self.parents = {c: p for p in root.iter() for c in p}
        self.n = 0
        self.depth = 0
        self.instr = ''
        self.pending = False
        self.figures = []

    def para(self, p):
        """One paragraph's visible text, with fields and images folded in."""
        parts_ = []
        for r in p.iter(W + 'r'):
            par = self.parents.get(r)
            if par is not None and par.tag == W + 'del':
                continue          # proposed for removal; not content
            for child in r:
                tag = child.tag[len(W):] if child.tag.startswith(W) else child.tag
                if tag == 'fldChar':
                    t = child.get(W + 'fldCharType')
                    if t == 'begin':
                        self.depth += 1; self.instr = ''; self.pending = True
                    elif t == 'end' and self.depth:
                        self.depth -= 1
                        if not self.depth and self.pending:
                            self.n += 1
                            kind = ('bibliography' if 'ZOTERO_BIBL' in self.instr
                                    else 'citation' if 'ZOTERO_ITEM' in self.instr
                                    else 'field')
                            parts_.append(f'«{kind}:{self.n}»'); self.pending = False
                elif tag == 'instrText':
                    self.instr += (child.text or '')
                elif tag in ('t', 'delText') and self.depth == 0:
                    parts_.append(child.text or '')
                elif child.tag.endswith('}drawing'):
                    parts_.append(self.image(child))
        return ''.join(parts_).strip()

    def image(self, drawing):
        alt = ''
        for d in drawing.iter(WP + 'docPr'):
            alt = d.get('descr') or d.get('name') or ''
        target = ''
        for b in drawing.iter(A + 'blip'):
            rid = b.get(R + 'embed') or b.get(R + 'link')
            if rid:
                target = self.rmap.get(rid, rid)
        self.figures.append({'index': len(self.figures) + 1,
                             'part': 'word/' + target.lstrip('/'), 'alt': alt})
        f = self.figures[-1]
        return f'\n«figure:{f["index"]} {f["part"]}{" — " + alt if alt else ""}»\n'

    def table(self, tbl):
        rows = []
        for tr in tbl.findall(W + 'tr'):
            cells = []
            for tc in tr.findall(W + 'tc'):
                cells.append(' '.join(self.para(p) for p in tc.findall(W + 'p')).strip())
            rows.append(cells)
        if not rows:
            return ''
        wide = max(len(r) for r in rows)
        rows = [r + [''] * (wide - len(r)) for r in rows]
        out = ['| ' + ' | '.join(rows[0]) + ' |',
               '|' + '|'.join('---' for _ in rows[0]) + '|']
        out += ['| ' + ' | '.join(r) + ' |' for r in rows[1:]]
        return '\n'.join(out)

    def blocks(self, root):
        """Body children IN ORDER. A table is one block, not 16 paragraphs."""
        out = []
        body = root.find(W + 'body')
        for child in (body if body is not None else root):
            if child.tag == W + 'p':
                t = self.para(child)
                if t: out.append(('p', t))
            elif child.tag == W + 'tbl':
                t = self.table(child)
                if t: out.append(('table', t))
        if self.depth:
            out.append(('p', '«WARNING: a field was never closed — document may be damaged»'))
        return out


def integrity(path):
    with zipfile.ZipFile(path) as z:
        x = z.read('word/document.xml').decode('utf8', 'replace')
        media = [n for n in z.namelist() if n.startswith('word/media/')]
    return {
        'live citations':   x.count('ADDIN ZOTERO_ITEM'),
        'bibliography':     x.count('ADDIN ZOTERO_BIBL'),
        'field begin':      x.count('w:fldCharType="begin"'),
        'field separate':   x.count('w:fldCharType="separate"'),
        'field end':        x.count('w:fldCharType="end"'),
        'instrText in del': len(re.findall(r'<w:del[ >](?:(?!</w:del>).)*?<w:instrText', x, re.S)),
        'embedded images':  len(media),
        'tables':           x.count('<w:tbl>'),
    }


def compare(new, old):
    a, b = integrity(old), integrity(new)
    print(f'  {"":18} {"sent":>6} {"back":>6}')
    bad = False
    for k in a:
        changed = a[k] != b[k]
        bad = bad or changed
        print(f'  {k:18} {a[k]:>6} {b[k]:>6}' + ('   <-- CHANGED' if changed else ''))
    if b['instrText in del']:
        bad = True; print('\n  A citation field is inside a deletion. That field is damaged.')
    if not (b['field begin'] == b['field end'] == b['field separate']):
        bad = True; print('\n  Field markers are unbalanced — the document is structurally broken.')
    print()
    if bad:
        print('  FAIL  do not build on this file. Go back to the version you sent,')
        print('        and make the change another way.')
        sys.exit(1)
    print('  ok    citations, figures and tables all still intact. Safe to continue.')


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args: sys.exit(__doc__)
    path = args[0]
    if '--against' in sys.argv:
        return compare(path, sys.argv[sys.argv.index('--against') + 1])

    root, rmap = parts(path)
    rd = Reader(root, rmap)
    blocks = rd.blocks(root)
    body = '\n'.join(t for _, t in blocks)
    a = integrity(path)
    a['figures referenced'] = len(rd.figures)
    a['gap markers'] = re.findall(r'\[GAP:[^\]]*\]', body)
    a['web markers'] = sorted(set(re.findall(r'\[WEB:\d+\]', body)))
    a['stray citekeys'] = re.findall(r'\[@[\w-]+\]', body)

    if '--media' in sys.argv:
        out = sys.argv[sys.argv.index('--media') + 1]
        os.makedirs(out, exist_ok=True)
        with zipfile.ZipFile(path) as z:
            for f in rd.figures:
                if f['part'] in z.namelist():
                    dest = os.path.join(out, f'figure{f["index"]}-' + os.path.basename(f['part']))
                    open(dest, 'wb').write(z.read(f['part']))
                    print(f'  figure {f["index"]} -> {dest}')
        print('\n  Open these to review the figures. Reading the caption is not\n'
              '  reviewing the figure; the axes are where claims go wrong.\n')
        return

    if '--json' in sys.argv:
        print(json.dumps({'blocks': [{'kind': k, 'text': t} for k, t in blocks],
                          'figures': rd.figures, 'audit': a}, indent=2)); return

    for i, (kind, t) in enumerate(blocks, 1):
        print(f'[{i}]{" TABLE" if kind == "table" else ""}\n{t}\n')
    print('--- audit ' + '-' * 50)
    for k, v in a.items():
        if isinstance(v, list):
            print(f'{k:20} {len(v)}' + (': ' + '; '.join(str(x)[:66] for x in v) if v else ''))
        else:
            print(f'{k:20} {v}')
    if rd.figures:
        print(f'\nTo look at the figures:  python3 tools/docx_text.py {path} --media /tmp/figs')
    if a['stray citekeys']:
        print('\nWARNING: [@citekey] markers left as plain text. They were never\n'
              'converted to fields — re-render, or insert them in Word by hand.')


main()
