#!/usr/bin/env bash
# What is installed, what is missing, and the exact command to fix each gap.
#
#   tools/doctor.sh
#
# Nothing here is required to READ papers or write markdown. The checks are
# ordered by how much you lose without them, and each one says so.
set -uo pipefail
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$HERE"

ok()   { printf '  \033[32mok\033[0m    %s\n' "$*"; }
warn() { printf '  \033[33mwarn\033[0m  %s\n' "$*"; }
miss() { printf '  \033[31mMISS\033[0m  %s\n' "$*"; }
fix()  { printf '        %s\n' "$*"; }
head_() { printf '\n\033[1m%s\033[0m\n' "$*"; }

head_ "Core — without these the workspace does not work"

command -v python3 >/dev/null && ok "python3 $(python3 -V 2>&1 | awk '{print $2}')" \
  || { miss "python3"; fix "xcode-select --install"; }

python3 -c 'import docx' 2>/dev/null \
  && ok "python-docx — tools/docx_text.py and docx_suggest.py can run" \
  || { miss "python-docx — cannot read or suggest on Word files"
       fix "pip3 install python-docx"; }

head_ "Writing to Word"

# Which pandoc would render.sh live actually choose? Same search order.
cands=()
[ -f tools/pandoc.path ] && cands+=("$(sed -n 1p tools/pandoc.path)")
cands+=(tools/pandoc/bin/pandoc "$HOME/bin/pandoc-http/bin/pandoc" \
        /opt/homebrew/bin/pandoc /usr/local/bin/pandoc "$(command -v pandoc 2>/dev/null)")
probe=$(mktemp -t doc.XXXXXX).lua
{ printf 'function Pandoc(d)\n'
  printf '  local o,e = pcall(pandoc.mediabag.fetch,"http://127.0.0.1:1/x")\n'
  printf '  if not o then io.stderr:write(tostring(e)) end\n  return d\nend\n'; } > "$probe"

chosen=""; seen=""; any=""
for c in "${cands[@]}"; do
  [ -n "$c" ] && [ -x "$c" ] || continue
  case " $seen " in *" $c "*) continue ;; esac; seen="$seen $c"
  v=$("$c" --version 2>/dev/null | head -1 | awk '{print $2}') || continue
  [ -n "$v" ] || continue
  any=yes
  out=$(printf 'x\n' | "$c" --lua-filter="$probe" -t plain 2>&1)
  case "$out" in *"without HTTP support"*) h=no ;; *) h=yes ;; esac
  maj=${v%%.*}; min=$(printf '%s' "$v" | cut -d. -f2)
  good=no
  { [ "$maj" -gt 2 ] || { [ "$maj" -eq 2 ] && [ "$min" -ge 16 ]; }; } && [ "$h" = yes ] && good=yes
  printf '        %-38s %-8s http=%s\n' "$c" "$v" "$h"
  [ "$good" = yes ] && [ -z "$chosen" ] && chosen="$c ($v)"
done
rm -f "$probe"
[ -n "$any" ] || { miss "no pandoc at all"; fix "brew install pandoc  (then see below — you will also need one with http)"; }
if [ -n "$chosen" ]; then
  ok "live mode will use $chosen"
else
  miss "no pandoc with HTTP support — 'render.sh live' cannot reach Zotero"
  fix "curl -s https://api.github.com/repos/jgm/pandoc/releases/tags/3.8 \\"
  fix "  | grep -o '\"browser_download_url\": *\"[^\"]*\"' | grep -i macOS.zip"
  fix "unzip pandoc-3.8-<arch>-macOS.zip -d /tmp/p"
  fix "mkdir -p tools/pandoc && mv /tmp/p/*/[bs]* tools/pandoc/"
  fix "echo tools/pandoc/bin/pandoc > tools/pandoc.path"
fi

[ -s tools/zotero.lua ] && ok "tools/zotero.lua — the Better BibTeX filter" \
  || { miss "tools/zotero.lua — live citations impossible"
       fix "curl -o tools/zotero.lua https://retorque.re/zotero-better-bibtex/exporting/zotero.lua"; }

ls writing/styles/*.csl >/dev/null 2>&1 \
  && ok "$(ls writing/styles/*.csl | wc -l | tr -d ' ') citation style(s) in writing/styles/" \
  || warn "no .csl — the docx route falls back to Chicago, wrong for most journals
        https://www.zotero.org/styles  (the live route does not need one)"

head_ "Zotero — only needed at the moment you render live"

if curl -fsS --max-time 2 http://127.0.0.1:23119/connector/ping >/dev/null 2>&1; then
  ok "Zotero is running"
  p=$(curl -fsS --max-time 2 'http://127.0.0.1:23119/better-bibtex/cayw?probe=1' 2>/dev/null)
  case "$p" in *ready*) ok "Better BibTeX responding" ;;
    *) miss "Better BibTeX not answering (got '${p:-nothing}')"
       fix "Zotero > Tools > Plugins > gear > Install Plugin From File"
       fix "https://github.com/retorquere/zotero-better-bibtex/releases/latest" ;;
  esac
else
  warn "Zotero not running — fine right now; open it before 'render.sh live'"
fi

[ -d "$HOME/Zotero/storage" ] \
  && ok "~/Zotero/storage — $(ls "$HOME/Zotero/storage" 2>/dev/null | wc -l | tr -d ' ') attachment folders readable" \
  || warn "~/Zotero/storage not found — citecheck cannot open PDFs"

[ -f papers/library/library.csv ] && ok "papers/library/library.csv present" \
  || warn "no library.csv — export it from Zotero (see the guide, section 6)"

head_ "LaTeX / Overleaf — only if you write in LaTeX"

if command -v latexmk >/dev/null; then
  ok "latexmk $(latexmk --version 2>/dev/null | grep -o '[0-9.]*' | head -1)"
  command -v pdflatex >/dev/null && ok "pdflatex" || warn "latexmk but no pdflatex — odd; reinstall your TeX distribution"
  command -v biber >/dev/null && ok "biber (biblatex)" \
    || { command -v bibtex >/dev/null && ok "bibtex (natbib). biber only needed for biblatex" \
         || warn "no bibtex or biber — bibliographies will not build"; }
else
  warn "no LaTeX. Skip this block unless you write in LaTeX
        BasicTeX  ~100 MB   brew install --cask basictex
        Tectonic  one binary, fetches packages on demand
        MacTeX    ~5 GB — you do not need it for this"
fi
ls papers/library/*.bib >/dev/null 2>&1 \
  && ok "papers/library/$(cd papers/library && ls *.bib | head -1) — tick 'Keep updated' in Zotero so it stays in sync" \
  || warn "no .bib — LaTeX citations need one. Zotero > right-click My Library >
        Export Library > Better BibTeX > TICK 'Keep updated'"

head_ "Anthropic's document skills — for .pptx, .pdf, .xlsx work"

if ls "$HOME/.claude/skills/synced"/*/docx/SKILL.md >/dev/null 2>&1 \
   || ls "$HOME/.claude/plugins"/*/*/skills/docx/SKILL.md >/dev/null 2>&1; then
  ok "document skills installed"
else
  warn "not installed. Optional — nothing in writing/ needs them"
  fix "/plugin marketplace add anthropics/skills"
  fix "/plugin install document-skills@anthropic-agent-skills"
  fix "(or sign in to your claude.ai account; account skills sync automatically)"
fi

command -v soffice >/dev/null && ok "LibreOffice — those skills can render a page to look at" \
  || warn "no soffice — the document skills cannot preview their own output
        brew install --cask libreoffice"
command -v pdftoppm >/dev/null && ok "pdftoppm" \
  || warn "no pdftoppm — same preview loop
        brew install poppler"

printf '\n  Reading papers and writing markdown need only the Core block.\n'
printf '  Everything below it is for the day you hand a draft to Word.\n\n'
