#!/usr/bin/env bash
# Render a draft. The flags live HERE, in one place, and are verified.
#
# Why a script and not an MCP server: this is one command with fixed flags,
# not a family of operations an agent has to choose among. A script costs one
# file and zero context; a server costs a process, a config, and a tool schema
# loaded into every session.
#
# Why a script and not a line in a README: a README is a request. The `-s`
# flag went missing once because two documents disagreed about it. Here there
# is one copy, and the output is checked before it is handed on.
#
#   tools/render.sh rtf   writing/drafts/foo.md  -> foo.rtf   for Zotero RTF Scan (static)
#   tools/render.sh docx  writing/drafts/foo.md  -> foo.docx  pandoc --citeproc (static)
#   tools/render.sh live  writing/drafts/foo.md  -> foo.docx  LIVE Zotero field codes
#   tools/render.sh live  writing/tex/paper.tex  -> paper.docx LIVE, from LaTeX
#
# Markdown and LaTeX both work. The zotero.lua filter acts on pandoc's Cite
# nodes and branches on the OUTPUT format, so \cite{k} and [@k] arrive as the
# same thing. Measured, not assumed — see writing/README.md.
#
# `live` needs a pandoc 2.16.2+ built WITH HTTP support, which Homebrew's and
# conda's are not. Unpack one into tools/pandoc/ and record it in
# tools/pandoc.path (both gitignored); the search below then finds it and you
# never set PANDOC= by hand. Full setup: writing/README.md.
set -euo pipefail

die() { printf '\n  FAIL  %s\n' "$*" >&2; exit 1; }
ok()  { printf '  ok    %s\n' "$*"; }

MODE=${1:-}; SRC=${2:-}
[ -n "$MODE" ] && [ -n "$SRC" ] || die "usage: tools/render.sh {rtf|docx|live} <draft.md|draft.tex>"
[ -f "$SRC" ] || die "no such file: $SRC"

# --- what kind of source is this --------------------------------------
# Markdown and LaTeX both reach the zotero filter as the same Cite nodes.
# What differs is how a citation LOOKS in the file, so the "did you write
# any citations" check has to know which one it is reading.
case "$SRC" in
  *.tex)           SRCFMT=latex ;;
  *.md|*.markdown) SRCFMT=markdown ;;
  *) die "unknown source type: $SRC - this takes .md or .tex" ;;
esac

# This check used to be a bare grep for '[@', which rejected every .tex
# file before pandoc ever ran. Both spellings count now.
have_cites() {
  case "$SRCFMT" in
    markdown)
      grep -q '\[@' "$1" && return 0
      grep -qE '(^|[^[:alnum:]_@])@[[:alpha:]][[:alnum:]_:.#$%&+?<>~/-]*' "$1"
      ;;
    latex)
      grep -qE '\\[a-zA-Z]*[Cc]ite[a-zA-Z]*\*?(\[[^]]*\])*\{' "$1"
      ;;
  esac
}
# --- picking a pandoc -------------------------------------------------
# `live` mode needs a pandoc built WITH HTTP support; the other modes do not.
# Rather than make you remember which binary that is, this probes the
# candidates and takes the first that qualifies. Order, best first:
#
#   $PANDOC            if you set it, that is the one, no searching
#   tools/pandoc.path  one line, machine-local, gitignored. Written once.
#   tools/pandoc/bin   a binary unpacked into this repo
#   ~/bin/pandoc-http  the conventional spot if you keep it outside the repo
#   Homebrew, then PATH
#
# Conda's pandoc and Homebrew's pandoc 3.12 are both built WITHOUT HTTP, and
# an active conda env puts its one first on PATH. That used to surface as a
# Lua traceback blaming the filter. Now it just gets skipped.
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)

candidates() {
  if [ -n "${PANDOC:-}" ]; then printf '%s\n' "$PANDOC"; return; fi
  if [ -f "$HERE/tools/pandoc.path" ]; then
    pp=$(sed -n '1p' "$HERE/tools/pandoc.path")
    case "$pp" in /*) printf '%s\n' "$pp" ;; ?*) printf '%s\n' "$HERE/$pp" ;; esac
  fi
  printf '%s\n' "$HERE/tools/pandoc/bin/pandoc" \
                 "$HOME/bin/pandoc-http/bin/pandoc" \
                 /opt/homebrew/bin/pandoc \
                 /usr/local/bin/pandoc
  command -v pandoc 2>/dev/null || true
}

# Does this binary have HTTP? pcall swallows the error, so the filter writes
# it to stderr explicitly. An earlier probe omitted that and passed a pandoc
# with no HTTP at all — a false OK, which is worse than no check.
has_http() {
  local probe out
  probe=$(mktemp -t probe.XXXXXX).lua
  {
    printf 'function Pandoc(d)\n'
    printf '  local ok, err = pcall(pandoc.mediabag.fetch, "http://127.0.0.1:1/x")\n'
    printf '  if not ok then io.stderr:write(tostring(err)) end\n'
    printf '  return d\nend\n'
  } > "$probe"
  out=$(printf 'x\n' | "$1" --lua-filter="$probe" -t plain 2>&1 || true)
  rm -f "$probe"
  case "$out" in *"without HTTP support"*) return 1 ;; *) return 0 ;; esac
}

CHOSEN=""; TRIED=""
while read -r c; do
  [ -n "$c" ] && [ -x "$c" ] || continue
  case " $TRIED " in *" $c "*) continue ;; esac
  TRIED="$TRIED $c"
  # executable but unrunnable is a real case: an x86_64 build on an Apple
  # Silicon Mac without Rosetta, or a half-extracted archive. Skip, do not die.
  "$c" --version >/dev/null 2>&1 || continue
  if [ "$MODE" = live ]; then
    # live needs BOTH: >= 2.16.2 for the filter, and HTTP to reach Zotero.
    # Skip rather than die, so one unsuitable pandoc on PATH does not hide
    # a suitable one further down the list.
    v=$("$c" --version | head -1 | awk '{print $2}')
    vmaj=${v%%.*}; vmin=$(printf '%s' "$v" | cut -d. -f2)
    [ "$vmaj" -gt 2 ] || { [ "$vmaj" -eq 2 ] && [ "$vmin" -ge 16 ]; } || continue
    has_http "$c" || continue
  fi
  CHOSEN=$c; break
done <<< "$(candidates)"

PANDOC=$CHOSEN

if [ -z "$PANDOC" ] && [ "$MODE" = live ]; then
  die "no pandoc here can do live mode. It needs version 2.16.2 or newer,
        built WITH HTTP support so the filter can reach Zotero. Tried:$TRIED

        WHY: pandoc 3.9 added an 'http' cabal flag so pandoc can be built
        without network support (for WASM targets). Some packagers build it
        off. Confirmed off in Homebrew's pandoc 3.12 on macOS and in conda's.

        FIX, about a minute. Any pandoc from 2.16.2 to 3.8 works — the flag
        did not exist before 3.9, so HTTP is unconditional in those:

          curl -s https://api.github.com/repos/jgm/pandoc/releases/tags/3.8 \\
            | grep -o '\"browser_download_url\": *\"[^\"]*\"' | grep -i macOS.zip

          # take arm64 on Apple Silicon, x86_64 on Intel
          unzip pandoc-3.8-<arch>-macOS.zip -d /tmp/p
          mkdir -p tools/pandoc && mv /tmp/p/*/[bs]* tools/pandoc/
          echo tools/pandoc/bin/pandoc > tools/pandoc.path

        Then re-run this command. Nothing else to set; the path file is
        machine-local and gitignored, and the search above finds it.

        Keep it elsewhere if you prefer — put that path in tools/pandoc.path,
        or pass PANDOC=/that/binary before the command (before, not after).

        Worth one try first: the official .pkg of the current version from
        https://pandoc.org/releases.html — it may be built with +http.

        No HTTP anywhere? Use the rtf route; it needs no network."
fi
[ -n "$PANDOC" ] || die "pandoc not installed. brew install pandoc"

PV=$("$PANDOC" --version | head -1 | awk '{print $2}')
PMAJ=${PV%%.*}; PMIN=$(printf '%s' "$PV" | cut -d. -f2)
# Strip whatever extension it has. "${SRC%.md}" left .tex files as foo.tex.docx
BASE="${SRC%.*}"

case "$MODE" in

rtf)
  [ "$SRCFMT" = markdown ] \
    || die "the rtf route is for {Author, Year} markdown drafts. A .tex draft
        should use the live route, which keeps real Zotero fields."
  OUT="$BASE.rtf"
  # -s is REQUIRED. Without it pandoc emits a fragment with no {\rtf1 header.
  # Zotero's RTF Scan accepts the fragment anyway, and Word then refuses the
  # result with an encoding dialog. That failure is three steps downstream of
  # the mistake, which is exactly why it is checked here.
  "$PANDOC" "$SRC" -s -o "$OUT"
  head -c 6 "$OUT" | grep -q '{\\rtf1' \
    || die "$OUT has no {\\rtf1 header — Word will not open it. pandoc -s failed?"
  ok "$OUT has a valid {\\rtf1 header"

  # Markers must survive. Two traps here, both hit while writing this:
  #   1. line wrapping splits a marker across two lines, so flatten first;
  #   2. pandoc's RTF *reader* only exists in 3.x, so do NOT verify by
  #      reading the file back — grep the raw RTF instead, where a literal
  #      brace is written \{ ... \}. That works on every pandoc version.
  FOUND=$(tr '\n' ' ' < "$OUT" | grep -o '\\{[^\\]*\\}' \
          | sed 's/\\//g' | sort -u || true)
  WANT=$(grep -o '{[^}]*}' "$SRC" | sort -u || true)
  [ -n "$WANT" ] || { ok "no {Author, Year} markers in the source"; }
  if [ -n "$WANT" ]; then
    MISSING=$(comm -23 <(printf '%s\n' "$WANT") <(printf '%s\n' "$FOUND") || true)
    [ -z "$MISSING" ] || die "markers lost in conversion:"$'\n'"$MISSING"
    ok "all $(printf '%s\n' "$WANT" | grep -c . ) marker(s) survived"
  fi
  printf '%s\n' "$FOUND" | grep -q '{Bibliography}' \
    && ok "{Bibliography} placeholder present" \
    || printf '  note  no {Bibliography} placeholder — it will go at the end\n'

  printf '\n  Next: Zotero > Tools > RTF Scan\n'
  printf '        Input  %s\n' "$OUT"
  printf '        Output %s-formatted.rtf   (a DIFFERENT name)\n' "$BASE"
  printf '        then open the output in Word and Save As .docx\n'
  printf '\n  The result is STATIC text — formatted citations and a real\n'
  printf '  bibliography, but no Zotero field codes. Refresh in Word will say\n'
  printf '  "You must insert a citation first", which is correct. To change\n'
  printf '  style, re-scan this .rtf. For a manuscript co-authors will revise,\n'
  printf '  insert citations in Word by hand instead — see writing/README.md.\n'
  ;;

docx)
  OUT="$BASE.docx"
  BIB=papers/library/library.bib
  [ -f "$BIB" ] || die "$BIB not found — export it from your reference manager"
  if [ "$PMAJ" -lt 2 ] || { [ "$PMAJ" -eq 2 ] && [ "$PMIN" -lt 11 ]; }; then
    die "pandoc $PV is too old for --citeproc (needs 2.11+). brew install pandoc"
  fi
  CSL=$(ls writing/styles/*.csl 2>/dev/null | head -1 || true)
  if [ -n "$CSL" ]; then ARGS=(--csl="$CSL"); ok "style $CSL"
  else ARGS=(); printf '  note  no .csl in writing/styles/ — using Chicago, wrong for most journals\n'; fi
  have_cites "$SRC" \
    || die "no citations found in $SRC. This route needs [@citekey] (markdown)
        or \\cite{citekey} (LaTeX); {Author, Year} markers need the rtf route."
  "$PANDOC" "$SRC" --citeproc --bibliography="$BIB" "${ARGS[@]}" -o "$OUT"
  ok "$OUT written"
  printf '\n  Static text, not Zotero field codes. Zotero cannot restyle this later.\n'
  ;;

live)
  # LIVE Zotero field codes, straight from markdown. Documented by Better
  # BibTeX: https://retorque.re/zotero-better-bibtex/exporting/pandoc/
  # Needs pandoc >= 2.16.2, the zotero.lua filter, and ZOTERO RUNNING with
  # BBT installed at the moment this runs — the filter talks to it.
  OUT="$BASE.docx"
  ok "pandoc $PV at $PANDOC, with HTTP support"
  # gitignored: it tracks Better BibTeX, not this repo. One curl on a
  # fresh clone, and the error below is the only reminder you need.
  FILTER="$HERE/tools/zotero.lua"
  [ -f "$FILTER" ] && [ -s "$FILTER" ] || die "missing or empty $FILTER — download it once:
        curl -o tools/zotero.lua https://retorque.re/zotero-better-bibtex/exporting/zotero.lua"
  grep -q 'zotero' "$FILTER" || die "$FILTER does not look like the zotero filter — re-download it"
  if [ "$PMAJ" -lt 2 ] || { [ "$PMAJ" -eq 2 ] && [ "$PMIN" -lt 16 ]; }; then
    die "pandoc $PV is too old for the zotero filter (needs 2.16.2+). brew install pandoc"
  fi
  have_cites "$SRC" \
    || die "no citations found in $SRC. The live route needs [@citekey]
        (markdown) or \\cite{citekey} (LaTeX)."

  # Is Zotero up, and is Better BibTeX answering? Two different failures.
  # BBT's documented probe returns the string "ready" and does not pop up
  # the citation picker.
  if command -v curl >/dev/null; then
    if ! curl -fsS --max-time 3 http://127.0.0.1:23119/connector/ping >/dev/null 2>&1; then
      die "nothing is answering on 127.0.0.1:23119 — Zotero is not running.
        Open Zotero and leave it open; the filter queries it live."
    fi
    ok "Zotero is running (port 23119 answering)"
    PROBE_OUT=$(curl -fsS --max-time 3 'http://127.0.0.1:23119/better-bibtex/cayw?probe=1' 2>/dev/null || true)
    case "$PROBE_OUT" in
      *ready*) ok "Better BibTeX is installed and responding" ;;
      *) die "Zotero is running but Better BibTeX did not answer its probe.
        Expected 'ready' from /better-bibtex/cayw?probe=1, got: '${PROBE_OUT:-<nothing>}'
        Install BBT: Zotero > Tools > Plugins > gear > Install Plugin From File
        https://github.com/retorquere/zotero-better-bibtex/releases/latest" ;;
    esac
  else
    printf '  note  curl not found — skipping the Zotero/BBT checks\n'
  fi
  # author-in-text has to be ON, and -M cannot turn it on.
  #
  # An in-text citation (\citet{k} in LaTeX, a bare @k in markdown) reaches
  # the filter as mode=AuthorInText. With author-in-text off the filter hands
  # the node straight back and you get NO field: from markdown the raw "@key"
  # leaks into the Word file as literal text, and from LaTeX the citation
  # vanishes outright - "Inline: @horne2012 showed this" renders as
  # "Inline: showed this". Nothing warns you in either direction.
  #
  # The filter reads meta.zotero['author-in-text'], which is a NESTED key,
  # and pandoc's -M cannot build one: -M zotero.author-in-text=true quietly
  # sets a flat key of that literal name and is ignored. It must come from
  # a metadata file.
  #
  # What it costs: the author name is written as plain text next to a
  # suppress-author field, so a later restyle in Zotero will not rewrite
  # that name. A visible wart you can fix. A missing citation is neither.
  META="${TMPDIR:-/tmp}/render-zotero-$$.yaml"
  trap 'rm -f "$META"' EXIT
  printf 'zotero:\n  author-in-text: true\n' > "$META"

  "$PANDOC" -s -f "$SRCFMT" --lua-filter="$FILTER" --metadata-file="$META" \
            "$SRC" -o "$OUT" \
    || die "pandoc failed. Is Zotero running with Better BibTeX installed?"

  # Count both ends. The filter skips a citation it cannot resolve and says
  # so on stdout, which scrolls past; a Word file with four fields where the
  # draft had five opens perfectly and looks finished.
  NCITE=$("$PANDOC" -f "$SRCFMT" -t json "$SRC" | python3 -c '
import json, sys
def n(x):
    if isinstance(x, dict):
        return (x.get("t") == "Cite") + sum(n(v) for v in x.values())
    if isinstance(x, list):
        return sum(n(v) for v in x)
    return 0
print(n(json.load(sys.stdin)))')
  NFIELD=$(python3 -c '
import sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
print(sum(z.read(k).count(b"ADDIN ZOTERO_ITEM")
          for k in z.namelist() if k.startswith("word/") and k.endswith(".xml")))' "$OUT")
  if [ "$NCITE" != "$NFIELD" ]; then
    # Delete it. A half-cited .docx sitting next to a good one is a file
    # somebody emails. Failing and leaving the artefact behind is not failing.
    rm -f "$OUT"
    die "$SRC has $NCITE citation(s) but $OUT has $NFIELD Zotero field(s).
        These must match. A missing field is a citation the filter could not
        resolve - scroll up, it printed the key. Fix it in Zotero or in the
        draft and run this again. $OUT has been deleted."
  fi
  ok "$OUT written - $NFIELD live Zotero field(s), one per citation in the source"
  printf '\n  In Word, THREE steps, in this order:\n'
  printf '    1. Zotero tab > Document Preferences > OK\n'
  printf '    2. put the cursor under the References heading, then\n'
  printf '       Zotero tab > Add/Edit Bibliography\n'
  printf '    3. Refresh\n'
  printf '\n  Step 2 is NOT optional and nothing warns you. The filter writes\n'
  printf '  citation fields (ZOTERO_ITEM) only; the bibliography is a separate\n'
  printf '  Zotero field that only the Word plugin can insert. Without it\n'
  printf '  Refresh succeeds silently and no reference list appears, which\n'
  printf '  looks like a failure and is not. Once per document, not per edit.\n'
  printf '\n  Doing Preferences after Refresh gives you a confirmation popup\n'
  printf '  for every single citation.\n'
  printf '\n  If Word calls the file corrupt on first open, re-run this\n'
  printf '  exact command — a documented quirk, and that fixes it.\n'
  ;;

*) die "unknown mode '$MODE' — use rtf, docx or live" ;;
esac
