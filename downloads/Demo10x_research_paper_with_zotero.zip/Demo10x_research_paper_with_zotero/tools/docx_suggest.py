#!/usr/bin/env python3
"""Propose edits to a Zotero-owned Word document as TRACKED CHANGES.

    python3 tools/docx_suggest.py <file.docx> <suggestions.json> [-o out.docx]

suggestions.json is a list of objects:

    [{"find": "exact text in one paragraph",
      "replace": "the replacement",
      "why": "shown nowhere; for your own review of the agent's reasoning"}]

Everything lands as <w:ins>/<w:del>, so Word shows it in Review and YOU accept
or reject. Nothing is silently changed, and the original file is never written.

WHY THIS EXISTS, AND WHY NOT pandoc
-----------------------------------
Once a .docx has live Zotero field codes it is the source of truth. Round
-tripping it through markdown destroys them: docx -> md -> docx returns ZERO
field codes; citations become plain text and Zotero no longer owns them.
Measured on this project's own draft, not assumed.

THREE HARD RULES, each one learned from a failure
-------------------------------------------------
1. Never touch a run that is part of a field. A regex replace that happened to
   span a citation wrapped `ADDIN ZOTERO_ITEM` inside a <w:del> and duplicated
   the field. Runs carrying fldChar/instrText are refused outright.
2. Never run the docx skill's merge_runs.py on a live document. It merges
   prose runs INTO field runs (verified: 0 mixed runs before, 3 after), after
   which rule 1 cannot be satisfied for the text next to any citation.
3. Verify after writing, not just before. Field counts and fldChar balance are
   re-checked against the input, and the output is discarded if they moved.

Citations are NOT insertable from here. Constructing a ZOTERO_ITEM field means
forging Zotero's internal item JSON and citationID. Ask for one with a
suggestion whose replacement contains [CITE: authorYearKeyword]; insert it in
Word with Add/Edit Citation, which is one click and always correct.
"""
import sys, json, copy, re, zipfile
from docx import Document
from docx.oxml.ns import qn

AUTHOR = 'Claude'
DATE = '2026-01-01T00:00:00Z'
FIELD_TAGS = (qn('w:fldChar'), qn('w:instrText'), qn('w:delInstrText'))


def is_field_run(r):
    return any(r.find(t) is not None for t in FIELD_TAGS)


def fingerprint(path):
    with zipfile.ZipFile(path) as z:
        x = z.read('word/document.xml').decode('utf8', 'replace')
    return {
        'ZOTERO_ITEM': x.count('ADDIN ZOTERO_ITEM'),
        'ZOTERO_BIBL': x.count('ADDIN ZOTERO_BIBL'),
        'begin': x.count('w:fldCharType="begin"'),
        'separate': x.count('w:fldCharType="separate"'),
        'end': x.count('w:fldCharType="end"'),
        'instr_in_del': len(re.findall(r'<w:del[ >](?:(?!</w:del>).)*?<w:instrText', x, re.S)),
    }


def mark(run_xml, kind, idx):
    el = run_xml.makeelement(qn('w:' + kind), {})
    el.set(qn('w:id'), str(9000 + idx))
    el.set(qn('w:author'), AUTHOR)
    el.set(qn('w:date'), DATE)
    return el


def all_paragraphs(doc):
    """Every <w:p> in the body, in order — INCLUDING those inside table cells.

    python-docx's doc.paragraphs skips table cells entirely, so a suggestion
    touching a table reported NOT FOUND and silently did nothing. Tables are
    where the numbers live; they are the last thing that should be unreachable.
    """
    body = doc.element.body
    return list(body.iter(qn('w:p')))


def para_runs(para):
    """Every run in document order, with where it sits relative to revisions.

    python-docx's para.runs sees only DIRECT children of <w:p>. After one
    tracked change, the runs it moved live inside <w:ins>/<w:del> and become
    invisible to it — so a second suggestion touching the same sentence would
    report NOT FOUND. Walk the tree instead.
    """
    out = []
    for r in para.iter(qn('w:r')):
        parent = r.getparent()
        tag = parent.tag if parent is not None else ''
        if tag == qn('w:del'):
            continue                      # already deleted; not ours to edit
        out.append((r, tag == qn('w:ins')))
    return out


def run_text(r):
    return ''.join(t.text or '' for t in r.findall(qn('w:t')))


def set_run_text(r, text):
    for t in r.findall(qn('w:t')):
        r.remove(t)
    t = r.makeelement(qn('w:t'), {})
    t.text = text
    t.set(qn('xml:space'), 'preserve')
    r.append(t)


def apply_one(doc, find, replace, idx):
    """Replace `find` with `replace` as a tracked change. Returns a status str."""
    for para in all_paragraphs(doc):
        allruns = para_runs(para)
        spans, pos = [], 0
        for r, in_ins in allruns:
            if is_field_run(r):
                continue              # field display text is Zotero's, not ours
            t = run_text(r)
            spans.append((pos, pos + len(t), r, in_ins))
            pos += len(t)
        plain = ''.join(s[2] is not None and run_text(s[2]) or '' for s in spans)
        at = plain.find(find)
        if at < 0:
            continue
        hit = [s for s in spans if s[0] < at + len(find) and s[1] > at]
        if not hit:
            continue

        # Already inside one of our insertions? Then it is still a tracked
        # insertion after editing — just change the text and stop.
        if len(hit) == 1 and hit[0][3]:
            r = hit[0][2]
            set_run_text(r, run_text(r).replace(find, replace, 1))
            return f'ok      {find[:50]!r} -> {replace[:50]!r}  (folded into an earlier suggestion)'

        order = [r for r, _ in allruns]
        first, last = hit[0][2], hit[-1][2]
        i0, i1 = order.index(first), order.index(last)
        if any(is_field_run(r) for r in order[i0:i1 + 1]):
            return f'REFUSED (a citation field sits inside the match): {find[:60]}'
        if any(ins for r, ins in allruns[i0:i1 + 1]):
            return (f'REFUSED (match straddles an earlier suggestion; '
                    f'make it one suggestion instead): {find[:60]}')

        merged = ''.join(run_text(r) for r in order[i0:i1 + 1])
        lead = at - hit[0][0]
        head, tail = merged[:lead], merged[lead + len(find):]

        parent = first.getparent()
        anchor = list(parent).index(first)
        proto = copy.deepcopy(first)          # carries the run's formatting

        def plain(text):
            r = copy.deepcopy(proto); set_run_text(r, text); return r

        # Mark ONLY the changed phrase. Deleting and re-inserting the whole run
        # is correct XML but unreadable in Word: a one-word fix strikes through
        # the entire paragraph and nobody can see what actually changed.
        out = []
        if head:
            out.append(plain(head))
        dele = mark(first, 'del', idx * 2)
        dr = copy.deepcopy(proto)
        for t in dr.findall(qn('w:t')):
            dr.remove(t)
        dt = dr.makeelement(qn('w:delText'), {})
        dt.text = find
        dt.set(qn('xml:space'), 'preserve')
        dr.append(dt)
        dele.append(dr)
        out.append(dele)
        ins = mark(first, 'ins', idx * 2 + 1)
        ins.append(plain(replace))
        out.append(ins)
        if tail:
            out.append(plain(tail))

        for r in order[i0:i1 + 1]:
            r.getparent().remove(r)
        for k, node in enumerate(out):
            parent.insert(anchor + k, node)
        return f'ok      {find[:50]!r} -> {replace[:50]!r}'
    return (f'NOT FOUND (must be exact, and within one paragraph or table cell): '
            f'{find[:60]}')


def main():
    a = [x for x in sys.argv[1:] if not x.startswith('-')]
    if len(a) < 2:
        sys.exit(__doc__)
    src, sug = a[0], a[1]
    out = sys.argv[sys.argv.index('-o') + 1] if '-o' in sys.argv \
        else src.replace('.docx', '-suggested.docx')
    if out == src:
        sys.exit('refusing to write over the input')

    items = json.load(open(sug))
    before = fingerprint(src)
    doc = Document(src)
    results = [apply_one(doc, it['find'], it['replace'], i) for i, it in enumerate(items)]
    doc.save(out)
    after = fingerprint(out)

    for r in results:
        print('  ' + r)
    print()
    bad = {k: (before[k], after[k]) for k in before if before[k] != after[k]}
    if bad or after['instr_in_del']:
        import os
        os.remove(out)
        sys.exit(f'\n  FAIL  field integrity changed, output DISCARDED: {bad}\n'
                 f'        instrText inside a deletion: {after["instr_in_del"]}\n'
                 f'        {src} is untouched.')
    print(f'  ok    fields intact: {before["ZOTERO_ITEM"]} citation(s), '
          f'{before["ZOTERO_BIBL"]} bibliography, fldChar balanced')
    print(f'  ok    {out}')
    print('\n  Open it in Word > Review tab. Accept or reject each change.')
    print('  Citations and bibliography stay live throughout; Refresh still works.')
    if any(r.startswith(('REFUSED', 'NOT FOUND')) for r in results):
        print('\n  Some suggestions did not apply. Nothing was forced.')


main()
