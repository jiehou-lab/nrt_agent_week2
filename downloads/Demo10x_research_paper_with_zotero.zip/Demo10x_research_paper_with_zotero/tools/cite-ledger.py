#!/usr/bin/env python3
"""Remember which claims have already been verified, so nothing is checked twice.

    python3 tools/cite-ledger.py --log     <draft>          what WAS verified, and when
    python3 tools/cite-ledger.py --skip    <draft>          OPT-IN: what could be skipped
    python3 tools/cite-ledger.py --record  <draft> KEY VERDICT "evidence"
    python3 tools/cite-ledger.py --forget  KEY               drop entries for one source
    python3 tools/cite-ledger.py --stale                     entries whose note has changed since

WHAT THIS IS FOR — AND WHAT IT IS NOT FOR
-----------------------------------------
This is a RECORD, not a cache. Its job is to answer "what did I verify, when,
and against what" — the question a co-author or a reviewer may reasonably ask,
and the one you cannot answer from an agent transcript that no longer exists.

**Verification is re-run every time by default.** Skipping is opt-in (--skip),
and you should usually not. Two reasons, and the second is the real one:

1. An agent is not deterministic. A verdict recorded with its evidence is a
   different thing from a verdict re-derived; neither is strictly better, so
   re-running costs little in reliability terms.

2. **A cache of judgements is where false confidence hides.** If the
   invalidation logic is wrong — and the logic below is exactly the kind of
   thing that looks right and is not — the ledger will assert "verified" for a
   claim that changed, silently. An unverified claim is a known unknown. A
   wrongly-cached one is a trap.

CACHE THE EXTRACTION, NEVER THE VERDICT.
`.cache/pdftext/` holds pdftotext output. Re-extracting a PDF gives
byte-identical text, so caching that is free and risk-free. That is where the
expensive part actually lives: reading the PDF, not deciding about it.

WHAT MAKES AN ENTRY VALID
-------------------------
A verdict is keyed on a hash of (normalised sentence + cite key). Change the
sentence by one word and the hash changes, so the claim is checked again —
which is correct: you changed the claim. Change nothing and it is skipped.

A note-based verdict also records the note's own hash. Edit the note and the
verdict goes STALE, because what you verified against is no longer what the
note says. PDF-based verdicts do not expire: the paper does not change.

The ledger is versioned in git on purpose. It is a record of what you checked
and when — the kind of thing a reviewer or a co-author may reasonably ask for.
"""
import sys, os, re, json, hashlib, pathlib, datetime

LEDGER = pathlib.Path('writing/citecheck-ledger.json')
NOTES  = pathlib.Path('papers/notes')
BIB    = pathlib.Path('papers/library/library.bib')
CITE   = re.compile(r'\\cite[a-zA-Z]*\s*(?:\[[^\]]*\])*\s*\{([^}]*)\}|\[@([\w:-]+)\]')
OK     = {'confirmed-by-note', 'confirmed-in-pdf'}

def norm(s):
    """Whitespace and the citation command itself are not part of the claim."""
    s = CITE.sub('', s)
    return re.sub(r'\s+', ' ', s).strip().lower()

def claim_id(sentence, key):
    return hashlib.sha1((norm(sentence) + '|' + key).encode()).hexdigest()[:16]

def sentences(t):
    t = re.sub(r'%.*', '', t); t = re.sub(r'\s+', ' ', t)
    return [s for s in re.split(r'(?<=[.!?])\s+', t) if s.strip()]

def cited(s):
    out = []
    for m in CITE.finditer(s):
        if m.group(1): out += [k.strip() for k in m.group(1).split(',') if k.strip()]
        elif m.group(2): out.append(m.group(2))
    return out

def load():
    return json.loads(LEDGER.read_text()) if LEDGER.is_file() else {}

def save(d):
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    LEDGER.write_text(json.dumps(d, indent=2, sort_keys=True) + '\n')

def note_hash_for(key):
    """Hash the note that backs this cite key, if there is one."""
    doi = None
    if BIB.is_file():
        cur = None
        for ln in BIB.read_text(errors='replace').splitlines():
            m = re.match(r'\s*@\w+\{([^,]+),', ln)
            if m: cur = m.group(1).strip()
            d = re.match(r'\s*doi\s*=\s*[{"]?([^}",]+)', ln, re.I)
            if d and cur == key: doi = d.group(1).strip().lower()
    if not doi or not NOTES.is_dir(): return None
    for f in NOTES.glob('*.md'):
        t = f.read_text(errors='replace')
        m = re.search(r'^doi:\s*"?([^"\n]+)', t, re.M)
        if m and m.group(1).strip().lower() == doi:
            return hashlib.sha1(t.encode()).hexdigest()[:16]
    return None

def report(draft, skip_mode=False):
    led = load()
    text = pathlib.Path(draft).read_text(errors='replace')
    done, stale, todo = [], [], []
    for s in sentences(text):
        for k in cited(s):
            cid = claim_id(s, k)
            e = led.get(cid)
            if not e or e.get('verdict') not in OK:
                todo.append((k, s[:110])); continue
            if e.get('note_hash') and e['note_hash'] != note_hash_for(k):
                stale.append((k, e, s[:110]))
            else:
                done.append((k, e))
    if not skip_mode:
        print(f"  {len(done)+len(stale)+len(todo)} cited claim(s) in this draft")
        print(f"  {len(done)} previously verified, {len(stale)} since gone stale")
        print( "  Default is to CHECK THEM ALL. This is a log, not a skip list.\n")
    else:
        print(f"  already verified   {len(done)}")
        print(f"  STALE (note edited) {len(stale)}")
        print(f"  not yet checked    {len(todo)}")
    if done:
        print("\n  --- previously verified (context; check them anyway):"
              if not skip_mode else "\n  --- settled, being skipped:")
        for k, e in done:
            print(f"      [{k}] {e['verdict']} on {e['checked']} — {e.get('evidence','')[:60]}")
    if stale:
        print("\n  --- the note changed since you verified against it. Re-check:")
        for k, e, s in stale:
            print(f"      [{k}] verified {e['checked']} — {s}…")
    if todo:
        print("\n  --- new or changed claims:")
        for k, s in todo: print(f"      [{k}] {s}…")
    if skip_mode:
        print(f"\n  --skip was used: hand the agent {len(todo)+len(stale)}, not "
              f"{len(done)+len(stale)+len(todo)}. You are trusting {len(done)} old verdict(s).")
    return todo, stale

def record(draft, key, verdict, evidence):
    led = load()
    text = pathlib.Path(draft).read_text(errors='replace')
    n = 0
    for s in sentences(text):
        if key not in cited(s): continue
        cid = claim_id(s, key)
        led[cid] = {
            'key': key, 'verdict': verdict, 'evidence': evidence,
            'checked': datetime.date.today().isoformat(),
            'sentence': s[:120],
            **({'note_hash': note_hash_for(key)} if verdict == 'confirmed-by-note' else {}),
        }
        n += 1
    save(led); print(f"  recorded {n} claim(s) for {key} as {verdict}")

def main():
    a = sys.argv[1:]
    if not a: sys.exit(__doc__)
    if a[0] == '--log' and len(a) > 1: report(a[1], skip_mode=False)
    elif a[0] == '--skip' and len(a) > 1: report(a[1], skip_mode=True)
    elif a[0] == '--record' and len(a) >= 4: record(a[1], a[2], a[3], a[4] if len(a) > 4 else '')
    elif a[0] == '--forget' and len(a) > 1:
        led = load(); gone = [k for k, v in led.items() if v.get('key') == a[1]]
        for k in gone: del led[k]
        save(led); print(f"  forgot {len(gone)} entr(ies) for {a[1]}")
    elif a[0] == '--stale':
        led = load(); n = 0
        for cid, e in led.items():
            if e.get('note_hash') and e['note_hash'] != note_hash_for(e['key']):
                print(f"  [{e['key']}] verified {e['checked']} — note has changed"); n += 1
        print(f"  {n} stale entr(ies)")
    else: sys.exit(__doc__)

main()
