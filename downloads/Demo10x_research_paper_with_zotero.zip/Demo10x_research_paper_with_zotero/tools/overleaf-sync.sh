#!/usr/bin/env bash
# Commit your section and get it onto the shared Overleaf project — safely,
# in a room where thirty other people are pushing to the same branch.
#
#   tools/overleaf-sync.sh sections/yourname.tex "what you added"
#   tools/overleaf-sync.sh                        (uses YOUR_SECTION below)
#
# WHY THIS EXISTS
# ---------------
# Measured, two clones of one repo:
#
#   different files -> push REJECTED ("fetch first"), then pull --rebase
#                      succeeds silently and both contributions land.
#   the same file   -> push REJECTED, pull --rebase CONFLICTS, and you are
#                      left mid-rebase with "UU main.tex" and no idea why.
#
# So the rule for a classroom is: ONE FILE PER PERSON. This script enforces
# it, retries the first case until it wins, and refuses to leave you stranded
# in the second.
set -uo pipefail

YOUR_SECTION="${YOUR_SECTION:-}"
FILE="${1:-$YOUR_SECTION}"
MSG="${2:-update}"
TRIES=8

die(){ printf '\n  \033[31mFAIL\033[0m  %s\n' "$*" >&2; exit 1; }
ok(){  printf '  \033[32mok\033[0m    %s\n' "$*"; }
note(){ printf '  note  %s\n' "$*"; }

git rev-parse --git-dir >/dev/null 2>&1 || die "not inside a git repo.
        You are probably one folder too high — the Overleaf clone is the
        folder you cloned INTO. Check with: git remote -v"
git remote get-url origin 2>/dev/null | grep -q overleaf \
  || note "origin does not look like Overleaf — continuing anyway"

[ -n "$FILE" ] || die "which file is yours?
        tools/overleaf-sync.sh sections/yourname.tex \"what you added\""
[ -f "$FILE" ] || die "no such file: $FILE
        Create it first; do not edit someone else's section."

# --- the rule that makes this work at all --------------------------------
MYBIB_EARLY="refs/$(basename "${FILE%.*}").bib"
STRAY=$(git status --porcelain | awk '{print $2}' \
        | grep -v "^${FILE}$" | grep -v "^${MYBIB_EARLY}$" || true)
if [ -n "$STRAY" ]; then
  printf '\n  You have changes outside your own section:\n'
  printf '%s\n' "$STRAY" | sed 's/^/        /'
  printf '\n        In a shared project that is how you collide with someone\n'
  printf '        else. Revert them, or commit them separately and deliberately:\n'
  printf '            git checkout -- <file>\n'
  die "refusing to push changes outside $FILE"
fi

git status --porcelain -- "$FILE" "$MYBIB_EARLY" | grep -q . \
  || { note "nothing changed in $FILE or $MYBIB_EARLY"; exit 0; }

git add -- "$FILE" ${MYBIB_EARLY:+"$MYBIB_EARLY"} 2>/dev/null || git add -- "$FILE"
git commit -qm "$MSG" || die "commit failed"
ok "committed your change to $FILE"

# --- the one that breaks EVERYONE'S bibliography -------------------------
# Measured: two refs/*.bib files sharing one cite key makes bibtex fail with
# "Repeated entry", latexmk exit 12, and EVERY citation in the document —
# not just the duplicated one — renders as [?]. In a room where several
# people cite the same paper, Better BibTeX gives them the same key, so this
# is close to certain unless something checks.
MYBIB="refs/$(basename "${FILE%.*}").bib"
if [ -f "$MYBIB" ]; then
  MINE=$(grep -oE '^@[A-Za-z]+\{[^,]+' "$MYBIB" | sed 's/^@[A-Za-z]*{//' | sort -u)
  THEIRS=$(ls refs/*.bib 2>/dev/null | grep -v "^${MYBIB}$" \
           | xargs -r grep -hoE '^@[A-Za-z]+\{[^,]+' | sed 's/^@[A-Za-z]*{//' | sort -u)
  CLASH=$(comm -12 <(printf '%s\n' "$MINE") <(printf '%s\n' "$THEIRS") | grep . || true)
  if [ -n "$CLASH" ]; then
    printf '\n  These cite keys are already in somebody else'"'"'s .bib:\n'
    printf '%s\n' "$CLASH" | sed 's/^/        /'
    printf '\n        Keeping both copies makes bibtex fail and turns EVERY\n'
    printf '        citation in the shared document into [?] — not just yours.\n'
    printf '        Delete these entries from %s and push again.\n' "$MYBIB"
    printf '        Your \\cite still works: the bibliography is shared, so one\n'
    printf '        copy of an entry serves everyone who cites it.\n'
    die "duplicate cite keys — nothing pushed"
  fi
  ok "no cite-key collisions with the other $(ls refs/*.bib 2>/dev/null | wc -l | tr -d ' ') bib file(s)"
fi

# --- push, losing races politely -----------------------------------------
for i in $(seq 1 $TRIES); do
  if git push -q 2>/dev/null; then
    ok "pushed on attempt $i"
    printf '\n  Reload the Overleaf tab. Your section is in the project.\n'
    exit 0
  fi
  note "someone pushed first (attempt $i/$TRIES) — rebasing onto their work"
  if ! git pull -q --rebase 2>/dev/null; then
    git rebase --abort 2>/dev/null
    printf '\n  Your change and someone else'"'"'s touch the SAME lines.\n'
    printf '  Nothing is lost and you are not stuck — the rebase was undone.\n\n'
    printf '  Almost always this means you edited a file that is not yours.\n'
    printf '  Your work is still committed locally. Ask for help, or:\n'
    printf '      git log --oneline -1     # your commit is here\n'
    die "real conflict in $FILE — not retrying"
  fi
  sleep "0.$(( (RANDOM % 7) + 2 ))"      # jitter, so 30 people do not retry in step
done
die "could not push after $TRIES attempts. The project may be busy;
        wait a moment and run this again. Your commit is safe locally."
