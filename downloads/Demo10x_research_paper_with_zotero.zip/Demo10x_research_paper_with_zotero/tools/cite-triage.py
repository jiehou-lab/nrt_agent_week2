#!/usr/bin/env python3
"""Triage citations against YOUR NOTES first, and only then the PDFs.

    python3 tools/cite-triage.py <draft.tex|draft.md>

WHY NOTES FIRST
---------------
A note's `## Evidence` is already a human-verified extraction from the paper.
Checking a claim against it is cheaper than opening the PDF, and it uses the
information the drafter already declared: a `note`-tier claim SAID the
evidence lives in the note. If it does not, that is a finding in itself.

Two different things get confused here, so this tool names them:

  FIDELITY  does the claim match what my note says?   (cheap, and circular if
            the draft was written from the note — it catches drift and
            overstatement, not a misreading of the paper)
  TRUTH     does the claim match what the PAPER says? (needs the PDF)

A note whose frontmatter says `attachment_read: false` was never checked
against the source, so confirming against it proves fidelity to an unverified
note. That is reported separately rather than counted as a pass.
"""
import sys, os, re, glob, pathlib

ROOT  = pathlib.Path('.')
NOTES = ROOT / 'papers' / 'notes'
BIB   = ROOT / 'papers' / 'library' / 'library.bib'
CACHE = ROOT / '.cache' / 'pdftext'

CITE = re.compile(r'\\cite[a-zA-Z]*\s*(?:\[[^\]]*\])*\s*\{([^}]*)\}|\[@([\w:-]+)\]')
NUM  = re.compile(r'(?<![\w.])\d+(?:\.\d+)?(?![\w])')

def sentences(t):
    t = re.sub(r'%.*', '', t); t = re.sub(r'\s+', ' ', t)
    return re.split(r'(?<=[.!?])\s+', t)

def bib_dois():
    """cite key -> doi, from the .bib"""
    if not BIB.is_file(): return {}
    out, key = {}, None
    for ln in BIB.read_text(errors='replace').splitlines():
        m = re.match(r'\s*@\w+\{([^,]+),', ln)
        if m: key = m.group(1).strip(); continue
        d = re.match(r'\s*doi\s*=\s*[{"]?([^}",]+)', ln, re.I)
        if d and key: out[key] = d.group(1).strip().lower()
    return out

def load_notes():
    """doi -> (path, attachment_read, evidence-ish body)"""
    out = {}
    for f in sorted(NOTES.glob('*.md')):
        t = f.read_text(errors='replace')
        d = re.search(r'^doi:\s*"?([^"\n]+)', t, re.M)
        if not d: continue
        read = bool(re.search(r'^attachment_read:\s*true', t, re.M))
        body = []
        for sec in ('## Evidence', '## Supports', '## Claim', '## Checks', '## Method'):
            m = re.search(re.escape(sec) + r'(.*?)(?=\n## |\Z)', t, re.S)
            if m: body.append(m.group(1))
        out[d.group(1).strip().lower()] = (f, read, '\n'.join(body))
    return out

def main():
    if len(sys.argv) < 2: sys.exit(__doc__)
    draft = pathlib.Path(sys.argv[1])
    dois, notes = bib_dois(), load_notes()
    pdfs = {pathlib.Path(p).stem: open(p, errors='replace').read()
            for p in glob.glob(str(CACHE / '*.txt'))}

    by_note, unverified_note, need_pdf, by_pdf, no_source, nonum = [], [], [], [], [], 0
    seen = 0
    for s in sentences(draft.read_text(errors='replace')):
        keys = []
        for m in CITE.finditer(s):
            if m.group(1): keys += [k.strip() for k in m.group(1).split(',') if k.strip()]
            elif m.group(2): keys.append(m.group(2))
        if not keys: continue
        seen += 1
        nums = [n for n in NUM.findall(s) if not re.fullmatch(r'(19|20)\d\d', n)]
        for k in keys:
            doi = dois.get(k, '')
            note = notes.get(doi)
            if not nums:
                nonum += 1
                continue
            if note:
                f, read, body = note
                miss = [n for n in nums if n not in body]
                if not miss:
                    (by_note if read else unverified_note).append((k, f.name, s[:120]))
                    continue
                need_pdf.append((k, f.name, miss, s[:130]))
                continue
            # no note: fall back to the PDF
            body = pdfs.get(k)
            if body is None:
                no_source.append((k, s[:100])); continue
            miss = [n for n in nums if n not in body]
            (by_pdf if not miss else need_pdf).append(
                (k, '(no note)', miss, s[:130]) if miss else (k, '(no note)', s[:120]))

    print(f"  {seen} sentence(s) carry a citation\n")
    print(f"  confirmed by a note you read     {len(by_note)}")
    print(f"  confirmed by an UNREAD note      {len(unverified_note)}   <- fidelity only")
    print(f"  confirmed in the PDF, no note    {len(by_pdf)}")
    print(f"  no numbers to match on           {nonum}   <- must be read")
    print(f"  NEED ATTENTION                   {len(need_pdf)}")
    if no_source: print(f"  no note AND no cached PDF        {len(no_source)}")

    if unverified_note:
        print("\n  --- the note confirms these, but its attachment_read is false.")
        print("      You are checking the claim against something nobody checked.")
        for k, n, s in unverified_note: print(f"      [{k}] {n}")
    if need_pdf:
        print("\n  --- a number here is in neither the note nor (where checked) the paper:\n")
        for k, n, miss, s in need_pdf:
            print(f"    [{k}]  note: {n}")
            print(f"      missing: {', '.join(miss)}")
            print(f"      {s}…")
            print(f"      -> open the PDF for this one. If the paper DOES support it,")
            print(f"         the note is incomplete — propose adding it to ## Evidence.\n")
    if no_source:
        print("\n  --- nothing to check against. Extract or write a note first:")
        for k, s in no_source: print(f"      {k}")
    print(f"\n  Agent work: {len(need_pdf) + nonum} claim(s), not {seen}.")

main()
