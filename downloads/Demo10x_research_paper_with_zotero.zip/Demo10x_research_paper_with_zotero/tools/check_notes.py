#!/usr/bin/env python3
"""Check every note in papers/notes/ against the contract in _templates/paper.md.

Why this exists: so a note written by something that has never read this
workspace's rules — an external summarising skill, a tool off GitHub, a
future agent — is still caught before it becomes 300 notes of drift.

It only reads. It cannot fix anything, for the same reason citecheck has no
Write tool: a checker that can edit can make its own findings disappear.

    python3 tools/check_notes.py            # report, exit 1 if any ERROR
    python3 tools/check_notes.py --warn     # also fail on WARN
"""
import sys, re, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NOTES = ROOT / "papers" / "notes"
MANIFEST = ROOT / "papers" / "library" / "MANIFEST.md"
AREAS = {"methods", "application", "evaluation", "background"}

REQUIRED_FIELDS = ["type", "title", "year", "doi", "item_key", "area",
                   "added", "status"]
REQUIRED_SECTIONS = ["## Problem and aim", "## Claim", "## Method", "## Evidence",
                     "## Supports", "## Checks", "## Limitations",
                     "## Relevance", "## Links", "## My take"]
NAME_RE = re.compile(r"^[A-Z][A-Za-z\-']*\d{4}[a-z]?-[a-z0-9\-]+$")


def manifest_fields():
    """metadata_file, key_column and the attachment directory, from MANIFEST.md."""
    out = {}
    if MANIFEST.is_file():
        for ln in MANIFEST.read_text(encoding="utf-8").splitlines()[:40]:
            m = re.match(r'\s*(metadata_file|key_column|attachment_path):\s*"?([^"#]+?)"?\s*(?:#.*)?$', ln)
            if m:
                out[m.group(1)] = m.group(2).strip()
    return out


def check_library():
    """The failure this catches is silent: a new metadata table exported
    against an old attachment folder. Nothing errors; the notes just point
    at files that are not there."""
    f = manifest_fields()
    lib = MANIFEST.parent
    msgs = []
    meta = lib / f.get("metadata_file", "") if f.get("metadata_file") else None
    att = f.get("attachment_path", "")
    if "<" in att:
        head = att.split("<")[0]
        # absolute or ~-relative => the live data directory, not an export
        attdir = (Path(head).expanduser() if head.startswith(("~", "/"))
                  else lib / head.strip("/"))
    else:
        attdir = None

    if meta is None or not meta.is_file():
        return [f"library: no {f.get('metadata_file','metadata file')} exported yet"]
    nrows = 0
    keys = set()
    try:
        import csv as _csv
        with meta.open(encoding="utf-8-sig", newline="") as fh:
            if meta.suffix.lower() == ".csv":
                for row in _csv.DictReader(fh):
                    nrows += 1
                    k = (row.get(f.get("key_column", "Key")) or "").strip()
                    if k:
                        keys.add(k)
            else:
                nrows = sum(1 for ln in fh if ln.lstrip().startswith("@"))
    except Exception as e:
        return [f"library: could not read {meta.name}: {e}"]

    if attdir is None or not attdir.is_dir():
        msgs.append(f"library: {nrows} items in {meta.name}, but no attachment folder "
                    f"at {att} — nothing can open a PDF. Is the path right in "
                    f"MANIFEST.md, and is it in additionalDirectories?")
        return msgs

    folders = {d.name for d in attdir.iterdir() if d.is_dir()}
    live = att.startswith(("~", "/"))
    dt = abs(meta.stat().st_mtime - attdir.stat().st_mtime)
    if not live and dt > 3600:
        msgs.append(f"library: {meta.name} and {attdir.name}/ were last written "
                    f"{dt/3600:.1f} h apart — EXPORT THEM AS A SET or attachment "
                    f"paths go stale silently")
    if keys and live:
        # The reverse direction, and the one that catches a forgotten export:
        # storage/ is LIVE, so a folder with no CSV row means the library moved
        # on and the snapshot did not.
        extra = folders - keys
        if extra:
            if len(extra) > len(keys):
                msgs.append(f"library: {len(keys)} rows in {meta.name} but "
                            f"{len(folders)} attachment folders — this CSV looks like "
                            f"a COLLECTION, not the whole library. Re-export My Library.")
            else:
                msgs.append(f"library: {len(extra)} attachment folders have no row in "
                            f"{meta.name} — Zotero has moved on; RE-EXPORT THE CSV. "
                            f"(upper bound: also counts web snapshots and trashed items)")
    if keys:
        gone = keys - folders
        if gone:
            why = ("either the CSV is newer than Zotero's files, or those items "
                   "have no PDF attached" if live else
                   "the CSV and the attachment folder are out of step")
            msgs.append(f"library: {len(gone)} of {len(keys)} keys have no attachment "
                        f"folder (e.g. {', '.join(sorted(gone)[:5])}) — {why}")
    return msgs


def manifest_key_regex():
    if not MANIFEST.is_file():
        return None, "papers/library/MANIFEST.md is missing — no key shape to check against"
    for ln in MANIFEST.read_text(encoding="utf-8").splitlines()[:40]:
        m = re.match(r'\s*key_regex:\s*"?([^"#]+?)"?\s*(?:#.*)?$', ln)
        if m:
            try:
                return re.compile(m.group(1)), None
            except re.error as e:
                return None, f"key_regex in MANIFEST.md is not a valid regex: {e}"
    return None, "MANIFEST.md has no key_regex: — item_key shape cannot be checked"


def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        return None, text
    fm = {}
    for ln in m.group(1).splitlines():
        k = re.match(r"([A-Za-z_]+):\s*(.*)$", ln)
        if k:
            fm[k.group(1)] = k.group(2).split("#")[0].strip()
    return fm, text[m.end():]


def section_body(body, head):
    i = body.find(head)
    if i < 0:
        return None
    j = body.find("\n## ", i + len(head))
    return body[i + len(head): j if j > 0 else len(body)].strip()


def check(path, key_re):
    err, warn = [], []
    text = path.read_text(encoding="utf-8", errors="replace")
    fm, body = frontmatter(text)
    if fm is None:
        return ["no YAML frontmatter"], []

    if not NAME_RE.match(path.stem):
        warn.append(f"filename '{path.stem}' is not <Author><Year>-<slug>")

    for f in REQUIRED_FIELDS:
        if f not in fm:
            err.append(f"frontmatter is missing `{f}:`")

    key = fm.get("item_key", "").strip('"\'')
    if key and key != "none" and key_re and not key_re.match(key):
        err.append(f"item_key '{key}' does not match the manifest's key_regex")
    doi = fm.get("doi", "").strip('"\'')
    if key == "none" and doi in ("", "unknown"):
        err.append("item_key is none AND doi is empty — nothing can ever join this note")
    if doi and doi not in ("unknown",) and not doi.startswith("10."):
        warn.append(f"doi '{doi}' does not start with '10.'")

    areas = [a.strip().lower() for a in fm.get("area", "").strip("[]").split(",") if a.strip()]
    if not areas:
        err.append("area: is empty")
    for a in areas:
        if a not in AREAS:
            err.append(f"area '{a}' is not one of {sorted(AREAS)}")

    added = fm.get("added", "").strip('"\'')
    try:
        datetime.date.fromisoformat(added)
    except ValueError:
        err.append(f"added: '{added}' is not a YYYY-MM-DD date")

    for sec in REQUIRED_SECTIONS:
        if sec not in body:
            err.append(f"missing section `{sec}`")

    meth = section_body(body, "## Method")
    if meth is not None:
        clean = re.sub(r"<!--.*?-->", "", meth, flags=re.S).strip()
        if len(clean) < 20:
            err.append("## Method is empty — no way to judge whether the numbers mean anything")
        elif not re.search(r"valid|split|cross-?val|hold-?out|external|cohort|not stated",
                           clean, re.I):
            warn.append("## Method says nothing about the validation split")
    rel = section_body(body, "## Relevance")
    if rel is not None:
        clean = re.sub(r"<!--.*?-->", "", rel, flags=re.S).strip()
        if not clean:
            warn.append("## Relevance is empty — why was this read?")
        elif not re.search(r"\bQ\d+\b|no current question", clean):
            warn.append("## Relevance cites no Q-number and does not say 'no current question'")
    prob = section_body(body, "## Problem and aim")
    if prob is not None:
        clean = re.sub(r"<!--.*?-->", "", prob, flags=re.S).strip()
        if len(clean) < 20:
            warn.append("## Problem and aim is empty — the novelty claim was not checked")
        elif not re.search(r"\*\*Aim\*\*|aim[:\s]", clean, re.I):
            warn.append("## Problem and aim records no Aim — only the gap")

    ev = section_body(body, "## Evidence")
    sup = section_body(body, "## Supports")
    chk = section_body(body, "## Checks")
    if ev is not None and len(ev) < 20:
        err.append("## Evidence is empty — a note with no evidence is a summary")
    if sup and (ev is None or len(ev) < 20):
        err.append("## Supports has content but ## Evidence does not: unsupported citations")
    if sup and not re.search(r"(Table|Fig|§|Section|p\.|pp\.)", sup, re.I):
        warn.append("no ## Supports statement cites a table, figure or section")
    if chk is not None and len(chk) < 20:
        warn.append("## Checks is empty — abstract vs tables was not done, or not recorded")

    take = section_body(body, "## My take")
    if take:
        take = re.sub(r"<!--.*?-->", "", take, flags=re.S).strip()
    if take:
        warn.append("## My take is not empty — confirm YOU wrote it, no agent may")
    return err, warn


def main():
    key_re, kerr = manifest_key_regex()
    if kerr:
        print(f"NOTE  {kerr}", file=sys.stderr)
    for m in check_library():
        print(f"warn   {m}"); 
    if not NOTES.is_dir():
        sys.exit("no papers/notes/")
    files = sorted(f for f in NOTES.glob("*.md") if not f.name.startswith("_"))
    nerr = nwarn = 0
    for f in files:
        e, w = check(f, key_re)
        for m in e:
            print(f"ERROR  {f.name}: {m}"); nerr += 1
        for m in w:
            print(f"warn   {f.name}: {m}"); nwarn += 1
    print(f"\n{len(files)} notes — {nerr} error(s), {nwarn} warning(s)")
    if nerr or (nwarn and "--warn" in sys.argv):
        sys.exit(1)


if __name__ == "__main__":
    main()
