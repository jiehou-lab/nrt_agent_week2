#!/usr/bin/env bash
# Compile a LaTeX draft, and FAIL on the things LaTeX does not fail on.
#
#   tools/tex.sh writing/drafts/paper.tex           compile + check
#   tools/tex.sh writing/drafts/paper.tex --look    also render pages to PNG
#
# WHY THIS EXISTS
# ---------------
# `latexmk` exits 0 on an undefined citation. The PDF builds, looks finished,
# and renders the citation as "?" in the body with the reference missing from
# the bibliography. Verified: a one-character typo in a cite key produced a
# 68 KB PDF and exit status 0. That is the single most likely way to submit a
# manuscript with a broken reference, so it is checked here and it is fatal.
#
# The warning IS in the .log — but LaTeX WRAPS IT across lines mid-word
# ("undef" / "ined"), so the obvious grep finds nothing. Every check below
# flattens the log first. This exact trap cost an hour elsewhere in this
# project with three different tools.
set -uo pipefail

die() { printf '\n  FAIL  %s\n' "$*" >&2; exit 1; }
ok()  { printf '  ok    %s\n' "$*"; }
note(){ printf '  note  %s\n' "$*"; }

SRC=${1:-}
[ -n "$SRC" ] || die "usage: tools/tex.sh <draft.tex> [--look]"
[ -f "$SRC" ] || die "no such file: $SRC"
command -v latexmk >/dev/null || die "latexmk not installed. See writing/README.md —
        BasicTeX (~100 MB) or Tectonic are both enough; MacTeX (~5 GB) is not needed."

DIR=$(cd "$(dirname "$SRC")" && pwd); BASE=$(basename "${SRC%.tex}")
cd "$DIR"

latexmk -pdf -interaction=nonstopmode -halt-on-error "$BASE.tex" >/dev/null 2>&1
STATUS=$?
LOG="$BASE.log"
[ -f "$LOG" ] || die "no log produced — latexmk did not run"

# Flatten: join every line, so a warning wrapped mid-word is still findable.
FLAT=$(tr -d '\r' < "$LOG" | tr '\n' ' ' | tr -s ' ')

if [ $STATUS -ne 0 ]; then
  printf '\n  LaTeX error:\n'
  grep -m3 -A2 '^!' "$LOG" | sed 's/^/        /'
  grep -m1 -o 'l\.[0-9]* .*' "$LOG" | sed 's/^/        at /'
  die "compile failed (latexmk exit $STATUS). Nothing else was checked."
fi
ok "compiled — $BASE.pdf"

# --- the silent one -------------------------------------------------------
UNDEF_CITE=$(printf '%s' "$FLAT" | grep -o "Citation \`[^']*' on page" \
             | sed "s/Citation \`//;s/' on page//" | sort -u)
if [ -n "$UNDEF_CITE" ]; then
  printf '\n  Undefined citation keys — the PDF built anyway and renders "?":\n'
  printf '%s\n' "$UNDEF_CITE" | sed 's/^/        /'
  printf '\n        These keys are not in your .bib. Either the key is mistyped,\n'
  printf '        or Better BibTeX regenerated it when you edited the item in\n'
  printf '        Zotero. Pin it: Zotero > the item > Extra > "Citation Key: ..."\n'
  die "undefined citations. latexmk exited 0; this script does not."
fi
ok "every \\cite key resolved"

# BibTeX reports missing entries separately, and sometimes only here.
if [ -f "$BASE.blg" ]; then
  MISS=$(grep -o "didn't find a database entry for \"[^\"]*\"" "$BASE.blg" | sort -u)
  [ -z "$MISS" ] || { printf '\n%s\n' "$MISS" | sed 's/^/        /'; die "bibtex could not find those entries"; }
  ok "bibtex resolved every entry"
fi

UNDEF_REF=$(printf '%s' "$FLAT" | grep -o "Reference \`[^']*' on page" \
            | sed "s/Reference \`//;s/' on page//" | sort -u)
[ -z "$UNDEF_REF" ] || { printf '\n  Undefined \\ref targets:\n'; printf '%s\n' "$UNDEF_REF" | sed 's/^/        /'; die "broken cross-references"; }
ok "every \\ref resolved"

case "$FLAT" in *"Citation(s) may have changed"*|*"Rerun to get"*)
  note "LaTeX asked for another pass; latexmk should have handled it — check the bibliography looks right" ;;
esac

# Markers the drafter leaves behind, in LaTeX comments so they never typeset.
GAPS=$(grep -c '\[GAP:' "$BASE.tex" 2>/dev/null || echo 0)
[ "$GAPS" -eq 0 ] && ok "no [GAP:] markers left" \
                  || note "$GAPS [GAP:] marker(s) still open — correct if the evidence is genuinely missing"

OVER=$(printf '%s' "$FLAT" | grep -o 'Overfull \\hbox' | wc -l | tr -d ' ')
[ "$OVER" -eq 0 ] || note "$OVER overfull hbox(es) — cosmetic, ignore until the final pass"

PAGES=$(pdfinfo "$BASE.pdf" 2>/dev/null | awk '/^Pages/{print $2}')
ok "${PAGES:-?} page(s)"

if [ "${2:-}" = "--look" ]; then
  command -v pdftoppm >/dev/null || die "pdftoppm not installed (brew install poppler)"
  rm -f "$BASE"-page-*.png
  pdftoppm -png -r 110 "$BASE.pdf" "$BASE-page"
  printf '\n'
  for f in "$BASE"-page-*.png; do printf '  %s\n' "$DIR/$f"; done
  printf '\n  Open these, or ask Claude to read them. A PDF that compiles is not\n'
  printf '  a PDF that is right: a table that runs off the page, a figure that\n'
  printf '  lost its caption and a bibliography in the wrong style all compile.\n'
fi
