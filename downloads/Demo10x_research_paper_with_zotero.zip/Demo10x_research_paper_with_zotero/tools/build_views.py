#!/usr/bin/env python3
"""Generate papers/_by-area.md from papers/_index.md (notes live in papers/notes/).

A pure function of the index: same input, same output, no judgement.
That is why it is a script and not an agent — a derivation that can be done
mechanically should never be done by something that can hallucinate a row.

    python3 tools/build_views.py            # write the view
    python3 tools/build_views.py --check    # exit 1 if the view is stale
"""
import sys, re, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INDEX = ROOT / "papers" / "_index.md"
VIEW = ROOT / "papers" / "_by-area.md"
NOTES = ROOT / "papers" / "notes"
RECENT_N = 15
AREAS = ["methods", "application", "evaluation", "background"]          # CLAUDE.md
COLS = ["note", "area", "item_key", "year", "claim", "tags"]


def rows(text):
    out, warn = [], []
    for ln in text.splitlines():
        s = ln.strip()
        if not (s.startswith("|") and s.endswith("|")):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) != len(COLS):
            continue
        if cells[0].lower() == "note" or set(cells[0]) <= set("-: "):
            continue                                    # header / separator
        r = dict(zip(COLS, cells))
        areas = [a.strip().lower() for a in re.split(r"[,;/]", r["area"]) if a.strip()]
        keep = []
        for a in areas:
            if a in AREAS:
                keep.append(a)
            else:
                warn.append((r["note"], a))
                keep.append("(unregistered)")      # never drop a paper from the view
        r["areas"] = sorted(set(keep)) or ["(unassigned)"]
        out.append(r)
    return out, warn


def added_dates(rs):
    """Read `added:` from each note's frontmatter. Also find orphans both ways."""
    on_disk = {f.stem for f in NOTES.glob("*.md")} if NOTES.is_dir() else set()
    indexed = {r["note"] for r in rs}
    for r in rs:
        f = NOTES / (r["note"] + ".md")
        r["added"] = ""
        if not f.is_file():
            continue
        for ln in f.read_text(encoding="utf-8", errors="replace").splitlines()[:20]:
            m = re.match(r"\s*added:\s*(\S+)", ln)
            if m:
                r["added"] = m.group(1).strip('"\'')
                break
    return sorted(indexed - on_disk), sorted(on_disk - indexed)


def render(rs, missing, unindexed):
    stamp = datetime.date.today().isoformat()
    L = [
        "# Papers by area",
        "",
        "> **GENERATED — do not edit.** `python3 tools/build_views.py`",
        f"> Built {stamp} from `_index.md`, which is the source of truth.",
        "",
        "A paper with two areas appears under **both**. That is the whole reason",
        "this is a view and `papers/notes/` is flat — a folder would force one.",
        "",
    ]
    dated = [r for r in rs if r["added"]]
    if dated:
        recent = sorted(dated, key=lambda r: r["added"], reverse=True)[:RECENT_N]
        L += [f"## Recently added  (last {len(recent)})", "",
              "| added | note | area | claim |", "|---|---|---|---|"]
        L += [f'| {r["added"]} | [[{r["note"]}]] | {r["area"]} | {r["claim"]} |' for r in recent]
        L += ["",
              "> Since your last commit, `git status --short papers/notes/` is exact.",
              "> This table is what survives the commit.", ""]

    for a in AREAS + ["(unregistered)", "(unassigned)"]:
        sel = sorted([r for r in rs if a in r["areas"]], key=lambda r: r["note"].lower())
        if not sel and a.startswith("("):
            continue
        L += [f"## {a}  ({len(sel)})", ""]
        if not sel:
            L += ["_nothing yet._", ""]
            continue
        L += ["| note | year | claim | tags |", "|---|---|---|---|"]
        L += [f'| [[{r["note"]}]] | {r["year"]} | {r["claim"]} | {r["tags"]} |' for r in sel]
        L += [""]
    multi = sorted(r["note"] for r in rs if len(r["areas"]) > 1)
    L += ["---", "", f"{len(rs)} papers. {len(multi)} in more than one area"
          + (": " + ", ".join(multi) if multi else "") + ".", ""]
    if missing:
        L += ["**Indexed but no note file** — " + ", ".join(missing), ""]
    if unindexed:
        L += ["**Note file but no index row** — " + ", ".join(unindexed), ""]
    return "\n".join(L)


def main():
    if not INDEX.exists():
        sys.exit(f"no {INDEX}")
    rs, warn = rows(INDEX.read_text(encoding="utf-8"))
    missing, unindexed = added_dates(rs)
    new = render(rs, missing, unindexed)
    for n in missing:
        print(f"WARN  {n}: in _index.md but no papers/notes/{n}.md", file=sys.stderr)
    for n in unindexed:
        print(f"WARN  papers/notes/{n}.md: no row in _index.md", file=sys.stderr)
    for note, a in warn:
        print(f"WARN  {note}: area '{a}' is not one of {AREAS}", file=sys.stderr)
    if "--check" in sys.argv:
        cur = VIEW.read_text(encoding="utf-8") if VIEW.exists() else ""
        strip = lambda t: "\n".join(l for l in t.splitlines() if not l.startswith("> Built "))
        if strip(cur) != strip(new):
            sys.exit("STALE: papers/_by-area.md does not match _index.md")
        print(f"ok — {len(rs)} papers, view is current")
        return
    VIEW.write_text(new, encoding="utf-8")
    print(f"wrote {VIEW.relative_to(ROOT)} — {len(rs)} papers"
          + (f", {len(warn)} area warning(s)" if warn else ""))


if __name__ == "__main__":
    main()
