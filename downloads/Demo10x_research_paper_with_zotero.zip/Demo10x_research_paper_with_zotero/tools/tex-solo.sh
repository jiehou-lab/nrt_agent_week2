#!/usr/bin/env bash
# Compile YOUR contribution on its own, before you push it to a shared project.
#
#   tools/tex-solo.sh groups/bob.tex
#
# WHY: in a drop-off workflow nobody compiles the shared document until the
# instructor assembles it. So a missing \end{itemize} in your file is not
# found until it breaks the assembly for everyone. This wraps your section in
# a minimal document with your own .bib and compiles just that — ten seconds,
# and it is the difference between contributing and contributing a problem.
set -uo pipefail
die(){ printf '\n  \033[31mFAIL\033[0m  %s\n' "$*" >&2; exit 1; }
ok(){  printf '  \033[32mok\033[0m    %s\n' "$*"; }

SRC=${1:-}; [ -n "$SRC" ] || die "usage: tools/tex-solo.sh groups/<yourname>.tex"
[ -f "$SRC" ] || die "no such file: $SRC"
HAVE_TEX=1
command -v latexmk >/dev/null || HAVE_TEX=0

ROOT=$(cd "$(dirname "$SRC")/.." && pwd); BASE=$(basename "${SRC%.tex}")
BIB="$(dirname "$SRC")/$BASE.bib"
for cmd in documentclass begin{document} end{document} bibliography usepackage; do
  if grep -q "\\\\$cmd" "$SRC"; then
    printf '\n  %s contains \\%s\n' "$SRC" "$cmd"
    printf '        A contributed section must be BODY TEXT ONLY — the shared\n'
    printf '        document supplies the preamble. Remove it.\n'
    die "not a section file"
  fi
done
ok "body text only — no preamble to collide with the shared document"

# ---------------------------------------------------------------------------
# No LaTeX installed? Most of what matters here is a TEXT property, not a
# compile. Check those anyway rather than refusing to help. This catches the
# defects that actually break somebody else's assembly; it cannot catch a
# subtly wrong macro, and it says so.
# ---------------------------------------------------------------------------
if [ $HAVE_TEX -eq 0 ]; then
  printf '  note  no latexmk here — running text checks only (see the end)\n'
  FAIL=0

  # unbalanced environments
  while read -r env; do
    [ -n "$env" ] || continue
    nb=$(grep -c "\\\\begin{$env}" "$SRC"); ne=$(grep -c "\\\\end{$env}" "$SRC")
    if [ "$nb" -ne "$ne" ]; then
      printf '\n  \\begin{%s} appears %s time(s), \\end{%s} %s time(s)\n' "$env" "$nb" "$env" "$ne"
      FAIL=1
    fi
  done < <(grep -oE '\\begin\{[A-Za-z*]+\}' "$SRC" | sed 's/.*{//;s/}//' | sort -u)
  [ $FAIL -eq 0 ] && ok "every \\begin has a matching \\end"

  # braces
  ob=$(tr -cd '{' < "$SRC" | wc -c | tr -d ' '); cb=$(tr -cd '}' < "$SRC" | wc -c | tr -d ' ')
  if [ "$ob" -ne "$cb" ]; then
    printf '\n  %s open braces, %s close braces — something is unclosed\n' "$ob" "$cb"; FAIL=1
  else ok "braces balance ($ob pairs)"; fi

  # cite keys against your own .bib
  if [ -f "$BIB" ]; then
    KEYS=$(grep -oE '^@[A-Za-z]+\{[^,]+' "$BIB" | sed 's/^@[A-Za-z]*{//' | sort -u)
  else KEYS=""; fi
  CITED=$(grep -oE '\\cite[a-z]*(\[[^]]*\])*\{[^}]*\}' "$SRC" \
          | sed 's/.*{//;s/}//' | tr ',' '\n' | sed 's/ //g' | sort -u | grep . || true)
  MISSING=$(comm -23 <(printf '%s\n' "$CITED") <(printf '%s\n' "$KEYS") | grep . || true)
  if [ -n "$MISSING" ]; then
    printf '\n  Cited but not in %s:\n' "$BIB"
    printf '%s\n' "$MISSING" | sed 's/^/        /'
    printf '\n        LaTeX does NOT call this an error — it prints "?" and exits 0.\n'
    FAIL=1
  elif [ -n "$CITED" ]; then
    ok "all $(printf '%s\n' "$CITED" | grep -c .) cited key(s) are in your .bib"
  fi

  [ $FAIL -eq 0 ] || die "fix these before pushing"
  printf '\n  \033[33mText checks passed.\033[0m These catch the defects that break an\n'
  printf '  assembly — unbalanced environments, stray preamble, missing cite keys.\n'
  printf '  They cannot prove it typesets. Install LaTeX for that, or let the\n'
  printf '  instructor'"'"'s assembly be the compile. Safe to push.\n'
  exit 0
fi

WORK=$(mktemp -d); trap 'rm -rf "$WORK"' EXIT
cp "$SRC" "$WORK/body.tex"
[ -f "$BIB" ] && cp "$BIB" "$WORK/refs.bib" || : > "$WORK/refs.bib"

{
  printf '\\documentclass[11pt]{article}\n'
  printf '\\usepackage[margin=1in]{geometry}\n\\usepackage[numbers]{natbib}\n'
  printf '\\usepackage{graphicx}\\usepackage{amsmath}\n'
  printf '\\bibliographystyle{unsrtnat}\n\\begin{document}\n'
  printf '\\input{body}\n\\bibliography{refs}\n\\end{document}\n'
} > "$WORK/solo.tex"

( cd "$WORK" && latexmk -pdf -interaction=nonstopmode -halt-on-error solo.tex >/dev/null 2>&1 )
STATUS=$?
LOG="$WORK/solo.log"
[ -f "$LOG" ] || die "latexmk produced no log"
FLAT=$(tr -d '\r' < "$LOG" | tr '\n' ' ' | tr -s ' ')

if [ $STATUS -ne 0 ]; then
  printf '\n  Your LaTeX does not compile:\n'
  grep -m2 -A2 '^!' "$LOG" | sed 's/^/        /'
  grep -m1 -o 'l\.[0-9]* .*' "$LOG" | sed 's/^/        near /'
  die "fix this before pushing — otherwise it breaks the assembly for everyone"
fi
ok "$SRC compiles on its own"

UNDEF=$(printf '%s' "$FLAT" | grep -o "Citation \`[^']*' on page" | sed "s/Citation \`//;s/' on page//" | sort -u)
if [ -n "$UNDEF" ]; then
  printf '\n  Cited but not in %s:\n' "$BIB"
  printf '%s\n' "$UNDEF" | sed 's/^/        /'
  printf '\n        latexmk exits 0 on this and renders "?" — it is not an error\n'
  printf '        to LaTeX, only to your reader. Add the entry, or pin the key\n'
  printf '        in Zotero (item > Extra > "Citation Key: ...").\n'
  die "undefined citations"
fi
ok "every \\cite resolves against your own .bib"

printf '\n  Safe to push.\n'
