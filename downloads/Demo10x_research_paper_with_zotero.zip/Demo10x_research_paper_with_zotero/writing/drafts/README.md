# Drafts

Agents **read** here and **do not rewrite prose**. One job only:

    Use the citecheck subagent on writing/drafts/<file>.

For every claim it reports: the source, whether that source is in the library,
whether the source says it, whether the number is right, and **whether the
strength matches** — a source saying "associated with" does not support a draft
saying "causes".

Verdicts are `confirmed`, `contradicted`, `overstated`, `cannot verify`.

`cannot verify` is an honest answer and the one to read most carefully.
