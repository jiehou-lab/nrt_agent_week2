# My writing conventions

> **I write this file. No agent writes it.** It is denied in
> `.claude/settings.json`.
>
> Twenty minutes, once. Without it, anything written "in my voice" is generic
> prose, which is the worst output — fluent, plausible, and not mine.

## Venues I write for

| Venue | Audience | What counts as evidence |
|---|---|---|
| | | |

## Rules I actually follow

- Hedging: 
- Tense in methods: 
- First person: we / passive / 
- Numbers: significant figures, units, how I report uncertainty
- Citation density: 
- What I never do: 

## Three paragraphs of mine that are good

Paste them. Say in one line why each one works. This does more than any amount
of description.

### 1.

> 

Why: 

### 2.

> 

Why: 

### 3.

> 

Why: 
