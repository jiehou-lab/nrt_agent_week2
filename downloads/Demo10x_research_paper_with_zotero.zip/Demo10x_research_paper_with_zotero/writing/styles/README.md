# CSL styles

`pandoc --csl=writing/styles/<name>.csl`. The same file works in Zotero and
in pandoc, so one download covers both routes.

## Getting one

Two sources, same files. Both give you raw XML — `curl -O` from your
Terminal:

    cd ~/research/writing/styles

    # Zotero's repository, by style slug
    curl -O https://www.zotero.org/styles/journal-of-thrombosis-and-haemostasis
    mv journal-of-thrombosis-and-haemostasis journal-of-thrombosis-and-haemostasis.csl

    # or GitHub, which already has the .csl extension
    curl -O https://raw.githubusercontent.com/citation-style-language/styles/master/vancouver.csl

The Zotero URL serves the file without an extension, hence the `mv`.

**Do not just click the style on <https://www.zotero.org/styles> in a
browser** — with Zotero installed, a click *installs the style into Zotero*
and you never get a file. Right-click → *Save Link As* if you want it that
way.

Around 1,900 styles exist. If your journal is not there, `vancouver.csl` is
the right fallback for anything biomedical, and `apa.csl` for anything else.
Pandoc's built-in default is Chicago author-date, which is wrong for every
journal you submit to — so always pass `--csl`.

## Worth having before you need them

| file | for |
|---|---|
| `journal-of-thrombosis-and-haemostasis.csl` | warfarin manuscripts |
| `vancouver.csl` | any biomedical fallback |

## Check it loaded

    tools/render.sh docx writing/drafts/<name>.md

It prints `ok  style writing/styles/<name>.csl`, or warns that it found none
and is falling back to Chicago.
