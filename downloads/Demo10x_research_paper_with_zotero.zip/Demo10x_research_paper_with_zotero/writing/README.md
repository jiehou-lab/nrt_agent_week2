# writing/ — how a draft gets from notes to a formatted document

`STYLE.md` is **voice** and it is mine. This file is **mechanics** and agents
read it.

    writing/
    ├── STYLE.md      MINE. voice, venues, sample paragraphs. denied to agents.
    ├── README.md     this file. the pipeline and the marker convention.
    └── drafts/       where drafter writes. markdown only.

## The pipeline

    1  Use the drafter subagent: <the section you want>
                                        → writing/drafts/<name>.md
    2  Use the cite skill: <any sentence you are unsure of>
    3  Use the citecheck subagent on writing/drafts/<name>.md
    4  Use the prose subagent on writing/drafts/<name>.md
    5  Use the manuscript-revision skill on writing/drafts/<name>.md
    6  render — see below

**Markdown is the source of truth at every step.** It is what git diffs, what
`citecheck` reads, and what survives a change of journal. `.docx` and `.rtf`
are outputs, regenerated from it.

### Why four separate reviewers

Each one can only see what it is built to see, and none of them can quietly
fix what it found:

| | opens the PDF | has Write | catches |
|---|---|---|---|
| `citecheck` | **yes** | no | is the claim in the source |
| `prose` | no | **no tools at all but Read** | strength, filler, unsourced sentences |
| `manuscript-revision` | no | n/a (skill) | figures, abbreviations, arithmetic |
| `drafter` | no | **yes**, `drafts/` only | writing it in the first place |

A single "review my draft" pass would pick one lens and miss the rest.

## Source tiers — the thing that makes open-ended drafting safe

`drafter` is **not bound to `papers/notes/`.** It will write from a note, a
PDF in the library with no note, something it found online, or nothing. That
is deliberate — a summary, a literature review and a proposal all need
different sources, and refusing the open ones just means not using the agent.

What makes it safe is that **every claim declares its tier**:

| tier | marker | may quote a number? |
|---|---|---|
| **note** | `{Choi, 2023}` | yes — `## Evidence` records it with its table |
| **library** | `{Saon, 2022 ·unread}` | yes, **naming the table**, flagged as unchecked by me |
| **web** | `[WEB:1]` | **no** — attribute it: "a 2024 preprint reports…" |
| **none** | `[GAP: …]` | correct behaviour, not a failure |

Every draft ends with a `<!-- SOURCES -->` block resolving each marker, and
`drafter` reports the tier counts. **A high web count is not a failure, it is
the finding** — it says this draft rests on things you have not read, which
is what you need to know before sending it anywhere. `prose` independently
checks that the tiers are honest.

## Citation markers

**The agent never writes a formatted reference.** It writes a marker that
names the source unambiguously; Zotero or pandoc formats it.

Default is **RTF Scan** style, because it needs no cite-key pinning:

    {Choi, 2023}            {Choi, 2023, 22461}       {Jones, 2005; Smith, 2009}

Every draft ends with a resolution block so a marker traces to an exact item:

    <!-- SOURCES
    {Choi, 2023} → papers/notes/Choi2023-warfarin-discharge-dose.md
                    item_key RDEWFSFF · doi 10.1160/TH11-06-0388
    -->

Switch to pandoc style — `[@choiMachineLearningModels2023]` — only if
you are rendering with `--citeproc`, **and only after pinning cite keys** in
Zotero's `Extra` field (`Citation Key: ...`). Unpinned, Better BibTeX
regenerates them when metadata changes and the citation silently stops
resolving.

## Rendering

Three routes. **Start with the third** — it is the one that gives you a
document Zotero can actually manage.

| | output | Zotero manages it? |
|---|---|---|
| `tools/render.sh live` | `.docx` with **live field codes** | **yes** — restyle, Refresh, co-author revisions |
| `tools/render.sh rtf` → RTF Scan | `.rtf`, formatted | no. static text. |
| `tools/render.sh docx` | `.docx` via `--citeproc` | no. static text. |

### Live citations, generated — no clicking

Better BibTeX documents a pandoc filter that writes **real Zotero field
codes** into a `.docx`. You do not have to insert citations by hand.

    tools/render.sh live writing/drafts/<name>.md
    tools/render.sh live writing/tex/<name>.tex

Markdown or LaTeX; the filter does not care which. It acts on pandoc's
`Cite` nodes and branches on the *output* format, and pandoc's LaTeX reader
produces the same nodes from `\citep{k}` as its markdown reader does from
`[@k]`. `\input{}` is followed, so an assembled `main.tex` converts in one
pass. Two LaTeX-only quirks: `\ref` resolves to real numbers but `\eqref`
does not, and before you Refresh the placeholders are empty rather than
showing the key.

#### One-time setup

Two downloads, both into `tools/`, both gitignored. Do them once per machine.

**1. The filter.** `render.sh` prints this exact line if it is missing:

    curl -o tools/zotero.lua \
      https://retorque.re/zotero-better-bibtex/exporting/zotero.lua

**2. A pandoc that can do the job.** Not Homebrew's — see below.

    curl -s https://api.github.com/repos/jgm/pandoc/releases/tags/3.8 \
      | grep -o '"browser_download_url": *"[^"]*"' | grep -i macOS.zip

    # arm64 on Apple Silicon, x86_64 on Intel
    unzip pandoc-3.8-<arch>-macOS.zip -d /tmp/p
    mkdir -p tools/pandoc && mv /tmp/p/*/[bs]* tools/pandoc/
    echo tools/pandoc/bin/pandoc > tools/pandoc.path

That is all. **Do not set `PANDOC=` in day-to-day use.** The script searches
`$PANDOC`, then `tools/pandoc.path`, then `tools/pandoc/bin`, then
`~/bin/pandoc-http/bin`, then Homebrew, then `PATH` — and in `live` mode it
*probes* each one and takes the first that is 2.16.2+ **and** has HTTP. An
unsuitable pandoc earlier in the list is skipped, not fatal. If you do pass
`PANDOC=`, it goes **before** the command, not after:

    PANDOC=/some/other/pandoc tools/render.sh live <draft>.md    # yes
    tools/render.sh live PANDOC=... <draft>.md                   # no

`tools/pandoc/` and `tools/pandoc.path` are gitignored: a 114 MB binary and a
path that is true on one machine do not belong in the repo. A fresh clone
gets the setup instructions from `render.sh`'s own error message.

#### Why not just `brew install pandoc`

The filter talks to Zotero over `127.0.0.1:23119`, so a pandoc compiled
without HTTP cannot reach it:

    Error running filter 'tools/zotero.lua':
    pandoc was compiled without HTTP support

pandoc 3.9 added an `http` cabal flag so pandoc can be built without network
support, for WASM targets
([#10980](https://github.com/jgm/pandoc/issues/10980)). Some packagers build
it off. Confirmed off in **Homebrew's pandoc 3.12 on macOS** and in
**conda's**; a Linux pandoc 3.1.3 has it. There is no `pandoc@3.8` formula,
and `brew extract` would compile Haskell from source — hours. Hence the zip.

**Any pandoc from 2.16.2 to 3.8 is guaranteed to work**: the flag did not
exist before 3.9, so HTTP is unconditional in those. Worth one try first: the
official `.pkg` of the current release, which may be built `+http`.

`pandoc --version` does **not** tell you — its `Features:` line lists
`server` and `lua`, never `http`. `render.sh` probes for you; by hand:

    cat > /tmp/httpcheck.lua <<'LUA'
    function Pandoc(d)
      local ok, e = pcall(pandoc.mediabag.fetch, 'http://127.0.0.1:1/x')
      if not ok then io.stderr:write(tostring(e)) end
      return d
    end
    LUA

    echo x | /path/to/pandoc --lua-filter=/tmp/httpcheck.lua -t plain

The filter has to be a real file; `--lua-filter=/dev/stdin` with a heredoc
fails because the pipe and the heredoc both claim stdin. The `io.stderr:write`
line is not optional either — `pcall` swallows the error, and without it the
probe passes a binary that has no HTTP at all.

`HttpExceptionRequest` = has HTTP. `without HTTP support` = does not.

**If nothing on your machine has HTTP, the live route is closed** — the
filter has no offline mode. Use `rtf`, which needs no network.

#### The other requirements

- **`[@citekey]` markers.** Pin keys in Zotero's `Extra` if you will
  re-render; after the handoff the cite key no longer matters, because
  field codes carry the item's own identity.
- **Zotero running, with Better BibTeX installed**, at the moment you run it.
  Check by hand:

      curl -s http://127.0.0.1:23119/connector/ping            # Zotero up?
      curl -s 'http://127.0.0.1:23119/better-bibtex/cayw?probe=1'   # -> ready

  The second is BBT's documented probe; it returns `ready` and does **not**
  pop up the citation picker. `render.sh live` runs both before invoking the
  filter, so a closed Zotero and a missing BBT give different messages.

#### Then in Word — three steps, in this order

1. **Zotero tab → Document Preferences → OK.** Picks the style.
2. **Cursor under the `References` heading → Add/Edit Bibliography.**
3. **Refresh.**

**Step 2 is not optional, and nothing warns you.** The filter writes
*citation* fields only — `ADDIN ZOTERO_ITEM`, which is why each citation
shows the grey Zotero shading. A bibliography is a *different* field,
`ADDIN ZOTERO_BIBL`, and only the Word plugin can insert it. Unpack the
`.docx` and you can see it is absent:

    unzip -p <file>.docx word/document.xml | grep -o 'ADDIN ZOTERO_[A-Z_]*' | sort | uniq -c
       2 ADDIN ZOTERO_ITEM          # citations: live
                                    # ZOTERO_BIBL: not there

So Refresh succeeds, reports nothing, and no reference list appears. That
reads like a failure and is not — there is simply nothing to build a list
into yet. Do it **once per document**, not per edit; after that Refresh
maintains it.

The `## References` heading in the draft exists to give you somewhere to put
the cursor. Keep it. It is a plain heading, not a placeholder — do **not**
write `{Bibliography}` in a draft bound for this route; that marker belongs
to the `rtf` route and will come through as literal text here.

Order matters elsewhere too: Document Preferences *after* Refresh gives you
a confirmation popup for every single citation. And if Word calls the file
corrupt on first open, re-run the exact same command; that is a documented
quirk and it fixes it.

Source: <https://retorque.re/zotero-better-bibtex/exporting/pandoc/>

**Prove the handoff once**, on a two-citation paragraph, before trusting it
with a manuscript. In Word, after the three steps above (Document
Preferences → Add/Edit Bibliography → Refresh):

1. *Add/Edit Citation* — insert a third citation. Does the bibliography grow?
2. Delete one of the agent-generated citations, Refresh. Does it shrink, and
   does the numbering close up?
3. Change style in Document Preferences. Do **all** citations restyle?

**2 and 3 are the test.** They are what separates a document Zotero owns
from one that is merely formatted. If they pass, markdown can stay your
drafting format permanently.



### Static, via citeproc — when you want a finished artifact

    tools/render.sh docx writing/drafts/<name>.md

It refuses if pandoc is older than 2.11, if there is no `library.bib`, or if
the draft uses `{Author, Year}` markers rather than `[@citekey]` — each of
which otherwise fails with a message that points somewhere else.

**This route does not remove Zotero from the loop.** It replaces the
*formatting* step only. Zotero still produces `library.bib`, fetches
authoritative metadata when you add a paper by DOI, holds the PDFs that
`citecheck` opens, and owns the `item_key` every note joins on. And the
route has a **manual Zotero step as a prerequisite**: Better BibTeX cite
keys regenerate when metadata changes, so each one must be pinned in the
item's `Extra` field (`Citation Key: choi2023warfarin`) or the citation
silently stops resolving.

Styles: see `writing/styles/README.md`.

Verified to produce in-text citations, page locators and a built
bibliography, into `.docx`, `.rtf` or `.pdf`. Needs `Bash(pandoc:*)` allowed,
pinned cite keys, and a CSL file from <https://www.zotero.org/styles>.

**Check your pandoc version first — this is the step that will fail:**

    pandoc --version | head -1

`--citeproc` arrived in **pandoc 2.11**. On anything older the flag does not
exist and you get `Unknown option --citeproc`, which looks like a typo and
is not:

| version | what to run |
|---|---|
| **2.11 or newer** | `--citeproc` (above) |
| 2.9 / 2.10 | `--filter pandoc-citeproc`, and that separate binary must be installed |
| older | upgrade. `brew install pandoc` |

**What you get is a finished document.** Static text. Zotero does not know
about it and cannot restyle it later.

### Zotero RTF Scan — three clicks, and the result is STATIC

    tools/render.sh rtf writing/drafts/<name>.md

**Use the script, not a raw pandoc command.** The flags live in exactly one
place and the output is verified before you hand it to Zotero:

      ok    <name>.rtf has a valid {\rtf1 header
      ok    all 3 marker(s) survived
      ok    {Bibliography} placeholder present

That first check exists because the `-s` flag once went missing from this
file while the guide still had it. Without `-s` pandoc emits a *fragment*
with no `{\rtf1` header; **Zotero scans it happily**, because RTF Scan only
looks for `{Author, Year}` patterns; and Word refuses the result three steps
later with "Select the encoding that makes your document readable". The
script fails at the point of the mistake instead.

**RTF Scan is a one-shot formatter, not a handoff to Zotero.** The output
has formatted citations and a bibliography as **plain text** — no field
codes. Open it in Word, press *Refresh* on the Zotero tab, and you get
*"You must insert a citation before performing this operation."* That is
correct behaviour, not a fault.

So: **you cannot restyle it, and you cannot Refresh it.** To change style,
re-scan the original marked-up `.rtf` with a different style — the markdown
is the source, so this costs a minute. To keep inserting citations in Word,
see the manuscript route below instead; mixing a live Add/Edit Citation into
a statically formatted document gives you a bibliography containing only the
new one.

Then **Zotero → Tools → RTF Scan**. Four screens: *Input File* (your
`.rtf`), *Output File* (**a different name** — it will not overwrite, and
you want the unformatted one kept), *Verify Cited Items* (click the icon
beside anything uncertain; an unmatched marker usually means the paper is
not in your library, which is worth knowing), then the citation style.

Output is `.rtf`. For `.docx`, open it in Word → Save As. Footnote styles
only render properly once a word processor has opened it.

**An agent cannot do the Zotero step** — it is a GUI menu, and Claude Code
has no GUI automation. Steps before and after it are agent-runnable.

Put a literal `{Bibliography}` where you want the bibliography; otherwise it
goes at the end.

pandoc escapes braces as `\{...\}` in RTF. That is the **correct** encoding
of a literal brace, and a conformant reader recovers `{Choi, 2023}`.
Confirmed by round-tripping the file.

`tools/render.sh` checks this for you. If you do it by hand, **flatten the
newlines first and grep the raw RTF**, not a re-read of it:

    tr '\n' ' ' < <name>.rtf | grep -o '\\{[^\\]*\\}'

Two traps, both hit while building this. A plain `grep` reports markers
missing when line wrapping split them across two lines — the same false
negative `pdftotext` produced earlier in this project. And pandoc's RTF
*reader* only exists in 3.x, so verifying by reading the file back silently
returns nothing on pandoc 2.x.

### The real manuscript

Use **`tools/render.sh live`** to produce the first `.docx` with live
citations already in it. Inserting forty citations by hand is not the price
of a Zotero-managed document — that was wrong in an earlier version of this
file.

Hand-insertion with *Add/Edit Citation* is still the fallback when the live
route cannot run: no Better BibTeX, pandoc too old, or Zotero closed.

**After the document exists, never let an agent edit it.** Zotero citations
are field codes; regenerating the `.docx` destroys them and the bibliography
breaks **silently** — you find out when a reviewer says the references do
not match. Once a manuscript is live in Word, the markdown stops being the
source of truth for it and the Word file takes over.

## One agent, many shapes

`drafter` holds the **discipline**: tiers, markers, `[GAP:]`, strength,
markdown-only. Skills hold the **shape**:

    Use the lit-review skill…    organised by disagreement, not paper by paper
    Use the proposal skill…      aims page first, independent aims, no invented numbers

Why not one agent per job: the discipline would be copied into each and then
drift, and they would all need the same tools anyway. Why not one giant
skill: idle skills are nearly free — only the one-line description sits in
context until something invokes it — so ten shapes cost about what one costs.

**If a skill's instructions conflict with the tier rule, the tier rule wins**
and `drafter` says which instruction it declined. That is what lets you
install a shape skill you have not fully read.

### Adding your own shape

`.claude/skills/<name>/SKILL.md`, frontmatter `name:` and `description:`.
Write **structure, not discipline** — the failure the shape prevents, the
section order, the rules specific to that form, and a word budget. Leave
sourcing, markers and gaps to `drafter`.

Candidates worth writing when you next need them: `rebuttal` (reviewer
response letters), `abstract`, `cover-letter`, `data-availability`.

## Adding a better writing skill

`EXTENDING.md` has the rules. The short version: an external drafting or
proposal skill supplies the **prose**; this workspace keeps the **contract** —
markers not formatted references, numbers from `## Evidence`, `[GAP:]` rather
than fluent filler, and `drafts/` as the only writable path.

---

## After the handoff: refining a Word document Zotero owns

**There is no round trip.** Once the `.docx` has live field codes, markdown
stops being the source of truth. Measured on this project's own draft:

    pandoc live.docx -o back.md && pandoc back.md -o again.docx
    unzip -p again.docx word/document.xml | grep -c 'ADDIN ZOTERO'
    0

Citations come back as the plain text `(Choi et al., 2023)`, the
bibliography as an ordinary paragraph, and Zotero no longer owns any of it.
Refresh does nothing, restyling is gone, co-authors inherit dead text. So
once you are in Word, **never regenerate the `.docx` from its markdown** and
never pass it through pandoc.

What still works is editing the `.docx` in place, carefully:

    python3 tools/docx_text.py  writing/drafts/<name>.docx          # read
    python3 tools/docx_suggest.py writing/drafts/<name>.docx sug.json

`docx_text.py` prints numbered paragraphs with citations folded to
`«citation:N»` and the reference list to `«bibliography:N»`, plus an audit:
live citation count, whether a bibliography exists at all, open `[GAP:]` and
`[WEB:n]` markers, and any `[@citekey]` that never became a field.

`docx_suggest.py` applies a JSON list of `{find, replace, why}` as **tracked
changes** into `<name>-suggested.docx` — the original is never written. You
accept or reject each one in Word's Review tab, and the citations and
bibliography stay live throughout.

Ask for it in conversation; the `docx-review` skill carries the procedure.

### The three rules, each from a failure

1. **Never edit a run that is part of a field.** A regex replace that spanned
   a citation wrapped `ADDIN ZOTERO_ITEM` inside a `<w:del>` and duplicated
   the field. `docx_suggest.py` refuses any match touching a field run.
2. **Never run the docx skill's `merge_runs.py` on a live document.** It
   merges prose runs *into* field runs — verified, 0 mixed runs before and 3
   after — and then nothing near a citation can be edited safely.
3. **Verify after writing, not only before.** Field counts and `fldChar`
   balance are re-checked against the input and the output is deleted if they
   moved, so a bad run leaves you with the original and an error.

Agents cannot write a `.docx` or `.rtf` under `writing/` at all; the deny
list in `.claude/settings.json` removes the capability rather than asking for
restraint. `docx_suggest.py` is the only route, and it writes a new file.

### Figures and tables

`docx_text.py` renders tables as pipe tables in body order, so an agent sees
rows and columns rather than sixteen stray one-word paragraphs, and marks
figures as `«figure:N word/media/imageN.png — alt text»`.

**To review a figure, look at it:**

    python3 tools/docx_text.py <file>.docx --media /tmp/figs

That writes the images out; then Read them. Reading the caption is not
reviewing the figure. The caption is the author's claim *about* the figure;
the axes are where it goes wrong — units that disagree with the text, a
highlighted bar with no interval behind it, an unmentioned log scale.

Figures cannot be edited from here, and should not be: say what is wrong and
redraw it from whatever produced it. Table *text* is editable —
`docx_suggest.py` reaches table cells, which is where the numbers worth
checking usually live.

### What a round trip actually costs

Two ways of "converting to XML and back", measured on a document with two
figures, one table and three Zotero fields:

| | citations | images | tables |
|---|---|---|---|
| `unzip` → edit → `zip` | 3 → 3 | 2 → 2 | 1 → 1 |
| `pandoc` → `.md` → `.docx` | 3 → **0** | 2 → **0** | 1 → 1 |

Editing the archive is **lossless** — every part not touched comes back
byte-identical, images included. That is what these tools do, via
`python-docx`, which rewrites the package properly rather than re-zipping a
folder (hand-zipping risks `[Content_Types].xml` landing in the wrong place).

pandoc loses the citations *and* every image; only the tables survive. It is
a converter, not an editor, and it only ever claimed to be the former.

### Checking a file that came back from somewhere else

Cowork, a co-author, or any tool that rewrites the XML can hand you a `.docx`
that opens fine, satisfies Word, and has a damaged citation field. Nothing
announces it; you find out at proof stage when one reference no longer
matches its citation.

    python3 tools/docx_text.py <came-back>.docx --against <what-you-sent>.docx

                       sent   back
      live citations      2      2
      bibliography        1      1
      field begin         3      3
      instrText in del    0      1   <-- CHANGED
      embedded images     2      2
      tables              1      1

Note what that example shows: citation and bibliography counts are
*identical*. Only `instrText in del` reveals the damage — a citation field
swallowed into a deletion. Counting citations is not enough, which is why
this compares six things and refuses to pass on any of them moving.

Thirty seconds, and worth it on anything you did not generate here.

### Claude cannot insert a citation

A `ZOTERO_ITEM` field embeds Zotero's internal item JSON and a citationID.
Forging one risks corrupting the document's link to your library, so the tool
will not. A suggestion can propose `[CITE: choiMachineLearningModels2023]`
and name the paper; you insert it in Word with **Add/Edit Citation**, which is
one click and always correct.

### Where to spend your effort

Markdown is for drafting — text fluid, citations just markers, git tracking
every change, agents free to rewrite whole paragraphs. Word is for the
endgame — co-authors, journal styles, Zotero managing the bibliography.

**The handoff is one-way, so do it late.** Every revision you make in
markdown is cheap and every one you make afterwards is careful. Render to
`live` when the argument is settled and you need Zotero, not before.
