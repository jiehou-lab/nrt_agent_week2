# The LaTeX route

If you write in LaTeX or Overleaf, **this is the simpler half of the
workspace**, not the harder one. Everything up to the draft is identical —
same `papers/`, same notes, same `librarian`, same `citecheck`. Only the
last step changes, and it changes in your favour.

## Why it is easier than Word

| | Word route | LaTeX route |
|---|---|---|
| source of truth | flips to the `.docx` at handoff | the `.tex`, always |
| can an agent edit the final form? | only as tracked changes | **yes, directly** |
| round trip | **impossible** — pandoc destroys field codes | it is plain text |
| library staleness | manual re-export, easy to forget | **auto-export keeps it in sync** |
| diffs | binary | readable |
| Claude can see the result | needs LibreOffice | `tools/tex.sh --look` |

**There is no one-way door here.** The whole "markdown drafts, then a Word
endgame, and never render over it" section of `writing/README.md` does not
apply. Write `.tex` from the first line and keep editing it forever.

## The loop, once it is set up

    git pull                                    FIRST, every session
    claude                                      from inside the clone
    tools/tex.sh <file>.tex --look              compile, check, render
    git add -A && git commit -m "..." && git push

**`git pull` first is not etiquette.** A co-author editing in the browser
makes Overleaf reject your push, and untangling that mid-session is the only
part of this workflow that genuinely wastes time.

### The mistake everyone makes once

    $ git push
    fatal: No configured push destination.

You are one folder too high. `writing/tex/` belongs to **your research
repo**, which has no remote; the Overleaf clone is the folder *inside* it.
Two repos nested, and git silently acts on whichever encloses your current
directory. `cd` into the clone — and when unsure, `git remote -v`: an
Overleaf URL means you are in the right place.

### Do not commit the PDF

Overleaf compiles it. A committed `main.pdf` is a stale binary that conflicts
on every pull. The shipped `.gitignore` covers it with `*.aux`, `*.bbl`,
`*.log` and the page PNGs.

## Setup

**1. Export a `.bib`, and tick Keep updated.** In Zotero: right-click
**My Library** → *Export Library* → format **Better BibTeX** → tick
**`Keep updated`**. Save as `papers/library/library.bib`.

> That tick is the whole difference. Better BibTeX re-exports the file
> whenever the library changes, so the `.bib` cannot drift from Zotero. The
> CSV route has no equivalent and a forgotten re-export is its main failure
> mode.

**2. Pin your cite keys.** Better BibTeX *regenerates* a key when you fix an
item's metadata, which silently breaks every `\cite` already written. Pin the
ones you cite: the Zotero item → **Extra** field → `Citation Key: smith2024`.

**3. A TeX engine**, if you want to compile locally:

    brew install --cask basictex      # ~100 MB, enough for this
    # or Tectonic — one binary, fetches packages on demand
    # MacTeX is ~5 GB and you do not need it

`tools/doctor.sh` reports what you have.

## Writing and compiling

    tools/tex.sh writing/tex/paper.tex            compile and check
    tools/tex.sh writing/tex/paper.tex --look     also render pages to PNG

The `--look` mode writes one PNG per page and prints the paths, so you can
ask Claude to **read the rendered pages**. A PDF that compiles is not a PDF
that is right: a table running off the page, a figure that lost its caption,
and a bibliography in the wrong style all compile cleanly.

### The check that matters

**`latexmk` exits 0 on an undefined citation.** Verified here: a
one-character typo in a cite key produced a 68 KB PDF, exit status 0, a `?`
where the citation should be, and that reference missing from the
bibliography. Nothing failed. You would find it at proof stage.

`tools/tex.sh` treats that as fatal:

    ok    compiled — paper.pdf

    Undefined citation keys — the PDF built anyway and renders "?":
          guoPredictionModelStabel2025

    FAIL  undefined citations. latexmk exited 0; this script does not.

It also fails on undefined `\ref` targets, and reports open `[GAP:]` markers
and overfull boxes without failing on them.

> **A note on reading the log yourself:** LaTeX wraps warnings across lines
> *mid-word* — `undef` / `ined` — so `grep "undefined" paper.log` finds
> nothing on a file that has them. `tex.sh` flattens the log first. This
> exact trap cost an hour in three different tools on this project.

## Citations in the draft

`cite` and `drafter` emit `\cite{key}` for this route. Tiers still apply —
a `[GAP:]` goes in a LaTeX comment so it never typesets:

    Models report strong pooled accuracy \cite{choiMachineLearningModels2023}.
    % [GAP: error stratified by achieved INR band]

`citecheck` is unchanged: it opens the PDFs in your Zotero storage and checks
each claim against the source. It does not care what markup surrounds it.

## Overleaf

**Overleaf's Git integration is a premium feature** — it is not on the free
plan, though many universities have an institutional licence, so check yours
before assuming.

**Every paid Overleaf plan includes Git** — only the Free plan does not. If
your university licenses Overleaf (MSU does, via SSO at `overleaf.com/edu/msu`),
you have it at no personal cost. Check in 30 seconds: open any project →
**Menu → Sync**. If *Git* is listed, you are set.

### Authenticating without leaking the token

Overleaf uses a **token**, never your password, and SSO does not change that.
Account Settings → *Git integration* → generate one. Up to 10 tokens, each
expires after a year.

    git clone https://git.overleaf.com/<project-id> writing/tex/<name>
    # username: git
    # password: <your Overleaf token>

**Do not put the token in the clone URL.** `https://git:TOKEN@git.overleaf.com/...`
works, and writes your token in plaintext into `.git/config`, where it will be
read by anything with access to the repo — including an agent. Let the keychain
hold it instead:

    git config --global credential.helper osxkeychain   # macOS

Then enter the token once at the prompt and it is stored outside the repo.
`.gitignore` here already excludes `.git-credentials`, and the deny list blocks
reading it, but the keychain is better than both: there is no file to leak.

Then:

    cd writing/tex/<name> && claude

Claude Code works directly in the clone, you `git push`, and Overleaf shows the
result. Overleaf compiles for you, so a local TeX is optional — though
`tools/tex.sh` locally still gives you the undefined-citation check, which
**Overleaf's compiler will not fail on either**.

### Overleaf's Zotero integration vs. Better BibTeX — pick one

Overleaf's sidebar offers Zotero, Mendeley and ReadCube. **Claude Code cannot
use those** — they are browser-side buttons. But the `.bib` they create lives
*in the project*, so it arrives in your clone on `git pull`. Two routes to the
same place:

| | Overleaf's Zotero integration | Better BibTeX auto-export |
|---|---|---|
| where the `.bib` is made | in Overleaf, in the browser | on your disk, by Zotero |
| how it refreshes | **manual Refresh button** (linked `.bib`) | **automatic** on every library change |
| cite keys | Zotero's own | **yours, pinnable** via `Extra` |
| scope | whole library, flat — no choosing a collection | whatever you export |
| extra account link | yes, Overleaf ↔ Zotero | no |
| usable before you push | no | **yes** — `tex.sh` and `citecheck` run locally |

**Prefer Better BibTeX** for this workspace. The deciding reason is cite-key
stability: BBT lets you *pin* a key in the item's `Extra` field, and nothing
regenerates it afterwards. Overleaf's import uses Zotero's own key generation,
so a key can shift under you when you fix an author's name — and an undefined
citation compiles to `?` without failing.

The one thing Overleaf's integration does better: co-authors get the
bibliography without waiting for you to push.

**Do not run both.** Two `.bib` files in one project, with different keys for
the same papers, is a failure that looks like a typo for a long time. If you
inherit a project that already has an Overleaf-managed `.bib`, either keep
using it and skip the BBT export, or remove it in Overleaf first — its file is
read-only there, so a `git push` is not the way to replace it.

**Without Git access**, do not fight it. Write locally, compile locally, and
move files at the boundaries: download the project as a ZIP to start, upload
the changed `.tex` and `.bib` when you are done. Overleaf's Dropbox and
GitHub sync are premium too, so there is no free automatic path.

Either way, keep `library.bib` generated by Better BibTeX rather than
hand-edited in Overleaf — one generator, one direction, no merge conflicts
in a file nobody writes by hand.
