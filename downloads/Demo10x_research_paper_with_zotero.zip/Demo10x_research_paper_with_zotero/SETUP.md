# Setup, step by step

Assumes nothing. Roughly 20 minutes of setup, then 30 of actual work.

Every step ends with **a way to check it worked.** If a check fails, stop
there — the next step will fail in a way that is harder to read.

---

## 0 · Before anything

    cd Demo10_research_paper_with_zotero
    tools/doctor.sh

It prints what is installed, what is missing, and the exact command for each
gap, grouped by how much you lose without it. Nothing is required yet. Come
back to it after every section below.

**Only the Core block has to pass today.** Everything under it is for the
part where a draft becomes a Word document.

    pip3 install python-docx      # if Core reports it missing

---

## 1 · Claude Code

Install it, then from **inside this folder**:

    claude

Starting from inside the folder matters: `CLAUDE.md`, the four subagents and
the permission boundary in `.claude/` are all loaded relative to where you
start.

**Check:** type `/agents`. You should see `librarian`, `citecheck`,
`drafter`, `prose`.

### The document skills (optional, 30 seconds)

Claude Code supports the same skills a claude.ai session has; they are just
not preinstalled. Nothing in this package needs them, but they are what you
would want for a `.pptx` or a `.pdf` later:

    /plugin marketplace add anthropics/skills
    /plugin install document-skills@anthropic-agent-skills

---

## 2 · Zotero and Better BibTeX

1. Install **Zotero 7**.
2. Download the **Better BibTeX** `.xpi` from its GitHub releases page.
   In Firefox, right-click the link and *Save Link As* — a left-click
   installs it as a Firefox extension, which is not what you want.
3. Zotero → **Tools → Plugins** → gear icon → *Install Plugin From File*.

In Zotero 6 this menu was called *Add-ons*. Zotero 7 renamed it to
**Plugins**, and most tutorials online still say the old name.

**Check**, with Zotero open:

    curl -s http://127.0.0.1:23119/connector/ping
    curl -s 'http://127.0.0.1:23119/better-bibtex/cayw?probe=1'

The first answers *is Zotero running*. The second must print `ready`. It is
Better BibTeX's own documented probe and it does **not** pop up the citation
picker.

---

## 3 · Add the three papers

Open `papers/inbox/PAPERS.md`. In Zotero, click the green **Add Item by
Identifier** wand and paste:

    10.1038/s41598-023-49831-6
    10.3390/jpm12050717
    10.31083/RCM33425

All three are CC BY 4.0, so Zotero fetches the PDF as well as the metadata.
If one does not arrive, open the DOI in a browser, save the PDF and drag it
onto the item.

**Check:** three items in Zotero, each with a paperclip showing an attached
PDF.

---

## 4 · Export the library

**Export the whole library, not a collection.** Right-click **My Library** in
the left pane → *Export Library*.

| setting | value | why |
|---|---|---|
| Format | **CSV** | the first column is `Key`, which is the join |
| Export Notes | optional | your Zotero notes, if you keep any |
| Export Files | **leave unticked** | it wraps output in a subfolder and renames attachments by an internal id. We read the live `storage/` instead |

Save it as `papers/library/library.csv`.

> **Why not just a collection?** A collection exports only its own items,
> while `~/Zotero/storage/` holds attachments for *everything*. The mismatch
> is silent: you get one row in the CSV and dozens of folders on disk, and
> every lookup for a paper outside the collection fails with no error.

**Check:**

    head -1 papers/library/library.csv     # must start with: Key,
    wc -l papers/library/library.csv       # 4 lines: header + 3 papers

---

## 5 · Point the manifest at your machine

`papers/library/MANIFEST.md` is **the only vendor-specific file in the whole
workspace** — which tool, which metadata file, which key column, and how a
key becomes a PDF path. Open it and confirm the attachment path matches your
Zotero data directory (Zotero → Settings → Advanced → Files and Folders):

    attachment_path: ~/Zotero/storage/<KEY>/

Swapping Zotero for Paperpile later is this one file plus a re-export. No
folder gets renamed and no agent gets edited.

---

## 6 · Let Claude Code read your PDFs

Claude Code can only read inside the folder you started it in. Your PDFs live
in `~/Zotero/storage/`, which is outside. Add it to
`.claude/settings.json`:

    "additionalDirectories": ["/Users/YOURNAME/Zotero/storage"]

Read access only — the deny list already makes `papers/library/**`
unwritable, and nothing here ever writes into Zotero's own folders.

**Check:** restart `claude`, then ask it to list one storage subfolder. If it
refuses, the path is wrong — use the absolute path, no `~`.

---

## 7 · First run: a note from a paper

Copy one PDF out of Zotero into `papers/inbox/`, then:

    Use the librarian subagent on papers/inbox/<file>.pdf

Watch what it does, in this order: it checks for a duplicate on **DOI**
first, reads `MANIFEST.md` to find the library, writes
`papers/notes/<Author><Year>-<slug>.md` from `_templates/paper.md`, adds a
row to `papers/_index.md`, and rebuilds the view.

**Check:**

    python3 tools/check_notes.py

A read-only conformance check: are all ten sections present, is there a DOI,
does the index row match the file. It fixes nothing — that is deliberate.

---

## 8 · Read the note critically

Open it. Two things to look for:

- **`## My take` is empty.** It always is. That section is yours, and no
  agent writes in it. In six months it is the only part you can trust to be
  your own thinking.
- **`## Problem and aim` comes first**, before `## Claim`. A note that opens
  with the claim has already accepted the paper's framing. What problem did
  they think they were solving, and was the gap real?

Now do the other two papers. Three notes is enough to ask a real question.

    python3 tools/build_views.py          # rebuild papers/_by-area.md

---

## 9 · Ask the library something it cannot fully answer

    Use the question skill: do these models work for patients who
    never reach a therapeutic INR?

The honest answer is **no source here separates that out.** You should get
`[GAP:]` markers rather than a confident synthesis. If you get a smooth,
complete answer from three papers, something invented the rest — and that is
the single most useful thing this demo can show you.

---

## 10 · Draft with citations

    Use the drafter subagent: one paragraph on whether published
    warfarin dose-model accuracy describes patients who never stabilise.

Every claim comes back carrying its **tier**:

    {Choi, 2023}            note      I read it; the note has the numbers
    {Guo, 2025 ·unread}     library   in Zotero, skimmed now, not read properly
    [WEB:1]                 web       online, not in my library
    [GAP: ...]              none      nothing supports this yet

A high web count is a finding, not a failure. So are the gaps.

Then the two reviewers, neither of which can edit:

    Use the citecheck subagent on writing/drafts/<file>.md
    Use the prose subagent on writing/drafts/<file>.md

`citecheck` opens the actual PDFs and checks claim against source.
*Cannot verify* is a legitimate verdict and you will see several.

---

## 11 · Render to Word — or skip to LaTeX

**Writing in LaTeX or Overleaf? Stop here and read `writing/tex/README.md`
instead.** It is the shorter path, not a workaround: same papers, same notes,
same checks, but the `.tex` stays the source of truth forever, so there is no
handoff and agents edit it directly at every stage. Export the `.bib` with
Better BibTeX and **tick `Keep updated`**, then:

    tools/tex.sh writing/tex/<name>.tex --look

One warning worth carrying over even if you never touch Word: **`latexmk`
exits 0 on an undefined citation.** The PDF builds, renders `?`, and drops
the reference. `tex.sh` makes that fatal; Overleaf's compiler will not.

Everything below is the Word route. Two routes within it — try the simple
one first; it needs nothing.

### Route A — formatted text, no installs

    tools/render.sh rtf writing/drafts/<file>.md

Then Zotero → **Tools → RTF Scan**, pick a style, and open the result in
Word. You get formatted citations and a real bibliography as **static text**.
Zotero cannot restyle it later. Fine for a handout; not for a manuscript.

### Route B — live Zotero field codes

This is the one worth the setup. Two downloads, once per machine:

    curl -o tools/zotero.lua \
      https://retorque.re/zotero-better-bibtex/exporting/zotero.lua

    curl -s https://api.github.com/repos/jgm/pandoc/releases/tags/3.8 \
      | grep -o '"browser_download_url": *"[^"]*"' | grep -i macOS.zip
    # arm64 on Apple Silicon, x86_64 on Intel
    unzip pandoc-3.8-<arch>-macOS.zip -d /tmp/p
    mkdir -p tools/pandoc && mv /tmp/p/*/[bs]* tools/pandoc/
    echo tools/pandoc/bin/pandoc > tools/pandoc.path

**Why not `brew install pandoc`?** pandoc 3.9 added an `http` build flag so
pandoc can be built *without* network support. Homebrew's build has it off,
and conda's does too — and the filter talks to Zotero over
`127.0.0.1:23119`, so those builds cannot work. Any pandoc from 2.16.2 to
3.8 is safe, because the flag did not exist yet. `pandoc --version` will not
tell you; `tools/doctor.sh` probes it properly.

With Zotero running:

    tools/render.sh live writing/drafts/<file>.md
    tools/render.sh live writing/tex/<file>.tex

**Both work.** The filter acts on pandoc's citation nodes and branches on the
*output* format, so `[@key]` and `\cite{key}` reach it as the same thing —
measured, not assumed. What the route cannot take is `{Author, Year}`
markers; those are the `rtf` route.

The script counts the citations going in and the Zotero fields coming out,
and fails if they differ rather than handing you a half-cited `.docx`.

---

## 12 · In Word — three steps, and step 2 is the one nobody mentions

1. Zotero tab → **Document Preferences** → OK
2. Cursor under the `References` heading → **Add/Edit Bibliography**
3. **Refresh**

Skip step 2 and the symptom is a non-symptom: Refresh runs, no error, your
citations are shaded grey — and there is no reference list. The filter writes
*citation* fields only; a bibliography is a different field that only the
Word plugin can insert. Once per document.

**Check it is really live:** insert a citation with *Add/Edit Citation* and
watch the bibliography grow. Delete one and watch it shrink. Change the style
in Document Preferences and watch **all** citations restyle. If those three
work, Zotero owns the document.

---

## 13 · Send it back to Claude Code

From here the `.docx` is the source of truth and the markdown is not. There
is no round trip: `docx → md → docx` returns **zero** field codes and loses
every embedded image.

There is no attachment step in Claude Code — the file is already on disk:

    Refine the second paragraph of writing/drafts/<file>.docx.
    Tighten the hedging but do not touch the citations.

Claude reads it with `tools/docx_text.py` (tables render as tables, figures
as `«figure:N …»`, citations as `«citation:N»`) and proposes changes through
`tools/docx_suggest.py`, which writes a **separate** `-suggested.docx` of
tracked changes. Accept or reject each in Word's Review tab.

To review a figure, Claude has to look at it:

    python3 tools/docx_text.py <file>.docx --media /tmp/figs

Reading the caption is not reviewing the figure.

If a file comes back from somewhere else — a co-author, another tool:

    python3 tools/docx_text.py <new>.docx --against <what-you-sent>.docx

Citation counts can match while a field is quietly damaged. This checks eight
things, including images and tables.

---

## 14 · Make it yours

- **`writing/STYLE.md`** ships blank. Paste two paragraphs of your own
  writing into it; `prose` will stop flagging your habits as faults.
- **The area table in `CLAUDE.md`** is generic. Rewrite it for your field —
  four areas that will still make sense in three years.
- **Put your own papers in.** Nothing here depends on the three demo papers.
- **`git init`** in this folder is worth more than any configuration on this
  page. It is what lets you tell what an agent changed.

---

## When something goes wrong

| symptom | cause |
|---|---|
| `no pandoc with HTTP support` | Homebrew's or conda's build. Route B above. |
| `FAIL no citations found` | draft has `{Author, Year}`; that is Route A |
| `has N citation(s) but M field(s)` | a cite key is not in Zotero — the filter printed which |
| Refresh works, no reference list | step 2 above was skipped |
| Word says the file is corrupt | re-run the identical command; documented quirk |
| `citecheck` cannot read any PDF | step 6 — `additionalDirectories` |
| library lookups fail for most papers | you exported a collection, not the library |
| agent edited something it should not | tell us; that is a bug in the deny list |

`tools/doctor.sh` covers most of the top half of that table.
