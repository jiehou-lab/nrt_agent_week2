# papers/inbox/ — literature waiting to be read up

Drop a PDF here. That is the whole protocol.

It sits beside `notes/` because what comes out of it is a note in `papers/notes/`.
One intake for one literature, the same way there is one `_index.md` and one
Zotero library.

## Drop it even if you think it is already filed

**You are not expected to remember what is in Zotero or in `papers/notes/`.** That
is a machine's job and it is the first thing `librarian` does:

| what it finds | what it does |
|---|---|
| Same DOI already in `papers/notes/` | **Writes no second note.** Reports the existing one — path, date filed, areas, and your `## My take` — then asks whether anything should change. |
| In Zotero but never read up | Says so, and files it normally. |
| Preprint of a note you have (or vice versa) | **Not a duplicate.** Two documents, one study: both get notes, both flagged, cross-linked. |
| Genuinely new | Note, index line, DOI reported. |

A rule that depends on your memory is a rule that breaks in week three and
then the whole convention feels like theatre. Dropping a duplicate costs one
grep. Not dropping a paper because you half-remembered filing it costs you
the paper.

## Area and project are assigned by reading, not by filing

You do not sort into folders. `librarian` opens the paper and sets `area:`
from the four in `CLAUDE.md` — two if two fit. It then **proposes**
an area and you confirm, because what you grabbed it for is
intent, not content, and the paper cannot tell it.

Area is a field, not a folder. A paper that serves two areas says so, in
one note. Nothing is duplicated and nothing is filed arbitrarily.

## Literature only

| | |
|---|---|
| A meeting transcript | not this workspace. This one is papers only. |
| Your own draft | `writing/drafts/` |
| A dataset or result | not this workspace. This one is papers only. |

If it is not something you would cite, it does not belong here.

## How it empties

    Use the librarian subagent on papers/inbox/<file>

Only for papers you have **actually read**. A note exists because you read it.

Then: add it to Zotero (*Add Item by Identifier*, paste the DOI the librarian
reported), attach the PDF, re-export, reconcile, and delete the copy here.
Zotero holds the only copy that matters.

## Finding what you just filed

Five PDFs in, five notes out, among hundreds. Before you commit:

    git status --short papers/notes/

The `??` lines are exactly today's. After the commit, the **Recently added**
table at the top of `papers/_by-area.md` is what remains — built from each
note's `added:` date, so it survives commits, moves and re-clones.

## Nothing here is versioned

`.gitignore` excludes the contents — transient by definition, and a 6 MB PDF
committed once stays in history forever. So `git status` will not show you
what is waiting. This will:

    ls papers/inbox/

## Empty is the correct state

Not a backlog. If five things have sat here a month, you are not going to
read them. Delete them and feel nothing.
