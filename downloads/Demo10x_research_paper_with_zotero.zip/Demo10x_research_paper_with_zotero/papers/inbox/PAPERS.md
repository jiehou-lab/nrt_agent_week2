# The three papers for this demo

**No PDFs ship with this package, on purpose.** Adding a paper to Zotero by
its DOI and letting Zotero fetch the PDF *is* the first step of the workflow
you are learning. Pre-staging the files would skip it.

All three are **open access under CC BY 4.0** — real papers, real DOIs, real
authors. You can cite them. They are a coherent set: one review and two
primary cohorts that used different populations and different methods to
answer nearly the same question.

| # | DOI | short |
|---|---|---|
| 1 | `10.1038/s41598-023-49831-6` | Choi 2023 — Korean inpatients, discharge dose |
| 2 | `10.3390/jpm12050717` | Zhang 2022 — review of nonlinear ML |
| 3 | `10.31083/RCM33425` | Guo 2025 — mechanical valve, stable dose |

## How to add them

**In Zotero:** click the green *Add Item by Identifier* button (the magic
wand) in the toolbar, paste one DOI, press Enter. Repeat. Zotero fetches the
metadata and, for these three, the PDF as well.

Paste all three at once if you like — the wand accepts a multi-line list.

**If a PDF does not arrive**, open the DOI in a browser and save the PDF,
then drag it onto the Zotero item. All three publishers serve the PDF without
a paywall or a login.

## Full citations

**1.** Choi H, Kang HJ, Ahn I, Gwon H, Kim Y, Seo H, Cho HN, Han J, Kim M,
Kee G, Park S, Kwon O, Roh J-H, Kim A-R, Kim JH, Jun TJ, Kim Y-H.
*Machine learning models to predict the warfarin discharge dosage using
clinical information of inpatients from South Korea.*
**Scientific Reports** 13:22461 (2023). <https://doi.org/10.1038/s41598-023-49831-6>
— © The Author(s), CC BY 4.0.

**2.** Zhang F, Liu Y, Ma W, Zhao S, Chen J, Gu Z.
*Nonlinear Machine Learning in Warfarin Dose Prediction: Insights from
Contemporary Modelling Studies.*
**Journal of Personalized Medicine** 12(5):717 (2022). <https://doi.org/10.3390/jpm12050717>
— © The Authors, CC BY 4.0.

**3.** Guo B, Chen C, Jia J, Zheng J, Song Y, Liu T, Zhang K, Li Y, Dong R.
*A Prediction Model of Stable Warfarin Doses in Patients After Mechanical
Heart Valve Replacement Based on a Machine Learning Algorithm.*
**Reviews in Cardiovascular Medicine** 26(6):33425 (2025). <https://doi.org/10.31083/RCM33425>
— © The Authors, CC BY 4.0.

## Why these three

They share a question — *can a model predict a warfarin dose well enough to
use?* — and they answer it on different populations with different methods.
That gives you something real to do:

- **A note each** that an agent drafts and you correct.
- **A synthesis question** whose answer is not in any one of them.
- **A citation check** with actual numbers to verify against actual PDFs.
- **An honest gap.** None of the three reports error stratified by whether
  the patient ever reached a therapeutic range. So a draft about patients who
  never stabilise will come back with `[GAP:]` markers, and that is the
  correct result, not a failure of the agent.

The last one is the point of the whole demo. A system that cannot tell you
what it does not know is worse than no system.

## Using your own papers instead

Fine, and better. Put three or four PDFs on one topic into Zotero, export
`library.csv` as `papers/library/README.md` describes, and work from those.
Everything in this package is about the method, not these three papers.
