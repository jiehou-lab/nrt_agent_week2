---
tool: Zotero
version: "10"
metadata_file: library.csv
key_column: Key
key_shape: 8 uppercase alphanumerics
key_regex: "^[A-Z0-9]{8}$"      # machine-readable. tools/check_notes.py uses this.
attachment_path: ~/Zotero/storage/<KEY>/   # the LIVE data dir, not an export
bib_file: library.bib            # OPTIONAL. nothing here reads it. for your manuscripts.
updated: 2026-10-03
---

# Which reference manager this is, and how to read it

**This is the only tool-specific file in the workspace.** Everything else —
the agents, the note template, the index, the skills — reads the facts in the
frontmatter above and does not know or care what produced them.

Swapping reference managers means rewriting *this file*. Not renaming folders,
not editing agents.

## Naming these files

**The names are mine to choose** — change `metadata_file:` and `bib_file:`
above and nothing else in the workspace needs touching. Nothing hardcodes
them: `librarian`, `citecheck` and `tools/check_notes.py` all read this file.

Two things worth getting right, though:

- **Name it for its role, not its contents or its vendor.** `library.csv`
  survives a switch to Paperpile and a year of scope creep. `zotero_` repeats
  what this file already says, and the folder is called `library/` rather than
  `zotero/` for exactly that reason.
- **Not one export per project.** `zotero_warfarin.csv` alongside
  `zotero_rna.csv` would mean two answers to "do I have this paper", and
  dedup would have to read both and reconcile them. There is **one** literature
  here — papers are not filed per project, and neither is the library that
  holds them. Export one collection if you like; just call it `library`.

`My Library` is Zotero's own default and says nothing; it is not a good name
either.

## One file is required. One is optional.

| | |
|---|---|
| **`library.csv`** | **Required.** The only file this system reads. Its `Key` column is the join. |
| `library.bib` | **Optional, and read by nothing here.** It exists for your manuscripts. Skip it entirely if you cite with Zotero's Word or LibreOffice plugin, which talks to the live library and needs no export. Export it if you write in LaTeX, or owe a collaborator a `.bib`. |

The `.bib` cannot replace the CSV: Better BibTeX cite keys look like
`choiMachineLearningModels2023` and **regenerate when metadata
changes**, so they cannot be a join. The CSV's `Key` does not change.

## The four facts, and why each is needed

| fact | why |
|---|---|
| `metadata_file` | the table that answers "do I have this paper". `citecheck` opens it before trusting any citation. |
| `key_column` | the column holding the per-item identifier that notes join on, as `item_key:`. |
| `key_shape` / `key_regex` | so a malformed key is caught rather than stored. `check_notes.py` enforces the regex. |
| `attachment_path` | the rule for getting from a key to a PDF on disk. `librarian` and `citecheck` both open attachments; neither may guess the path. |

### Why `attachment_path` points outside this folder

Zotero's own data directory is `~/Zotero/`, and it contains a `storage/`
folder whose subfolders are the **8-character item keys** — exactly what
notes join on. So the PDFs are already laid out the way this system needs,
and **they are the live files**, not a copy.

Pointing at them means:

- **no attachment export at all.** Untick *Export Files*. The only thing
  exported is the metadata table.
- **attachments cannot go stale**, because nothing is copied. The
  "export all three as a set" problem shrinks to one file.
- **no 1–2 GB duplicate** in the workspace, and nothing for `.gitignore`
  to chase.

They are read-only to every agent: `~/Zotero` is in `additionalDirectories`
and denied for `Edit`, `Write` and `mv` in `.claude/settings.json`.

**Do not confuse this with an export.** An *exported* collection with
*Export Files* ticked puts attachments in `<name>/files/<number>/` — numbered
by internal item ID, **not** by the item key — so it cannot be joined on.
That is the wrong shape for this system.

If your attachments are linked files kept elsewhere, or your data directory
has been moved, set `attachment_path` to wherever they actually are and add
that path to `additionalDirectories` instead.

## Why a snapshot at all, when Zotero is right there

Fair question, and the answer is not "because it has to be".

**The metadata could be live.** Zotero has a read-only local HTTP API at
`http://localhost:23119/api/` (Settings → Advanced), and `zotero-mcp` wraps it
— three tools: search, metadata, full text. Nothing goes stale, ever.

**But it requires Zotero to be running.** Close Zotero, or run `claude` on a
morning you have not opened it, and every library question fails. A snapshot
answers when Zotero is shut.

**And a snapshot is reproducible.** A note written against `library.csv` can
be re-checked later against that same CSV, in git history. A note written
against a live library can only be re-checked against a library that has
since changed. That matters for the one thing this workspace exists to do:
make a claim you can still defend in two years.

**Do not read `zotero.sqlite` directly.** Zotero's own docs: *"A caching
layer breaks the normal file-locking in SQLite"*, the schema *"can change
between Zotero releases"*, and they recommend the API instead.

So the split is deliberate:

| | |
|---|---|
| **attachments** | **live** — read straight from `~/Zotero/storage/`. Cannot go stale. |
| **metadata** | **snapshot** — `library.csv`, reproducible, works with Zotero closed. |

### "What if I add a paper and forget to export?"

**`tools/check_notes.py` catches it**, and it can be exact precisely because
attachments are live: every item you add with a PDF creates a folder in
`~/Zotero/storage/`, and the CSV does not grow with it.

    warn  library: 3 attachment folders have no row in library.csv —
          Zotero has moved on; RE-EXPORT THE CSV.

    warn  library: 1 rows in library.csv but 48 attachment folders — this
          CSV looks like a COLLECTION, not the whole library.

It is an upper bound: web snapshots and trashed items have folders too. But
it never stays silent while the snapshot drifts, which is the thing that
would actually hurt.

**If the staleness still bothers you**, add `zotero-mcp` for live queries and
keep the CSV as the reproducible snapshot. They are not alternatives —
`EXTENDING.md` covers adding an MCP server.

## Export the whole library, not a collection

The metadata table and `~/Zotero/storage/` must describe the same set. Export
one collection and they do not: the CSV holds the collection, storage holds
everything, and every item outside the collection is invisible to this system
while its PDF sits on disk. Nothing errors.

Right-click **My Library**, not a collection. Narrowing is what `area:` and
`area:` is for — a field holds two values, an export folder holds one.

## Getting the export in (Zotero)

1. In Zotero, right-click the collection → **Export Collection…**
2. **Required.** Format **CSV** → save here as `library.csv`. Its `Key`
   column is the join. Every checkbox unticked.
3. *Optional, for manuscripts only.* Format **Better BibTeX**, every
   checkbox unticked → `library.bib`. Skip if you cite through Zotero's
   word-processor plugin.

Attachments are **not** exported. They are read live from
`~/Zotero/storage/<KEY>/`; see above.

| checkbox | |
|---|---|
| **Export Files** | **untick.** It wraps the output in a subfolder and puts attachments in `files/<number>/`, numbered by item ID, which cannot be joined on. Attachments are read live instead. |
| **Include Annotations** | **untick** — moot once Export Files is off, and independently risky: annotations live in Zotero's database, and embedding them has produced PDFs with no text layer at all (Zotero 10.0.1 bug report). |
| **Keep updated** | **untick here.** It auto-re-exports the `.bib` only, never the CSV, which has no auto mode. Useful next to a manuscript; here it just makes two files drift at two rates. |
| Export Notes · Journal Abbreviation | untick |

**Re-export the CSV whenever you add papers.** That is now the only file that
goes stale — attachments are live, and the `.bib` is only for your
manuscripts. `python3 tools/check_notes.py` reports every key in the CSV with
no attachment folder, which catches both a stale CSV and a Zotero item you
never attached a PDF to.

## Going live later (Zotero)

Zotero 7+ has a local API — Settings → Advanced → "Allow other applications
on this computer to communicate with Zotero" — at `http://localhost:23119/api/`,
**no API key**. `zotero-mcp` reaches it with `ZOTERO_LOCAL=true`.

It is **read-only** (search, metadata, full text — three tools, all reads), so
it does not replace exporting. Export anything you are going to analyse, so
the thing you analysed still exists in the state you analysed it.

## If you use something else

Rewrite the frontmatter and this section. The rest of the workspace follows.

<details>
<summary>Paperpile</summary>

```yaml
tool: Paperpile
metadata_file: paperpile.bib        # Paperpile keeps a .bib in sync automatically
key_column: citekey                 # the BibTeX entry key
key_shape: author-year-word, lowercase
key_regex: "^[a-z]+[0-9]{4}[a-z]+$"
attachment_path: "<synced Google Drive>/Paperpile/All Papers/<A>/<file>.pdf"
```

PDFs live in a Google Drive folder that syncs locally, so `attachment_path`
points at the synced copy. **Confirm the key is stable before relying on it:
a key that regenerates when metadata changes cannot be the join.** If it is
not stable, use `doi:` alone and set `item_key: none`.
</details>

<details>
<summary>EndNote, Mendeley, a plain BibTeX folder</summary>

Same questions, different answers. EndNote keeps attachments in a `.Data/`
folder beside the `.enl`, and its own docs say not to move them, so
`attachment_path` points in there. A plain `.bib` plus a folder of PDFs named
by cite key is a perfectly good library here — it has all four facts.
</details>

## What else the CSV carries

87 columns. Beyond the identifiers, these are the ones worth knowing about —
all of them readable by agents without any live connection:

| column | what it gives you |
|---|---|
| `Manual Tags` · `Automatic Tags` | **your Zotero tagging, readable here.** Tag in Zotero, filter in the workspace. |
| `File Attachments` | the **absolute path** to each attachment. More reliable than the `storage/<KEY>/` convention, because it handles linked files and items with several attachments. |
| `Extra` | Zotero's free field — and where Better BibTeX pins a cite key (`Citation Key: ...`). |
| `Abstract Note` | the full abstract. Useful for triage; **never** as evidence. |
| `Date Added` · `Date Modified` | answers "what did I add to the library this week" from the library side, independent of `added:` in the notes. |
| `Notes` | your Zotero child notes — **only if you tick Export Notes.** Off by default here, because notes belong in `papers/notes/`. Tick it if you already write in Zotero and want that text reachable. |

**What the CSV cannot give you: PDF annotations.** Highlights live in Zotero's
database, not in the file and not in this export. Reaching them means the
local API, or exporting an annotation report by hand.

## Only one

There is **one** library, whatever the tool. Not one folder per tool. Two
libraries means two answers to "do I have this paper", and `item_key:` is
ambiguous unless every note also records which library it came from.
Migrating means rewriting this file and re-exporting, not adding a sibling.

`doi:` is the identifier that survives a migration. `item_key:` is local to
whatever this manifest currently describes.
