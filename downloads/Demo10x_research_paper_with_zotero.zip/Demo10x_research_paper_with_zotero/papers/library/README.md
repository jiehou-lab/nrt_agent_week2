# papers/library/ — the reference manager's export. Read only.

Nothing here is written by an agent. `.claude/settings.json` denies `Edit`,
`Write` and `mv` on this whole folder. It is the **system of record for what
I have**, and a record you can edit is not a record.

**Which tool this is, and how to read it, is in [`MANIFEST.md`](MANIFEST.md)** —
the only vendor-specific file in the workspace. Read it before opening
anything here. Everything below is true whatever tool you use.

## What the workspace needs from a reference manager

Four facts, all named in the manifest. Any tool that can supply them works:

| | |
|---|---|
| a **metadata table** on disk | answers "do I have this paper" |
| a **key column** in it | what notes join on, as `item_key:` |
| the **shape** of that key | so a malformed one is caught, not stored |
| a **rule from key to PDF** | agents open attachments; none may guess a path |

Zotero, Paperpile, EndNote, Mendeley or a plain `.bib` beside a folder of
PDFs all have these. The manifest is where you say which.

## Export the metadata. Never the attachments.

`MANIFEST.md` points `attachment_path` at the reference manager's **own**
storage — for Zotero, `~/Zotero/storage/<KEY>/`, whose subfolders are already
named by item key. Those files are read live and read-only, so **nothing is
copied and nothing can go stale.**

That leaves one exported file, the metadata table, and one chore: re-export
it when you add papers.

`python3 tools/check_notes.py` checks this every run: it compares the
metadata file's timestamp against the attachment folder's, counts how many
keys have no attachment folder, and warns on both. **It is the only automatic
defence against a half-finished export**, so read its `library:` lines.

After any re-export:

    Reconcile papers/library/ against papers/_index.md, using the metadata
    file and key column named in MANIFEST.md. Report every disagreement.
    Change nothing.

## Taking in a paper that is not in the library yet

| | |
|---|---|
| 1. Drop the PDF | `papers/inbox/` — you. Duplicates welcome; step 2 catches them. |
| 2. Read it, write the note | `librarian` — note in `papers/notes/`, line in `_index.md`, `item_key: none`, flag `inbox-only` |
| 3. Report the DOI | `librarian` — or `unknown`. It never invents one. |
| 4. Add it to the library | **you**, in the tool itself. Paste the DOI and let the tool fetch the metadata — it comes from CrossRef and beats anything assembled by reading a PDF. |
| 5. Attach the PDF | **you.** The library now holds the only copy that matters. |
| 6. Re-export, as a set | **you** |
| 7. Resolve the key | the reconcile above; `item_key: none` becomes real, `inbox-only` comes off |
| 8. Delete the inbox copy | **you.** Two copies is one too many. |

**Steps 4 and 5 are yours on purpose.** An agent that can write to the system
of record is an agent whose mistakes you cannot detect by comparing against
it. That is the same reason this folder is read-only and `citecheck` has no
`Write` tool.

## Two identifiers, one of which survives

`doi:` is cross-tool. It still means something after a migration, a
re-export, or a switch to a different manager — so it is what matching and
deduplication use.

`item_key:` is local to whatever `MANIFEST.md` currently describes. It is how
an attachment is found on disk, and it is meaningless anywhere else. If your
tool's key regenerates when metadata changes, it cannot be a join: set
`item_key: none` and rely on the DOI.
