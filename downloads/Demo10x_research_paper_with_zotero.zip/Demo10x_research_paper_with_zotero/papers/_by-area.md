# Papers by area

> **GENERATED — do not edit.** `python3 tools/build_views.py`
> Built 2026-10-04 from `_index.md`, which is the source of truth.

A paper with two areas appears under **both**. That is the whole reason
this is a view and `papers/notes/` is flat — a folder would force one.

## methods  (0)

_nothing yet._

## application  (0)

_nothing yet._

## evaluation  (0)

_nothing yet._

## background  (0)

_nothing yet._

---

0 papers. 0 in more than one area.
