# Paper index

One line per note, and **the source of truth for what has been read.** Agents
read this before opening any note: it is about 20 tokens a line where a note
is 550. Three hundred papers is 6k tokens here and 165k as notes.

The column order below is not cosmetic — `tools/build_views.py` parses on it.
A row with the wrong number of cells is skipped silently.

| note | area | item_key | year | claim | tags |
|---|---|---|---|---|---|

<!-- note     the filename without .md, so [[note]] resolves
     area     methods | application | evaluation | background. two is fine: "methods, application"
     item_key the key_column from papers/library/MANIFEST.md, or `none`
     year     publication year
     claim    the paper's main claim in one line, in sentence form
     tags     free text; keep it short

     Add a row when a note is created. Never delete a row for a paper you
     still have — flag it in the note instead. -->
