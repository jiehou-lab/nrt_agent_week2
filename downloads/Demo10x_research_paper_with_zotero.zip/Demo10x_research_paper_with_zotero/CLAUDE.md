# Paper workspace

One literature, read carefully, written up honestly, cited from a real
reference manager. That is the whole scope. There are no projects, no
proposals and no topic syntheses here — if you want those, they are a
different workspace.

**Read this file before touching anything.** It is the contract.

## Layout and who owns what

| path | who writes it | what it is |
|---|---|---|
| `papers/inbox/` | **you** | PDFs waiting to be read. Empty is correct. |
| `papers/notes/` | agents, you edit | one note per paper. Flat. |
| `papers/_index.md` | agents | one line per note. The source of truth. |
| `papers/_by-area.md` | **generated** | never edit. `tools/build_views.py`. |
| `papers/library/` | **your reference manager** | READ ONLY to every agent. |
| `writing/drafts/` | agents, you decide | markdown drafts, then Word. |
| `writing/STYLE.md` | **you** | how your prose should sound. |
| `QUESTIONS.md` | **you** | what you are trying to find out. Numbered. |
| `CLAUDE.md` | **you** | this file. |

Anything marked **you** is yours; an agent proposing a change to it says so
and waits. Anything marked generated is rebuilt, never hand-edited.

## The three layers

Three different ways to stop an agent doing something, and they are not
interchangeable:

| layer | file | what it is |
|---|---|---|
| **context** | `CLAUDE.md` | a **request**. Can be misread, forgotten, overridden. |
| **permission** | `.claude/settings.json` | a **refusal**. The tool call is blocked. |
| **capability** | a subagent's `tools:` list | an **absence**. There is nothing to call. |

A rule that matters belongs in the lowest layer that can hold it. "Do not
edit the library" is a request; the deny list makes it a refusal. "The
citation checker must not fix what it finds" is neither — `citecheck` simply
has no `Write` tool, so the option does not exist.

**A verifier that can edit is a verifier you cannot trust.** It can make its
own findings disappear.

## The shape of `papers/`

    papers/
    ├── library/        your reference manager's export. READ ONLY.
    │   └── MANIFEST.md   which tool, and how to read it. The ONLY vendor file.
    ├── inbox/          PDFs in. gitignored. empty = correct.
    ├── _index.md       one line per note. the source of truth.
    ├── _by-area.md     GENERATED view. never edit.
    └── notes/          every note. flat. nothing else in here.

**There is exactly one library, whatever tool fills it.** `papers/library/`
is named for its role, not its vendor. `MANIFEST.md` says which tool, which
metadata file, which key column, and how a key becomes a PDF path on disk.
Those are the only tool-specific facts anywhere, so swapping Zotero for
Paperpile or Mendeley is one file rewritten and a re-export.

Not `papers/zotero/` with room for a second. Two libraries means two answers
to "do I have this paper", and `item_key:` stops being unambiguous.

## Areas are a field, not a folder

`papers/notes/` has **no subfolders**. A note carries `area:` in its
frontmatter and that field can hold two values; a folder holds one.

Edit this table to your own field. It ships generic on purpose:

| area | covers |
|---|---|
| `methods` | the modelling, statistics or technique itself |
| `application` | the domain the method is used on |
| `evaluation` | benchmarks, validation, reproducibility |
| `background` | reviews, position papers, context |

**Folders may encode lifecycle, never classification.** `inbox/` is a folder
because *unprocessed* is a state a paper is in exactly one of. Area is not —
a paper is in several at once. Before adding any subfolder, apply the test:
**can a paper be in two of these at the same time?** If yes, it is a field.

Browse with the generated view, not a tree:

    python3 tools/build_views.py            # rebuild papers/_by-area.md
    python3 tools/build_views.py --check    # exit 1 if stale

A paper with two areas appears under **both** headings, which is exactly what
a folder cannot do. For a one-off slice, just ask:

    Group papers/_index.md by area, 2024 onward, flagged notes only.

## Note filenames

`papers/notes/<Author><Year>-<two-or-three-words>.md`

    papers/notes/Choi2023-warfarin-discharge-dose.md
    papers/notes/Zhang2022-nonlinear-ml-review.md

Lowercase the slug, hyphens, no underscores. **Not the item key** —
`4J8KQW2M.md` is unreadable in a folder listing and in a search result, and
the key is already in the frontmatter. Two papers by one author in one year:
add `b`, `c` to the year. Never renumber an existing note.

## Identifiers

Two, and they do different jobs.

```yaml
doi: "10.1038/s41598-023-49831-6"   # cross-tool. survives migration. the real one.
item_key: "4J8KQW2M"                # local to whatever MANIFEST.md describes.
```

**`doi:` outlives the tool.** It is how a paper is matched when
deduplicating, how a note is recognised after the library is re-exported, and
the only thing that still means anything if you leave Zotero. Prefer it for
every comparison.

**`item_key:` is the local join** — what `MANIFEST.md` calls `key_column`,
used to find the PDF on disk. Meaningless outside that one library.

Not the title, which gets retyped. Not the filename. Not a Better BibTeX cite
key, which regenerates when you fix metadata — unless you pinned it in
Zotero's `Extra` field.

If a source has no library item, write `item_key: none` and say why on the
next line. **Never invent either identifier.** `unknown` is correct; a
plausible DOI is wrong for years.

## Finding what is new — never scan

Do not read all of `papers/notes/` to work out what has been processed:

    ls papers/inbox/          # what is waiting
    git status --short        # what this batch added

`_index.md` is about 20 tokens a line; a note is about 550. Three hundred
papers is 6k tokens as an index and 165k as notes. Read the index, then open
only the notes the question needs.

## Rules

1. **Never edit `papers/library/`.** It is your reference manager's. Changes
   belong in Zotero, followed by a re-export.
2. **Never invent a DOI, an item key, a page number or a result.** Say
   `unknown`, or leave the `[GAP:]` marker in.
3. **One note per paper.** Found a second? Reconcile on DOI, do not add.
4. **Rebuild the view** after any batch. Never hand-edit `_by-area.md`.
5. **`## My take` is mine.** An agent leaves it empty, always.
6. **`QUESTIONS.md` is mine.** An agent drafts a block and shows it; I paste it.
   Never renumber a question — notes and drafts cite the numbers.

## Writing

`writing/README.md` has the pipeline. The order matters, because each pass
only sees what it is built to see:

    drafter  →  cite  →  citecheck  →  prose  →  render

- `drafter` writes from a note, from a library PDF with no note, from the
  web, or from nothing — but **every claim declares its tier**:

      {Choi, 2023}            note     I read it; the note's Evidence has the numbers
      {Guo, 2025 ·unread}     library  in the library, skimmed now, not properly read
      [WEB:1]                 web      online, not in my library
      [GAP: ...]              none     correct behaviour, not a failure

  A web-tier claim may not state a number as fact; it attributes it.
- It writes **markers**, never formatted references. Formatting is Zotero's
  job, or pandoc's.
- `prose` and `citecheck` have **no `Write` tool**. They report; you decide.

### Markdown drafts, then a Word endgame

Rendering to `live` is **one-way**. A `.docx` with Zotero field codes cannot
be round-tripped: `docx → md → docx` returns zero field codes, citations
become plain text, and Zotero stops owning the document.

| | source of truth | agents may | how to change it |
|---|---|---|---|
| **drafting** | the `.md` | rewrite freely | `drafter`, then the checkers |
| **after `render.sh live`** | the `.docx` | **read, and suggest** | `tools/docx_suggest.py` |

- **Never regenerate a live `.docx` from its markdown.** The deny list
  removes `Edit`/`Write` on `writing/**/*.docx`, so this is an absence.
- Read one with `tools/docx_text.py`; propose changes with
  `tools/docx_suggest.py`, which writes a separate `-suggested.docx` of
  tracked changes. The `docx-review` skill has the procedure.
- **Never insert a citation into a `.docx`.** Propose
  `[CITE: authorYearKeyword]`; the human inserts it with Add/Edit Citation.

**Prefer refining before the handoff.** Markdown edits are cheap; every one
after the handoff is careful.

### If I write in LaTeX, none of that applies

`writing/tex/README.md`. The `.tex` is the source of truth from the first
line to the last, so **edit it directly at every stage** — there is no
handoff and no tracked-changes dance.

- Compile with `tools/tex.sh <file>.tex`. **Never trust `latexmk`'s exit
  code alone**: it exits 0 on an undefined citation, builds the PDF, and
  renders `?` where the reference should be. `tex.sh` makes that fatal.
- `--look` renders each page to PNG. Read them. A table running off the page
  compiles perfectly.
- Citations are `\cite{key}` from `papers/library/library.bib`, which Better
  BibTeX keeps in sync. `[GAP:]` markers go in `%` comments so they never
  typeset.

## Reporting back

Say what you did, what you could not verify, and what you left open. A run
that ends with four `[GAP:]` markers and three *cannot verify* lines from a
three-paper library is **correct**. A run that ends with a confident,
complete paragraph from a three-paper library invented the rest.
