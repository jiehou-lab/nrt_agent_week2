# What I am trying to find out

**Yours. No agent writes here** — the deny list makes that a refusal, not a
request. An agent may draft a replacement block and show it to you; you paste
it in.

Numbered, because everything else refers to them: a note's `## Relevance`
cites `Q2`, a `[GAP:]` marker says which question the missing evidence would
answer, and `citecheck` reports per question.

A good question states **what evidence would answer it**. Without that it is
a topic, and a topic can never be closed.

---

## Q1 · <one sentence, ending in a question mark>

- **Status** — open | answered | dropped
- **Why it matters** — what changes depending on the answer.
- **What would answer it** — the specific result, measurement or source.
  Be concrete enough that you would recognise it if you saw it.
- **Where it stands** — what you have so far, and what is missing.

---

<!-- Example, delete it:

## Q1 · Do published warfarin dose-model accuracies describe patients who
never reach a therapeutic range?

- **Status** — open
- **Why it matters** — if the tail is excluded by the outcome definition,
  a reported R² says nothing about the patients a clinician worries about.
- **What would answer it** — prediction error stratified by achieved INR
  band, with tail covariates compared against the training distribution.
- **Where it stands** — three papers report pooled accuracy only. None
  stratifies. The exclusion criteria in two of them would remove the tail
  before the model ever sees it.

-->
