---
type: paper
title: ""
authors: []
year:
venue: ""
doi: ""                 # cross-tool, survives migration. PREFER THIS for matching.
item_key: ""            # the key_column in papers/library/MANIFEST.md. or `none` + reason.
source_file: ""         # only when item_key is none — the papers/inbox/ filename
attachment_read:        # true | false
area: []                # methods | application | evaluation | background — may be two
added:
status: read
flags: []               # contradiction | duplicate | correction | abstract-only | no-text-layer | inbox-only
tags: []
---

# <Author><Year> — <short title>

## Problem and aim
<!-- Three short lines. The value is in the gaps BETWEEN them, not in any
     one of them, so write all three even when they look the same. -->
- **Unsolved** — what they say is missing, in their words.
- **Aim** — what they set out to do about it. "We develop X and validate
  it on Y."
- **Is the gap real?** Name the paper that already did part of it, if there
  is one. Authors routinely overstate novelty and almost nobody checks.

<!-- Gap 1: aim narrower than problem — they motivate a big gap and address
     a slice of it. Gap 2: Claim below narrower than Aim — they set out to
     validate prospectively and ended up validating something else. Both are
     normal; both belong in ## Checks. -->

## Claim
One sentence: what the paper asserts it showed. **Not what it set out to
show** — that is the Aim above, and the difference is often the finding.

## Method
<!-- Not "they used a random forest." The five facts that decide whether
     the numbers mean anything. Write `not stated` when it is not stated —
     that is itself a finding. -->
- **Data** — what, n =, from where, public or not
- **Design** — what was compared against what
- **Validation** — the split. Random? Grouped by subject? Temporal?
  External cohort? ← the single most common place these papers go wrong
- **Baselines** — what they compared to, and whether it is the strongest
  method they themselves cite
- **Code / data** — URL, or `none`. Did the link resolve when you checked?

## Evidence
The numbers, each with the table or section it came from.

## Supports
<!-- What this paper can be CITED FOR. 2-4 statements, each with where in the
     paper it comes from. This is what a citation search reads — the index
     line carries one claim, and a paper is usually citable for more than
     one thing, often not its headline. Only what Evidence above supports. -->
- <statement> — Table 3
- <statement> — §4.2

## Checks
Abstract vs tables. n in abstract vs methods. Baseline choice. Any notice on
page 1. Overlap with other notes here.

**Does the Claim deliver the Aim?** A paper that aimed to validate
prospectively and claims it did, on a cohort missing the variable under
test, has not. The abstract will not flag this; it is the most common
overstatement in a results paper and the cheapest one to catch.

## Limitations
What the authors concede, and what they do not.

## Relevance
<!-- What question of MINE this bears on, and how. Be concrete about which
     claim it supports, limits or contradicts:
     "Gives the dose-band stratification I was going to build myself."
     Empty is a finding, not a blank: why did I read this? -->

## Links

## My take
<!-- MINE. Agents do not write here. Two sentences, same day:
     does this change what I will do, and why or why not?
     That is the significance of the paper, and it is the one judgement
     worth storing, because it is the only one I made. -->
