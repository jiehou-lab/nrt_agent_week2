---
name: cite
description: Find which paper in the library supports a sentence being written, and say what it does and does not support. Use when asked what to cite, which paper backs a claim, or to find a source for a statement in a draft.
---

# Finding a citation

Finding and verifying are two jobs. This is **finding** — narrowing the
library to a few candidates and saying what each actually supports. Once a
source is chosen, `citecheck` is what audits the finished sentence against it.

You write nothing. Not the draft, not the notes, not the index.

## The funnel

Four steps, cheapest first. **Do not skip to reading notes** — at 300 papers
that is ~165,000 tokens and most of it is irrelevant.

### 1. Read `papers/_index.md` in full

It is one line per paper and it is cheap. Filter on `area`, `tags`, `year`.
This gets you from everything to a candidate set.

### 2. Grep the notes — this is the step that matters

The index carries **one** claim per paper, and it is usually the headline
finding. The sentence being written is often supported by something else in
the paper entirely: its method, its cohort, a secondary result. So the index
*will* miss papers that are good citations.

    grep -il "<term>" papers/notes/*.md

Grep several wordings, not one. The note says "non-therapeutic range"; the
draft says "out-of-range INR". Nothing matches unless you try both. List the
terms you tried — if the answer is thin, the terms are the first suspect.

### 3. Open the hits — the `## Supports` section first

That section is written for exactly this: 2–4 statements the paper can be
cited for, each with a table or section. Read it before the rest of the note.

Open at most 8. If more than 8 survive, the query is too broad — say so and
ask which sense is meant rather than reading 30 notes.

### 4. Check the Evidence, not the Supports line

`## Supports` is a pointer. Before recommending a paper, read `## Evidence` and
confirm the numbers are there and say what the sentence needs. A statement
that survived into Supports but is not in Evidence is a finding — report it.

## What to return

For each candidate, in order of how well it fits:

    papers/notes/<note>.md   item_key: <KEY>   <Author> <Year>
      Supports .... <the statement, quoted from the note>
      Where ....... Table 3 / §4.2
      Does NOT .... <the part of your sentence it does not cover>

The **Does NOT** line is the one that earns this. A paper that supports half
your sentence, cited as if it supported all of it, is the most common way a
draft becomes wrong — and it reads perfectly.

Then one of:

- **Nothing fits.** Say so plainly. "No paper in the library supports this"
  is a useful answer and often the true one; it means either read something
  new, or weaken the sentence.
- **The sentence needs two citations.** Say which part each covers.
- **Something close but overstated.** Name the gap: the source says
  "associated with", the sentence says "reduces".

## Hard rules

- **Only papers with a note in `papers/notes/`.** A note exists because it was read.
  Never cite from the `.bib`, a title or an abstract — if it has no note, say
  "in the library but not read" and stop.
- **Never invent a citation**, and never attribute a number to a paper whose
  note does not contain it. `cannot find one` is a correct answer.
- Report `item_key`, never a cite key. Better BibTeX regenerates those.
- A note flagged `abstract-only` or `inbox-only` is a weak citation. Say so.

## Writing the citation into a draft

**Never write a formatted reference.** Not "(Choi et al., 2023, Sci Rep
Haemost 107:232-240)". A formatted reference you typed is one that nothing
checks, that no style switch can update, and that no bibliography knows
about.

Write a **placeholder that names the source unambiguously**, and let Zotero
format it. Which placeholder depends on how the draft will be finished —
`writing/STYLE.md` says which:

| route | placeholder | finished by |
|---|---|---|
| **LaTeX** | `\cite{choiMachineLearningModels2023}` | `tools/tex.sh <file>.tex` — the key must exist in `library.bib`, and an undefined one still compiles |
| **Zotero RTF Scan** | `{Choi, 2023}` or `{Choi, 2023, 22461}` | save as `.rtf`, then Zotero → Tools → RTF Scan → pick a style |
| **Pandoc** | `[@choiMachineLearningModels2023]` | `pandoc --citeproc --bibliography=papers/library/library.bib` |
| **Word plugin** | `{{CITE: Choi 2023 · 8KQW2MJ4}}` | I replace each one by hand with Add/Edit Citation |

Always append the note path and `item_key` in a comment or a list at the end
of what you hand back, so the placeholder can be resolved to an exact item
later:

    {Choi, 2023}     → papers/notes/Choi2023-warfarin-discharge-dose.md
                        item_key RDEWFSFF · doi 10.1160/TH11-06-0388

**A Better BibTeX cite key is not stable unless pinned.** If a draft uses
pandoc keys, say so once: the key must be pinned in Zotero's `Extra` field
(`Citation Key: ...`) or it will regenerate when metadata changes and the
citation will silently fail to resolve.

## Then stop

Do not insert the citation, edit the draft, or update the index. Hand back the
candidates. When the sentence is written, `citecheck` audits it against the
source that was chosen — that pass opens the PDF, which this one does not.
