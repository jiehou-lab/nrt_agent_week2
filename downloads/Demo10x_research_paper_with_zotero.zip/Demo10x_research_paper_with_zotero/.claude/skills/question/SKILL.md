---
name: question
description: Turn a spoken description into a properly-scoped numbered entry for QUESTIONS.md, or mark an existing question answered or dropped. Use when the user says they want to add, answer, drop or reword a research question.
---

# Shaping a research question

`QUESTIONS.md` is **denied to you** in `.claude/settings.json`. You cannot
write it, and that is the point: a question the human did not type is a
question they will not recognise in six months. You draft; they paste.

## A question comes from the human. Only.

Not from a paper. Not from a gap you found. Not from the folder contents.
If you derive a question from material rather than from something they said,
you have invented their research direction, which is the one thing here that
is entirely theirs.

What you may do with material: point out that a `[GAP:]` recurs across three
drafts and **ask** whether it is becoming a question.

## Make it answerable

The test is not "is it interesting" but **what evidence would close this?**

| What they said | What to ask back |
|---|---|
| A topic — "model calibration" | "What would you need to see to stop worrying about it?" |
| A task — "summarise these five papers" | "What would the summary change your mind about?" |
| Two questions in one sentence | "Which half fails first if you are wrong?" |
| Already settled | Quote the existing entry and its date; ask if it is being reopened. |
| Unfalsifiable as stated | Offer the nearest version that a result could contradict. |

Ask **one** of these, not all of them. If their answer already contains the
evidence condition, do not interrogate further — draft it.

## Draft the block

Use the exact shape in `QUESTIONS.md`, with the next free number. Never
renumber an existing question: notes and drafts cite these numbers, and
renumbering silently breaks every reference.

- **What would answer it** is the field that does the work. If you cannot
  write it from what they told you, say so and ask for that one thing.
- **Where it stands** cites what is actually in `papers/_index.md`. If
  nothing in the library bears on it, write that — a question with no
  supporting literature yet is a normal and useful state.

## Answering or dropping one

Never delete a question. Set `Status` to `answered` or `dropped` and add one
line saying what settled it and when. A dropped question that leaves no trace
gets asked again next year, usually by you.

## Then stop

Print the block, say which file and where it goes, and stop. Do not write
it, do not update `papers/_index.md`, and do not go looking for papers that
might answer it unless asked.
