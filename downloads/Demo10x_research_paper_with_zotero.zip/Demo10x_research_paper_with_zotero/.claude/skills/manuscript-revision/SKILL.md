---
name: manuscript-revision
description: Mechanical pre-submission check of a manuscript draft — figure call-outs, abbreviations, numbers against sources, limitations. Use before sending a draft to a co-author, a journal, or back to reviewers.
---

# Manuscript revision check

**Not "make this better."** This is the checklist you currently run by hand
across seven versions. Everything here is mechanically checkable, which is
why it belongs in a skill rather than in a conversation.

Report findings. **Do not rewrite prose.**

## 1. Figures and tables

- Is every figure called out in the text, in order? List any called out of
  order or never called out.
- Does every figure that exists have a call-out, and vice versa?
- Does each caption stand alone — could a reader who skipped the text follow it?
- Do panel letters in the caption match the panels in the figure file?

## 2. Abbreviations

- Defined at first use in the abstract, and again at first use in the body?
- Used consistently after definition — no silent reversions to the long form?
- Any abbreviation defined twice, or defined and never used again?

## 3. Numbers

**The one that matters.**

- Does every number in the abstract appear somewhere in a table or figure?
- Does every percentage follow arithmetically from the figures it derives
  from? Show the arithmetic.
- Units stated, and consistent across sections?
- Does `n` mean the same thing everywhere — subjects, measurements, records?
  This is the single most common error in this class of paper.
- Significant figures consistent within a table?

## 4. Claims against sources

Hand this part to `citecheck`:

    Use the citecheck subagent on <draft>.

It reports `confirmed` / `contradicted` / `overstated` / `cannot verify` per
claim. **Read the `overstated` rows most carefully** — a source saying
"associated with" does not support a draft saying "causes", and that upgrade
is what a reviewer catches.

## 5. Limitations

- Does the section name the objection a reviewer will actually raise, or only
  safe ones?
- Is any limitation contradicted by a claim made earlier in the paper?
- Is anything conceded in limitations that the abstract still asserts flatly?

## 6. Versions

If several versions of this draft are on disk, say which you read, and flag
any whose relationship is unclear from the filenames alone. A `_full` beside a
`_refined` beside a plain one is a question, not a naming scheme.

## Output

A table: check, finding, location. Then one line — how many checks passed out
of how many run.

**Do not comment on style, voice or flow.** Those are in `writing/STYLE.md`
and they are not this skill's job.
