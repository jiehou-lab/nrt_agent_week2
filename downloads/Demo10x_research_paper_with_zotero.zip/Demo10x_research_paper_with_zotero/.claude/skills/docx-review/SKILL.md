---
name: docx-review
description: Refine a Word manuscript that Zotero already owns — read it, and return edits as tracked changes without touching the citation fields. Use when the user points at a .docx in writing/ rather than a markdown draft.
---

# Reviewing a Word document Zotero owns

Once a `.docx` carries live Zotero field codes, **it is the source of truth
and markdown is not.** There is no round trip: `docx -> md -> docx` returns
zero field codes, citations degrade to plain text, and Zotero stops owning
the document. Measured on this project's own draft. So never regenerate a
live `.docx` from its markdown, and never edit one with pandoc.

## Read

    python3 tools/docx_text.py <file>.docx

Numbered paragraphs, with citations shown as `«citation:N»` and the reference
list as `«bibliography:N»` so you can see a citation is there without being
able to mistake its rendered text for something you may edit. Deleted text
from existing tracked changes is excluded, so you read the accepted view.

Tables come out as pipe tables in body order, not as a stream of one-word
paragraphs. Figures appear as `«figure:N word/media/imageN.png — alt text»`.

The audit block at the end is the first thing to check:

- `bibliography: NO` — nobody clicked Add/Edit Bibliography in Word. Say so.
- `stray_citekeys` — `[@key]` survived as plain text; it is not a citation.
- `gap markers` / `web markers` — the drafter's open questions, still open.
- `embedded images` vs `figures referenced` — a mismatch means an image is in
  the archive but not placed in the body, or placed twice.

## Look at the figures

    python3 tools/docx_text.py <file>.docx --media /tmp/figs

Then Read the PNGs. **Do this before commenting on any figure.** The caption
is the author's claim about the figure; the axes are where it goes wrong —
units that do not match the text, a highlighted bar with no interval behind
it, a log scale the caption does not mention. None of that is visible from
the caption, and an agent that reviews captions while calling it figure
review is worse than one that says it did not look.

You cannot edit a figure. Say what is wrong with it and let the user redraw.

## Check, if it came from elsewhere

A `.docx` edited by Cowork, a co-author, or any other tool may have a damaged
field and still open cleanly:

    python3 tools/docx_text.py <new>.docx --against <what-was-sent>.docx

Citation counts can match while a field sits inside a `<w:del>`. Run this
before building on a file this workspace did not produce.

## Suggest

Write a JSON list, then apply it:

    [{"find": "exact text, within one paragraph",
      "replace": "the replacement",
      "why": "for the user's review, not written into the document"}]

    python3 tools/docx_suggest.py <file>.docx suggestions.json

Output is `<file>-suggested.docx`; **the input is never written to.** Every
change is a `<w:ins>`/`<w:del>` pair, so the user accepts or rejects each one
in Word's Review tab. Only the changed phrase is marked, not the whole run.

`find` must be exact and inside one paragraph **or one table cell** — table
text is reachable, and it is usually where the numbers worth checking are. The script refuses any match
that touches a citation field and discards its own output if the field count
or `fldChar` balance moves.

## What you may not do

- **Do not insert citations.** A `ZOTERO_ITEM` field embeds Zotero's internal
  item JSON and a citationID; forging one is how a library gets corrupted.
  Put `[CITE: authorYearKeyword]` in a `replace` and say which paper it is.
  The user inserts it in Word with Add/Edit Citation — one click, always right.
- **Do not run the docx skill's `merge_runs.py`** on a live document. It
  merges prose runs into field runs, after which no edit near a citation can
  avoid the field.
- **Do not resolve a `[GAP:]` from memory.** It is open because no source
  supports it. Closing it needs a note or a search, same as in markdown.

## Where this sits

Markdown is for drafting, while the text is fluid and citations are markers.
Word is for the endgame: co-authors, journal styles, Zotero. The more
refinement that happens before the handoff, the less of this you need.
