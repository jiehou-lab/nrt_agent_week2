---
name: lit-review
description: Shape for a literature review or related-work section — organised by disagreement rather than by paper. Use when asked for a lit review, related work, background section, or a survey of what is known.
---

# Literature review — the shape

Invoke with `drafter`. This file supplies **structure only**; the tier rule
and the marker convention come from `drafter` and are not negotiable here.

## The failure this shape exists to prevent

**A paper-by-paper list.** "Smith et al. showed X. Jones et al. showed Y.
Lee et al. showed Z." Every sentence is true, the section is useless, and it
is what you get by default because it is the easiest thing to write from a
pile of notes.

A review is worth reading when it is organised by **what the field disagrees
about**, and each paragraph ends somewhere.

## Structure

1. **The question this review is for.** One or two sentences. If it serves a
   project, cite the Q-number. A review with no question is a reading list.
2. **Three to five themes, each a point of tension** — not a topic. Good:
   *"whether genotype adds anything once INR response is known"*. Bad:
   *"pharmacogenetic dosing"*. The test: can two papers disagree about it?
3. **Within each theme:** what most work assumes → who found otherwise →
   what the disagreement turns on, usually a methods difference. Finish the
   paragraph with where it currently stands, including "unresolved".
4. **What nobody has done.** The paragraph the review is actually for. It
   must follow from the themes above, not arrive as an assertion.

## Rules specific to this shape

- **Group by claim, not by paper.** One paper may appear in three themes;
  one theme may rest on six papers.
- **Disagreements are the content.** If two notes contradict each other, that
  is a paragraph, not a problem to smooth over. Quote both and say what the
  difference turns on — usually cohort, split, or outcome definition.
- Prefer a `## Supports` statement from a note over its `## Claim`. The claim
  is the headline; the supports are what the paper can actually back.
- **Say how much of this you have read.** End with the tier counts from
  `drafter`'s report. A review that is 70% `web` tier is a search summary,
  and the reader — you — should know that before using it.

## Length

Say how long before starting. 400 words is four themes stated; 2,000 is four
themes argued. Without a target this becomes long by default, and long
reviews hide thin ones.
