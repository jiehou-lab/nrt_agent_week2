#!/usr/bin/env python3
"""Where jobs actually go.

Two backends with the same three operations. Everything above this file — the
MCP server, CLAUDE.md, the agent — is identical either way. That is the point:
the agent talks to an interface, not to a scheduler.

    local   a small simulator that runs on any laptop. Default.
    slurm   sbatch / squeue / sacct on a real cluster.

Switch with the environment variable:

    export TISSUE_SCHEDULER=slurm
"""
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JOBS = ROOT / "jobs"
BACKEND = os.environ.get("TISSUE_SCHEDULER", "local").lower()

# How long the simulator pretends to wait in the queue, and to run per slide.
QUEUE_SECONDS = float(os.environ.get("TISSUE_FAKE_QUEUE_SECONDS", "5"))
SECONDS_PER_SLIDE = float(os.environ.get("TISSUE_FAKE_SECONDS_PER_SLIDE", "1.5"))


def _job_dir(job_id):
    return JOBS / job_id


def _read(job_id):
    f = _job_dir(job_id) / "job.json"
    if not f.exists():
        return None
    return json.loads(f.read_text())


def _write(job_id, record):
    d = _job_dir(job_id)
    d.mkdir(parents=True, exist_ok=True)
    (d / "job.json").write_text(json.dumps(record, indent=2) + "\n")


# --------------------------------------------------------------- local backend
def _submit_local(slides, magnification, threshold):
    job_id = "job_" + uuid.uuid4().hex[:8]
    record = {
        "job_id": job_id,
        "backend": "local",
        "state": "queued",
        "submitted_at": time.time(),
        "slides": slides,
        "magnification": magnification,
        "damage_threshold_fraction": threshold,
        "queue_seconds": QUEUE_SECONDS,
        "seconds_per_slide": SECONDS_PER_SLIDE,
        "n_slides": len(slides),
        "n_done": 0,
    }
    _write(job_id, record)
    # Detach the worker. The job now outlives this process, this MCP call, and
    # the conversation that started it.
    subprocess.Popen(
        [sys.executable, str(ROOT / "scheduler" / "runner.py"), job_id],
        cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return job_id


def _status_local(job_id):
    r = _read(job_id)
    if r is None:
        return {"error": "no such job: %s" % job_id}
    return {
        "job_id": job_id,
        "state": r["state"],
        "slides_total": r["n_slides"],
        "slides_done": r.get("n_done", 0),
        "elapsed_seconds": round(time.time() - r["submitted_at"], 1),
        "message": r.get("message", ""),
    }


# --------------------------------------------------------------- slurm backend
# NOTE: this path has not been run on a cluster by the course staff. Treat it as
# a starting point and check it against your own site's scheduler before relying
# on it. Partition, account and module lines live in slurm/job_template.sbatch.
def _submit_slurm(slides, magnification, threshold):
    job_id = "pending"
    payload = {"slides": slides, "magnification": magnification,
               "damage_threshold_fraction": threshold}
    spec = JOBS / ("spec_" + uuid.uuid4().hex[:8] + ".json")
    spec.parent.mkdir(parents=True, exist_ok=True)
    spec.write_text(json.dumps(payload, indent=2))
    p = subprocess.run(
        ["sbatch", "--parsable", str(ROOT / "slurm" / "job_template.sbatch"), str(spec)],
        cwd=str(ROOT), capture_output=True, text=True,
    )
    if p.returncode != 0:
        raise RuntimeError("sbatch failed: " + (p.stderr or p.stdout))
    job_id = p.stdout.strip().split(";")[0]
    _write(job_id, {"job_id": job_id, "backend": "slurm", "state": "queued",
                    "submitted_at": time.time(), "slides": slides,
                    "magnification": magnification,
                    "damage_threshold_fraction": threshold,
                    "n_slides": len(slides), "spec": str(spec)})
    return job_id


_SLURM_STATE = {
    "PENDING": "queued", "CONFIGURING": "queued",
    "RUNNING": "running", "COMPLETING": "running",
    "COMPLETED": "completed",
    "FAILED": "failed", "CANCELLED": "failed", "TIMEOUT": "failed",
    "NODE_FAIL": "failed", "OUT_OF_MEMORY": "failed",
}


def _status_slurm(job_id):
    p = subprocess.run(["squeue", "-j", job_id, "-h", "-o", "%T"],
                       capture_output=True, text=True)
    raw = (p.stdout or "").strip().splitlines()
    if raw:
        state = _SLURM_STATE.get(raw[0].strip(), raw[0].strip().lower())
    else:
        q = subprocess.run(["sacct", "-j", job_id, "-n", "-P", "-o", "State"],
                           capture_output=True, text=True)
        first = (q.stdout or "").strip().splitlines()
        state = _SLURM_STATE.get(first[0].split()[0], "unknown") if first else "unknown"
    r = _read(job_id) or {}
    return {"job_id": job_id, "state": state,
            "slides_total": r.get("n_slides"), "slides_done": None,
            "elapsed_seconds": round(time.time() - r.get("submitted_at", time.time()), 1),
            "message": "state read from squeue/sacct"}


# --------------------------------------------------------------- public API
def submit(slides, magnification, threshold):
    if BACKEND == "slurm":
        return _submit_slurm(slides, magnification, threshold)
    return _submit_local(slides, magnification, threshold)


def status(job_id):
    if BACKEND == "slurm":
        return _status_slurm(job_id)
    return _status_local(job_id)


def results(job_id):
    f = _job_dir(job_id) / "results.json"
    st = status(job_id)
    if "error" in st:
        return st
    if not f.exists():
        return {"error": "results are not ready", "job_id": job_id,
                "state": st["state"],
                "hint": "call check_status until state is 'completed'"}
    return json.loads(f.read_text())


def list_jobs():
    out = []
    if JOBS.exists():
        for d in sorted(JOBS.iterdir()):
            if d.is_dir() and (d / "job.json").exists():
                r = json.loads((d / "job.json").read_text())
                out.append({"job_id": r["job_id"], "state": r["state"],
                            "slides_total": r.get("n_slides"),
                            "submitted_at": r["submitted_at"]})
    return {"jobs": out, "backend": BACKEND}
