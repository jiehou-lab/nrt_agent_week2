#!/usr/bin/env python3
"""Cluster-side worker: the body of the sbatch script.

Same work as runner.py, without the simulated queue — the real queue already
happened. Writes jobs/<slurm_job_id>/results.json in the same shape, so nothing
above the backend has to know which scheduler ran it.

Not exercised by the course staff on a cluster. Check it against your site.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scheduler"))

from runner import make_summary, run_tool  # noqa: E402


def main(spec_path, job_id):
    spec = json.loads(Path(spec_path).read_text())
    jd = ROOT / "jobs" / str(job_id)
    jd.mkdir(parents=True, exist_ok=True)
    records = []
    for slide in spec["slides"]:
        stem = Path(slide).stem
        a_out = jd / (stem + "_analyze.json")
        feats = run_tool("analyze_tissue.py", [
            "--slide", slide,
            "--magnification", str(spec.get("magnification", 20)),
            "--damage-threshold-fraction", str(spec.get("damage_threshold_fraction", 0.45)),
            "--out", str(a_out)])
        cls = run_tool("classify_tissue.py", [
            "--features", str(a_out), "--out", str(jd / (stem + "_classify.json"))])
        records.append({
            "slide": slide, "damage_fraction": feats["damage_fraction"],
            "hard_edge_rate": feats["hard_edge_rate"], "confidence": feats["confidence"],
            "low_confidence": feats["low_confidence"], "usable": feats["usable"],
            "notes": feats.get("notes", ""), "label": cls["label"],
            "probability": cls["probability"]})
    (jd / "results.json").write_text(json.dumps({
        "job_id": str(job_id), "backend": "slurm",
        "magnification": spec.get("magnification", 20),
        "damage_threshold_fraction": spec.get("damage_threshold_fraction", 0.45),
        "n_slides": len(records), "summary": make_summary(records),
        "slides": records}, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
