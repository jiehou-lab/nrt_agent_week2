#!/usr/bin/env python3
"""The worker for the local backend.

Started detached by backend.submit(). It waits in a simulated queue, analyses and
classifies each slide, and writes results.json. Nothing about it knows an agent
exists — which is the property that makes the job survive the conversation.

On a real cluster this is the body of the sbatch script.
"""
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def run_tool(script, args):
    cmd = [sys.executable, str(ROOT / "tools" / script)] + args
    p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError("%s failed: %s" % (script, p.stderr.strip()))
    return json.loads(p.stdout)


def make_summary(records):
    """Human-readable one-liner for the report.

    NOTE FOR STUDENTS: read this function carefully before you trust anything it
    writes. It is the only part of the pipeline that decides what a reader is
    told, and what it leaves out is invisible downstream.
    """
    n = len(records)
    mean_damage = round(sum(r["damage_fraction"] for r in records) / n, 3) if n else 0
    labels = {}
    for r in records:
        labels[r["label"]] = labels.get(r["label"], 0) + 1
    parts = ", ".join("%s x%d" % (k, v) for k, v in sorted(labels.items()))
    return "%d slides analyzed. mean damage_fraction %.3f. classifications: %s." % (
        n, mean_damage, parts)


def main(job_id):
    jd = ROOT / "jobs" / job_id
    rec = json.loads((jd / "job.json").read_text())

    def save():
        (jd / "job.json").write_text(json.dumps(rec, indent=2) + "\n")

    time.sleep(rec.get("queue_seconds", 5))
    rec["state"] = "running"
    rec["started_at"] = time.time()
    save()

    records = []
    try:
        for slide in rec["slides"]:
            time.sleep(rec.get("seconds_per_slide", 1.5))
            stem = Path(slide).stem
            a_out = jd / (stem + "_analyze.json")
            feats = run_tool("analyze_tissue.py", [
                "--slide", slide,
                "--magnification", str(rec["magnification"]),
                "--damage-threshold-fraction", str(rec["damage_threshold_fraction"]),
                "--out", str(a_out),
            ])
            cls = run_tool("classify_tissue.py", [
                "--features", str(a_out),
                "--out", str(jd / (stem + "_classify.json")),
            ])
            records.append({
                "slide": slide,
                "damage_fraction": feats["damage_fraction"],
                "hard_edge_rate": feats["hard_edge_rate"],
                "confidence": feats["confidence"],
                "low_confidence": feats["low_confidence"],
                "usable": feats["usable"],
                "notes": feats.get("notes", ""),
                "label": cls["label"],
                "probability": cls["probability"],
            })
            rec["n_done"] = len(records)
            save()
    except Exception as exc:                                  # noqa: BLE001
        rec["state"] = "failed"
        rec["message"] = str(exc)
        rec["finished_at"] = time.time()
        save()
        return 1

    report = {
        "job_id": job_id,
        "backend": rec.get("backend", "local"),
        "magnification": rec["magnification"],
        "damage_threshold_fraction": rec["damage_threshold_fraction"],
        "n_slides": len(records),
        "summary": make_summary(records),
        "slides": records,
    }
    (jd / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    rec["state"] = "completed"
    rec["finished_at"] = time.time()
    save()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
