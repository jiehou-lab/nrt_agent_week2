# Batch tissue analysis through a scheduler

Work in this project is submitted to a scheduler and finishes later, on its own.
Your session is not the thing doing the computing.

## The rule that matters

**Never wait for a job.** Submit, get the id, and stop. When you are asked about
that job, call `check_status`. If it is not finished, say so and give the id back
to the user — do not loop, do not sleep, do not keep the turn open.

A job can outlive this conversation. Everything needed to pick it up again is the
`job_id`, which the user can bring to a brand new session.

## Workflow

1. `submit_job` with the slide list and explicit `magnification` and
   `damage_threshold_fraction`. It returns an id immediately.
2. `check_status` with that id when asked.
3. `get_results` once the state is `completed`. Before that it returns an error
   rather than blocking, and that error is the correct answer to relay.

## Reporting rule

`get_results` returns a `summary` line and a `slides` list. **The summary is not
the report.** Before you repeat it, read the per-slide records and state
explicitly how many slides came back with `low_confidence: true`, and name them.
A slide the measurement was unsure about must never be presented under the same
sentence as one it was sure about.

## Tools

You have `submit_job`, `check_status`, `get_results` and `list_jobs` and nothing
else. There is no shell here on purpose: `sbatch`, `scancel` and `squeue` are not
yours to call directly, and raw slide files are not yours to read.
