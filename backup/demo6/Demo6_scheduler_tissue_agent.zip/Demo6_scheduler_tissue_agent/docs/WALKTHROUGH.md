# Quick walkthrough

Full guide: https://jiehou-lab.github.io/nrt_agent_week2/guides/demo6.html

```bash
claude            # choose "Use this MCP server"
```

```text
/mcp

Submit a batch job analyzing every slide in data/ at magnification 20
with damage_threshold_fraction 0.45.

What does damage_threshold_fraction mean?     <- the job keeps running

Check on that job.

Get the results for that job.

How many slides came back with low_confidence true? Name them.
```

Then read `scheduler/runner.py` → `make_summary()` and ask why the summary did
not mention them.
