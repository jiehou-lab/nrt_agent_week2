# Demo 6 — a job that outlives the conversation

The same tissue analysis, submitted to a scheduler instead of run in the turn.

    agent -> submit_job    -> scheduler  (returns an id immediately)
             ...the job runs on its own, in a process nobody is waiting for...
    agent -> check_status  -> queued / running / completed
    agent -> get_results   -> a report the agent then has to read properly

## Run it

No cluster required. The default backend is a local simulator that queues for a
few seconds and then works through the slides, so the whole pattern runs on a
laptop with nothing but Python 3.

    claude

Then ask it to submit all eight slides. See `docs/WALKTHROUGH.md`.

Make the simulated queue longer or shorter:

    export TISSUE_FAKE_QUEUE_SECONDS=20
    export TISSUE_FAKE_SECONDS_PER_SLIDE=3

## On a real cluster

    export TISSUE_SCHEDULER=slurm

`scheduler/backend.py` then shells out to `sbatch --parsable` and reads state
from `squeue`/`sacct`; `slurm/job_template.sbatch` is where your account,
partition and module lines go. Nothing above `backend.py` changes — the MCP
server, CLAUDE.md and the agent are identical either way.

**This path has not been run on a cluster by the course staff.** Treat it as a
starting point and check it against your own site before relying on it.

## Files

    server.py                    MCP: submit_job, check_status, get_results, list_jobs
    scheduler/backend.py         local | slurm - the only file that knows which
    scheduler/runner.py          the local worker (detached; survives your session)
    scheduler/slurm_worker.py    the cluster worker (body of the sbatch script)
    slurm/job_template.sbatch    fill in account / partition / modules
    jobs/                        one directory per job: job.json, results.json
    CLAUDE.md                    "never wait for a job", and the reporting rule
    .claude/settings.json        four MCP tools; no Bash, no raw slide reads

## Why there is no shell

An agent with an open shell on a cluster can `scancel` someone else's array,
fill a scratch quota, or submit five hundred jobs from one mistyped loop. Here
the scheduler is reachable only through four tools that do exactly four things.
That is the Demo 3 lesson with real consequences attached.
