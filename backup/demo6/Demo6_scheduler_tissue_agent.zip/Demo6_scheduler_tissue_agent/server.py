#!/usr/bin/env python3
"""MCP server for a batch tissue-analysis job — standard library only.

Four tools, and none of them block:

    submit_job     hand work to the scheduler, get an id back immediately
    check_status   ask where that id has got to
    get_results    fetch the report, once there is one
    list_jobs      what has been submitted from this folder

The agent never waits for a job. It submits, and later it asks. The job itself
runs in a process this server does not own and does not wait for, which is why
it survives a closed terminal, a lost session, and a finished conversation.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scheduler"))

import backend  # noqa: E402

SLIDES = sorted(p.name for p in (ROOT / "data").glob("*.pgm"))

TOOLS = [
    {
        "name": "submit_job",
        "description": ("Queue a batch tissue analysis and return a job id straight away. "
                        "Does NOT wait for the work to finish. Use check_status afterwards."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "slides": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "description": "slide paths, e.g. ['data/case_001.pgm']",
                },
                "magnification": {"type": "integer", "enum": [10, 20, 40], "default": 20},
                "damage_threshold_fraction": {
                    "type": "number", "minimum": 0, "maximum": 1, "default": 0.45,
                    "description": "a FRACTION between 0 and 1, never a percentage"},
            },
            "required": ["slides"],
        },
    },
    {
        "name": "check_status",
        "description": ("Where a submitted job has got to: queued, running, completed or "
                        "failed, with how many slides are done."),
        "inputSchema": {
            "type": "object",
            "properties": {"job_id": {"type": "string"}},
            "required": ["job_id"],
        },
    },
    {
        "name": "get_results",
        "description": ("The report for a completed job: a summary line and one record per "
                        "slide. Returns an error, not a wait, if the job is still running."),
        "inputSchema": {
            "type": "object",
            "properties": {"job_id": {"type": "string"}},
            "required": ["job_id"],
        },
    },
    {
        "name": "list_jobs",
        "description": "Every job submitted from this project folder, newest last.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]
BY_NAME = {t["name"]: t for t in TOOLS}


def validate(schema, args):
    errs, props = [], schema.get("properties", {})
    for k in schema.get("required", []):
        if k not in args:
            errs.append("missing required argument '%s'" % k)
    for k, v in args.items():
        if k not in props:
            errs.append("unknown argument '%s' (allowed: %s)" % (k, ", ".join(props)))
            continue
        s = props[k]
        if s.get("type") == "integer" and not isinstance(v, int):
            errs.append("'%s' must be an integer, got %r" % (k, v))
        if s.get("type") == "number" and not isinstance(v, (int, float)):
            errs.append("'%s' must be a number, got %r" % (k, v))
        if s.get("type") == "array":
            if not isinstance(v, list):
                errs.append("'%s' must be a list, got %r" % (k, v))
            elif len(v) < s.get("minItems", 0):
                errs.append("'%s' needs at least %d item(s)" % (k, s["minItems"]))
        if "enum" in s and v not in s["enum"]:
            errs.append("'%s' must be one of %s, got %r" % (k, s["enum"], v))
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            if "minimum" in s and v < s["minimum"]:
                errs.append("'%s' must be >= %s, got %s" % (k, s["minimum"], v))
            if "maximum" in s and v > s["maximum"]:
                hint = " (did you mean %g?)" % (v / 100) if s["maximum"] == 1 else ""
                errs.append("'%s' must be <= %s, got %s%s" % (k, s["maximum"], v, hint))
    return errs


def call(name, args):
    spec = BY_NAME.get(name)
    if not spec:
        return "unknown tool: %s" % name, True
    errs = validate(spec["inputSchema"], args)
    if errs:
        return "argument validation failed (nothing was submitted):\n- " + "\n- ".join(errs), True

    if name == "submit_job":
        slides = args["slides"]
        missing = [s for s in slides if not (ROOT / s).exists()]
        if missing:
            return ("no such slide(s): %s\navailable in data/: %s"
                    % (", ".join(missing), ", ".join(SLIDES))), True
        job_id = backend.submit(slides, args.get("magnification", 20),
                                args.get("damage_threshold_fraction", 0.45))
        return json.dumps({
            "job_id": job_id,
            "state": "queued",
            "n_slides": len(slides),
            "note": ("submitted and returned immediately - the work has NOT been done yet. "
                     "Call check_status with this job_id."),
        }, indent=2), False

    if name == "check_status":
        return json.dumps(backend.status(args["job_id"]), indent=2), False

    if name == "get_results":
        out = backend.results(args["job_id"])
        return json.dumps(out, indent=2), "error" in out

    if name == "list_jobs":
        return json.dumps(backend.list_jobs(), indent=2), False

    return "unhandled tool: %s" % name, True


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            ver = (msg.get("params") or {}).get("protocolVersion") or "2024-11-05"
            res = {"protocolVersion": ver, "capabilities": {"tools": {}},
                   "serverInfo": {"name": "tissue-scheduler", "version": "1.0.0"}}
        elif method == "tools/list":
            res = {"tools": [{k: t[k] for k in ("name", "description", "inputSchema")}
                             for t in TOOLS]}
        elif method == "tools/call":
            pr = msg.get("params") or {}
            text, err = call(pr.get("name"), pr.get("arguments") or {})
            res = {"content": [{"type": "text", "text": text}], "isError": err}
        elif mid is None:
            continue
        else:
            print(json.dumps({"jsonrpc": "2.0", "id": mid,
                              "error": {"code": -32601, "message": "no method " + str(method)}}),
                  flush=True)
            continue
        if mid is not None:
            print(json.dumps({"jsonrpc": "2.0", "id": mid, "result": res}), flush=True)


if __name__ == "__main__":
    main()
